<?php

/* makefont.inc.php - SynApp2 include file for application specific customization
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: makefont.inc.php,v 1.1 2011/06/18 17:46:01 richard Exp $
*/

////

define('DIR_MAKEFONT', get_font_dir() . 'makefont/');

include(DIR_MAKEFONT . 'makefont.php');

get_custom()->bind_process('process_makefont_init', 'process_makefont_init');
get_custom()->bind_process('process_makefont', 'process_makefont');

////

function process_makefont_init(&$args, &$action, &$adhoc_markup)
{
    $fnt = array();
    $ttf = array();
    $afm = array();
    $enc = array();

    if (is_dir(DIR_MAKEFONT))
    {
        if ($dh = opendir(DIR_MAKEFONT))
        {
            while (($basename = readdir($dh)) !== false)
            {
                switch (strtolower(pathinfo(DIR_MAKEFONT . $basename, PATHINFO_EXTENSION)))
                {
                case 'ttf':
                    $ttf[] = preg_replace('/\.ttf$/', '', $basename);
                    break;
                case 'afm':
                    $afm[] = preg_replace('/\.afm$/', '', $basename);
                    break;
                case 'map':
                    $filename = preg_replace('/\.map$/', '', $basename);
                    $enc[$filename] = $filename;
                    break;
                }
            }

            closedir($dh);
        }
    }

    if (!empty($ttf) && !empty($afm))
    {
        foreach ($ttf as $filename)
        {
            if (in_array($filename, $afm))
            {
                $fnt[$filename] = $filename; // both of the files needed for processing are present
            }
        }
    }

    natcasesort($fnt);
    natcasesort($enc);

    $adhoc_markup[] = '<label>Font (.ttf, .afm):</label>' . get_markup()->get_element_select('_process_fontfile', '', $fnt) . '<br />';
    $adhoc_markup[] = '<label>Encoding:</label>' . get_markup()->get_element_select('_process_encoding', 'iso-8859-1', $enc) . '<br />';
    $adhoc_markup[] = '<label>Label:</label><input type="text" name="_process_fontlabel" value="" /><br />';

    return true; // default: continue action;
}

function process_makefont(&$args, &$action, &$adhoc_markup)
{
    $adhoc_markup[] = '<blockquote><pre>';
    $adhoc_markup[] = '<hr />';

    $fontfile = $args['fontfile'];
    $encoding = $args['encoding'];
    $fontlabel = preg_replace('/[^a-z0-9 \(\)\-]/', '', strtolower($args['fontlabel']));

    ob_clean();
    ob_start();

    set_php_shutdown_action("on_makefont_fatal();"); // trap die()

    MakeFont(get_font_dir(/*is_core_fonts=*/false), $fontlabel, "{$fontfile}.ttf", "{$fontfile}.afm", $encoding);

    set_php_shutdown_action();

    $adhoc_markup[] = 'Font directory (' . get_font_dir(false) . ')';
    $adhoc_markup[] = ob_get_contents();
    $adhoc_markup[] = '</pre></blockquote>';

    ob_end_clean();

    return true; // default: continue action;
}

function on_makefont_fatal()
{
    $feedback = "<status name=\"message\">Error MakeFont() - " . ob_get_contents() . "</status>";
    ob_end_clean();

    ////

    $response = '';

    fmt_line($response, '<' . '?xml version="1.0" encoding="' . get_charset_map()->get_charset_out() . '" standalone="yes" ?' . '>');
    fmt_line($response, "<response>");
    fmt_line($response, "<version>" . get_version() . "</version>");
    fmt_line($response, "<authentication>succeeded</authentication>");
    fmt_line($response, "<authorization>succeeded</authorization>");
    fmt_line($response, "<adhoc>");
    fmt_line($response, '<feedback>');
    fmt_line($response, $feedback);
    fmt_line($response, '</feedback>');
    fmt_line($response, "</adhoc>");
    fmt_line($response, "</response>");

    ////

    header("Content-Type: text/xml");
    echo $response;
}

////

?>
