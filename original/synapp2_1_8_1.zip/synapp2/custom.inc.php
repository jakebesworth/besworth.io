<?php

/* custom.inc.php - SynApp2 include file for application specific customization
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: custom.inc.php,v 1.5 2011/06/18 17:45:03 richard Exp $
*/

////

$this->m_data[APPID]['synapp2'][INCL][NAV][] = array(A_HREF => 'keymap', A_TEXT => 'KeyMap');
$this->m_data[APPID]['synapp2'][INCL][NAV][] = array(A_HREF => 'options', A_TEXT => 'Options');
$this->m_data[APPID]['synapp2'][INCL][NAV][] = array(A_HREF => 'pagegen', A_TEXT => 'PageGen');
$this->m_data[APPID]['synapp2'][INCL][NAV][] = array(A_HREF => 'tools', A_TEXT => 'Tools');

include('makefont.inc.php');

////

?>
