<?php

/* charset.inc.php - SynApp2 include file for charset customization
**
   +======================================================================+
   | SynApp2 - Web Application Generator and MVC Framework                |
   +======================================================================+
**
** http://www.synapp2.org
**
** $Id: template.charset.inc.php,v 1.1 2011/06/18 18:14:41 richard Exp $
*/

// IMPORTANT: put charset customization elements in a file named 'charset.inc.php' (you may copy or rename this file)

/*
** map_charset() - establishes charset conversions for all applications within a SynApp2 installation instance
**
** @param string $charset_eng a charset name recognized by the database engine (connection)
** @param string $charset_rpt a charset name recognized by the FPDF report sub-system (drives font selection)
** @param string $charset_php an iconv() compatable alias for $charset_eng
** @param string $charset_in = 'UTF-8' an iconv() compatable name for SynApp2 request/input decoding [from]
** @param string $charset_out = 'UTF-8' an iconv() compatable name for SynApp2 result/output encoding [to]
*/

//map_charset('latin1', 'iso-8859-1', 'ISO-8859-1'); // MySQL
//map_charset('latin2', 'iso-8859-2', 'ISO-8859-2'); // MySQL
//map_charset('EE8ISO8859P2', 'iso-8859-2', 'ISO-8859-2'); // Oracle - ISO 8859-2 East European
//map_charset('EE8MSWIN1250', 'cp1250', 'CP1250'); // Oracle - MS Windows Code Page 1250 8-bit East European

////

?>
