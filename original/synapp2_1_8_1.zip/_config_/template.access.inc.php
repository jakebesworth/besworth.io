<?php

/* access.inc.php - SynApp2 include file for access customization
**
   +======================================================================+
   | SynApp2 - Web Application Generator and MVC Framework                |
   +======================================================================+
**
** http://www.synapp2.org
**
** $Id: template.access.inc.php,v 1.1 2011/02/04 21:41:33 richard Exp $
*/

////

// IMPORTANT: put access customization elements in a file named 'access.inc.php' (you may copy or rename this file)

// SECURITY: <-- search this file for all instances of this tag and make changes as directed
// DEFAULT: <-- search this file for all instances of this tag and make changes as needed

////

//$this->m_config[DIAGNOSTIC_MSG_ENABLE_FLAG] = 'true'; //false; // SECURITY: consider value upon deployment

////

//$this->m_config[ONE_FOR_ALL_HOSTNAME] = 'localhost'; // DEFAULT: change as appropriate for your needs
//$this->m_config[ONE_FOR_ALL_PASSWORD] = 'password'; // SECURITY: consider value upon deployment
//$this->m_config[ONE_FOR_ALL_HASH] = '1a2b3c'; // SECURITY: consider value upon deployment

////

// see access_base::get_site_...()
//
//$this->m_config[MAP_SITE_PREFIX]['http_host'] = 'prefix'; // DEPRECATED:
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_SITE_PREFIX] = 'prefix';
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_SITE_CONNECTION_STRING] = 'database_connection_string';

////

// see access_base::get_database_...()
//
//$this->m_config[MAP_DATABASE_PHYSICAL]['http_host']['database_logical'] = 'database_physical'; // DEPRECATED:
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_DATABASE_LOGICAL]['database_logical'][MAP_DATABASE_PHYSICAL] = 'database_physical';
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_DATABASE_LOGICAL]['database_logical'][MAP_DATABASE_HOST] = 'database_host';
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_DATABASE_LOGICAL]['database_logical'][MAP_DATABASE_HOST_USERNAME] = 'database_host_username';
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_DATABASE_LOGICAL]['database_logical'][MAP_DATABASE_HOST_PASSWORD] = 'database_host_password';
//$this->m_config[MAP_HTTP_HOST]['http_host'][MAP_DATABASE_LOGICAL]['database_logical'][MAP_DATABASE_CONNECTION_STRING] = 'database_connection_string';

////

// see access_app::auth_connect()
//
//$this->m_config[MAP_AUTH_INTERFACE_DEF]['database_logical'] = new auth_interface_def('database_logical', 'table', 'field_username', 'field_password', 'function_encrypt');
//$this->m_config[MAP_AUTH_INTERFACE_DEF]['database_logical'] = new auth_interface_def('database_logical'); // remaining args default to: 'users', 'username', 'password', 'PASSWORD'

////

// see access_base::resolve()
//
//$this->m_config[MAP_HASH_CREDENTIALS]['special_hash'] = array('special_user', 'host', -u, -p);

////

?>
