<?php

/* engine.inc.php - SynApp2 include file for database engine customization
**
   +======================================================================+
   | SynApp2 - Web Application Generator and MVC Framework                |
   +======================================================================+
**
** http://www.synapp2.org
**
** $Id: template.engine.inc.php,v 1.1 2011/02/04 21:41:33 richard Exp $
*/

// IMPORTANT: put database engine customization elements in a file named 'engine.inc.php' (you may copy or rename this file)

//$engine = ENGINE_OCI;

////

?>
