<?php

/* validate.php - SynApp2 data validation and reporting
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: validate.php,v 1.15 2011/01/21 20:46:56 richard Exp $
*/

function validate_columns(&$action, &$dbx, &$custom, &$schema)
{
    $feedback = null;

    if ($action->is_insert() || $action->is_update())
    {
        $table_name = $custom->get_table();
        $cols_info = $schema->get_table_cols_info($table_name);

        foreach ($cols_info as $col_info)
        {
            $col_name = $col_info['Field'];
            $display_name = $schema->get_col_display_name($col_info);

            $col_type_detail = $schema->get_col_type_detail($col_info);

            $validator = $custom->get_validator($col_name, VALIDATOR_PRIMARY);

            if (!empty($validator) && is_callable($validator) === true)
            {
                $col_var = $action->get_col_var($col_name);
                $col_vars = $action->get_col_vars();

                $status_msg = call_user_func_array($validator, array($col_name, $col_var, $display_name, &$col_vars));

                if (!empty($status_msg))
                {
                    $feedback[$col_name] = array('status'=>"$status_msg");
                }
            }
            else if ($schema->is_pk($table_name, $col_name))
            {
                // ok - do nothing // TODO: ASSUME: all pk's are auto_increment
            }
            else
            {
                $is_fk = $schema->is_fk($table_name, $col_name);
                $is_blind = $schema->is_blind($table_name, $col_name);

                $col_var = $action->get_col_var($col_name);
                $col_var_is_present = $col_var !== null;
                $col_var_value = $col_var_is_present ? (is_array($col_var) ? trim($col_var[0]) : trim($col_var)) : '' ;
                $col_var_value_is_empty = strlen($col_var_value) < 1;

                if ($is_fk && $action->is_insert() && $col_var_value_is_empty && !is_valid_empty($col_info))
                {
                    $feedback[$col_name] = array('status'=>"$display_name (FK) is required!");
                }
                else if ($is_fk && $action->is_update() && !$col_var_is_present)
                {
                    // ok - do nothing;
                }
                else if ($is_blind && (!$col_var_is_present || $col_var_value_is_empty))
                {
                    // ok - do nothing;
                }
                else if ($col_var_value_is_empty && !is_valid_empty($col_info))
                {
                    $feedback[$col_name] = array('status'=>"$display_name is required, please enter a value");
                }
                else if ($col_var_value_is_empty)
                {
                    // ok - do nothing;
                }
                else if ($type_msg = validate_type($dbx, $col_info, $col_type_detail, $col_var_value))
                {
                    $feedback[$col_name] = array('status'=>"$display_name must be a valid $type_msg");
                }
                else if ($length_msg = validate_length($col_info, $col_type_detail, $col_var_value))
                {
                    $feedback[$col_name] = array('status'=>"$display_name may not be longer than $length_msg");
                }
                else if ($range_msg = validate_range($col_info, $col_type_detail, $col_var_value))
                {
                    $feedback[$col_name] = array('status'=>"$display_name must be $range_msg");
                }
                else if (!validate_duplicate($col_info, $col_type_detail, $col_var_value))
                {
                    $feedback[$col_name] = array('status'=>"$display_name must be unique");
                }
            }
        }

        foreach ($cols_info as $col_info)
        {
            $col_name = $col_info['Field'];

            if (empty($feedback[$col_name]))
            {
                $validator = $custom->get_validator($col_name, VALIDATOR_SECONDARY);

                if (!empty($validator) && is_callable($validator) === true)
                {
                    $col_var = $action->get_col_var($col_name);
                    $display_name = $schema->get_col_display_name($col_info);
                    $col_vars = $action->get_col_vars();

                    $status_msg = call_user_func_array($validator, array($col_name, $col_var, $display_name, &$col_vars, &$feedback));

                    if (!empty($status_msg))
                    {
                        $feedback[$col_name] = array('status'=>"$status_msg");
                    }
                }
            }
        }
    }
    else if ($action->is_delete())
    {
        $pk_values = $action->get_pk_values($custom->get_qid());

        if (!empty($pk_values))
        {
            $join_table = $custom->get_table();
            $pk_name = $custom->get_pk_name($join_table, true);
            $pk_list = implode(',', $pk_values);

            if (!empty($pk_name) && !empty($pk_list) && escape_sql_term($pk_list) == $pk_list)
            {
                $path_nodes = $schema->get_children($join_table);

                if (!empty($path_nodes))
                {
                    foreach ($path_nodes as $path_node)
                    {
                        $table_name = $path_node[TABLE_NAME];

                        $col_names = $custom->get_child_join_cols($join_table, $table_name);

                        if (!empty($col_names))
                        {
                            foreach ($col_names as $col_name)
                            {
                                $join_col = $custom->get_parent_join_col($join_table, $table_name, $col_name);

                                $qty = $dbx->get_query_value("select count(*) from $table_name, $join_table where $pk_name in ($pk_list) and $join_table.$join_col = $table_name.$col_name");

                                if ($qty > 0)
                                {
                                    $s = $qty > 1 ? 's' : '' ;
                                    $feedback[$join_table] = array('status' => "delete_denied - $qty dependent record{$s} in table: $table_name");
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return $feedback;
}

function validate_adhoc_col_vars(&$action, &$dbx, &$custom, &$schema)
{
    $feedback = null;

    if ($action->is_adhoc())
    {
        $adhoc_col_vars = array_merge(array(), $action->get_col_vars()); // copy by value

        foreach ($adhoc_col_vars as $col_name => $adhoc_col_var)
        {
            $validator = $custom->get_validator($col_name, VALIDATOR_PRIMARY);

            if (!empty($validator) && is_callable($validator) === true)
            {
                $col_var = $action->get_col_var($col_name);
                $col_vars = $action->get_col_vars();

                $status_msg = call_user_func_array($validator, array($col_name, $col_var, $col_name, &$col_vars));

                if (!empty($status_msg))
                {
                    $feedback[$col_name] = array('status'=>"$status_msg");
                }
            }
        }

        foreach ($adhoc_col_vars as $col_name => $adhoc_col_var)
        {
            if (empty($feedback[$col_name]))
            {
                $validator = $custom->get_validator($col_name, VALIDATOR_SECONDARY);

                if (!empty($validator) && is_callable($validator) === true)
                {
                    $col_var = $action->get_col_var($col_name);
                    $col_vars = $action->get_col_vars();

                    $status_msg = call_user_func_array($validator, array($col_name, $col_var, $col_name, &$col_vars, &$feedback));

                    if (!empty($status_msg))
                    {
                        $feedback[$col_name] = array('status'=>"$status_msg");
                    }
                }
            }
        }
    }

    return $feedback;
}

function validate_unique(&$action, &$dbx, &$custom, &$schema)
{
    $feedback = null;

    if ($error_dup = $dbx->get_error_dup())
    {
        $msg_dup = "duplicate_denied - Your entry would result in a duplicate record."; // TODO: get custom msg_dup for $qid
        $feedback["Table: {$custom->get_table()}"] = array('status'=>$msg_dup);
    }

    return $feedback;
}

////

function validate_type(&$dbx, &$col_info, &$col_type_detail, $col_value)
{
    $type_msg = '';

    $col_type = strtoupper($col_type_detail['type']);
    $is_type_unsigned = strpos(strtoupper($col_type_detail['flags']), 'UNSIGNED') !== false;

    if (strpos($col_type, 'CHAR') !== false ||
        strpos($col_type, 'TEXT') !== false)
    {
        // ok - do nothing
    }
    else if (strpos($col_type, 'ENUM') !== false ||
             strpos($col_type, 'SET') !== false)
    {
        if (!empty($col_type_detail['values']) &&
            is_array($col_type_detail['values']) &&
            !in_array($col_value, $col_type_detail['values']))
        {
            $type_msg = "'$col_type' member";
        }
    }
    else if ($col_type == 'DATE')
    {
        if ($col_value != '0000-00-00') // TODO: HACK: KLUGE:
        {
            $ymd = $dbx->parse_date_value($col_value);

            if (!is_valid_date($ymd['y'], $ymd['m'], $ymd['d']))
            {
                $type_msg = "'$col_type' (" . $dbx->get_datepicker_format() . ")";
            }
        }
    }
    else if ($col_type == 'TIME')
    {
        list($h, $m, $s) = sscanf($col_value, "%d:%d:%d");

        if (!preg_match('/^[0-9]{2}:[0-9]{2}:[0-9]{2}$/', $col_value) ||
            !is_valid_time($h, $m, $s))
        {
            $type_msg = "'$col_type' (hh:mm:ss)";
        }
    }
    else if ($col_type == 'DATETIME' ||
             $col_type == 'TIMESTAMP')
    {
        if ($col_type != 'TIMESTAMP' || $col_value != '0000-00-00 00:00:00')
        {
            list ($y, $m, $d, $h, $m, $s) = sscanf($col_value, "%d-%d-%d %d:%d:%d");

            if (!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$/', $col_value) ||
                !is_valid_date($y, $m, $d, $col_type == 'TIMESTAMP') ||
                !is_valid_time($h, $m, $s))
            {
                $type_msg = "'$col_type' (yyyy-mm-dd hh:mm:ss)";
            }
        }
    }
    else if ($col_type == 'YEAR')
    {
        if (!preg_match('/^[0-9]{4}$/', $col_value) ||
            !is_valid_year($col_value))
        {
            $type_msg = "'$col_type' (yyyy)";
        }
    }
    else if (strpos($col_type, 'INT') !== false ||
                    $col_type == 'BIT')
    {
        $regex = '/^' . ($is_type_unsigned ? '' : '[-]?') . '[0-9]+$/';

        if (!preg_match($regex, $col_value))
        {
            $type_msg = "'" . ($is_type_unsigned ? 'UNSIGNED ' : '') . "$col_type'";
        }
    }
    else if (strpos($col_type, 'FLOAT') !== false ||
             strpos($col_type, 'DOUBLE') !== false ||
             strpos($col_type, 'DECIMAL') !== false ||
             strpos($col_type, 'NUMERIC') !== false ||
             strpos($col_type, 'REAL') !== false)
    {
        if (!is_numeric($col_value) || ($is_type_unsigned && 0.0 > $col_value))
        {
            $type_msg = "'" . ($is_type_unsigned ? 'UNSIGNED ' : '') . "$col_type'";
        }
    }
    else if (strpos($col_type, 'BLOB') !== false ||
             strpos($col_type, 'BINARY') !== false)
    {
        // ok - do nothing
    }
    else
    {
        // unknown type // TODO: TBD: message??
    }

    return $type_msg;
}

function validate_length(&$col_info, &$col_type_detail, $col_value)
{
    $maxlength = '';

    $col_type = strtoupper($col_type_detail['type']);

    if (strpos($col_type, 'CHAR') !== false)
    {
        $length = strlen($col_value);

        if ($length > $col_type_detail['maxlength'])
        {
            $maxlength = $col_type_detail['maxlength'] . " (currently $length)";
        }
    }
    else
    {
        // ok - do nothing
    }

    return $maxlength;
}

////

function is_valid_empty(&$col_info)
{
    return preg_match('/^Y/i', $col_info['Null']) || $col_info['Default'] === '' ? true : false ;
}

function is_valid_date($y, $m, $d, $is_timestamp = false)
{
    return $y >= ($is_timestamp ? 1970 : 1000) &&
           $y <= ($is_timestamp ? 2037 : 9999) &&
           checkdate($m, $d, $y); // TODO: ASSUME: MySQL limits
}

function is_valid_year($y)
{
    return $y >= 1901 && $y <= 2155; // TODO: ASSUME: MySQL limits (approx)
}

function is_valid_time($h, $m, $s)
{
    return $h >= 0 && $h <= 23 &&
           $m >= 0 && $m <= 59 &&
           $s >= 0 && $s <= 59;
}

////

function get_value_range(&$col_info, &$col_type_detail)
{
    $value_range = null;

    if (!empty($col_info['Comment']))
    {
        $csv = explode(',', $col_info['Comment']);

        for ($i = 0; $i < count($csv); $i++)
        {
            if (preg_match('/([a-z]*) *= *([-]?[0-9]+(\.[0-9]*)?)/i', $csv[$i], $matches))
            {
                $n = strtoupper($matches[1]);
                $v = $matches[2];

                switch ($n)
                {
                case 'MIN':
                case 'MAX':
                    $value_range[$n] = $v;
                    break;
                default:
                    // unknown
                    break;
                }
            }
        }
    }

    return $value_range;
}

function validate_range(&$col_info, &$col_type_detail, $value)
{
    $range_msg = '';

    $value_range = get_value_range($col_info, $col_type_detail);

    // TODO: add support for !is_numeric($value)

    if (isset($value_range['MIN']) && $value < $value_range['MIN'])
    {
        $range_msg = "greater than or equal to '{$value_range['MIN']}'";
    }
    else if (isset($value_range['MAX']) && $value > $value_range['MAX'])
    {
        $range_msg = "less than or equal to '{$value_range['MAX']}'";
    }

    return $range_msg;
}

function validate_duplicate(&$col_info, &$col_type_detail, $value)
{
    $result = true;

    // TODO: not implemented

    return $result;
}

////

// this method is designed as VALIDATOR_PRIMARY
//
function validate_username_general(
    $col_name,
    $username,
    $display_name,
    &$col_vars,
    $table_name = null)
{
    global $g_action, $g_custom;

    $msg = '';

    if (empty($display_name) || !is_string($display_name))
    {
        $display_name = fmt_display_name($col_name);
    }

    if (empty($username))
    {
        $msg = "{$display_name} is required, please enter a value";
    }
    else if (preg_match('/[^a-z0-9_\.\-\@]+/i', $username) || $username != escape_sql_term($username))
    {
        $msg = "{$display_name} value contains disallowed characters";
    }
    else
    {
        if (empty($table_name) || !is_string($table_name))
        {
            if ($g_action->get_appid() == SYNAPP2) // support SynApp2 - Tools/Users
            {
                $table_name = UPW_STD_TABLE;
            }
            else
            {
                $table_name = $g_custom->get_table();
            }
        }

        $update_filter = $g_action->is_update() ? (" and " . $g_custom->get_pk_name($table_name) . " != '" . $g_action->get_pk() . "'") : '' ;

        if (get_dbx()->get_query_value("select count(*) from {$table_name} where {$col_name} = '{$username}'{$update_filter}"))
        {
            $msg = "{$display_name} value already exists";
        }
    }

    return $msg;
}

// this method is designed as VALIDATOR_PRIMARY
//
function validate_password_general(
    $col_name,
    $col_value,
    $display_name,
    &$col_vars,
    $password_action_col = null,
    $password_action_value = null,
    $password_function = null)
{
    global $g_action, $g_custom, $g_schema;

    $msg = '';

    if (empty($col_value))
    {
        // do nothing - empty value is ok
    }
    else if ($col_value != escape_sql_term($col_value))
    {
        $msg = "{$display_name} value contains disallowed characters";
    }
    else
    {
        if (empty($password_action_col) || !is_string($password_action_col))
        {
            $password_action_col = UPW_STD_COL_ACTION;
        }

        if (empty($password_action_value) || !is_string($password_action_value))
        {
            $password_action_value = UPW_STD_PROCESS_EXPR;
        }

        if (empty($password_function) || !is_string($password_function))
        {
            $password_function = UPW_STD_FUNC_ENCRYPT;
        }

        //// do processing, as needed (KLUGE: bends the rules of normally passive behavior for a validation function)

        $password_action = null;

        if ($g_action->get_appid() == SYNAPP2) // support SynApp2 - Tools/Users
        {
            $password_action = $g_action->m_process_args[$password_action_col]; // ASSUME: pseudo-column is a process arg
        }
        else
        {
            $password_action = $col_vars[$password_action_col]['v'];

            if ($default_password_action_value = $g_schema->find_col_info($g_custom->get_table(), $password_action_col, 'Default'))
            {
                $col_vars[$password_action_col]['v'] = $default_password_action_value; // ASSUME: pseudo-column is a col_var, keep it clamped to it's default value
            }
        }

        if (preg_match('/' . $password_action_value . '/i', $password_action))
        {
            $password_encrypted = get_dbx()->get_query_value("select {$password_function}('{$col_value}')");

            if (!empty($password_encrypted))
            {
                $col_vars[$col_name]['v'] = $password_encrypted; // stuff the computed hash value back into the col_var
            }
            else
            {
                $msg = "Unable to process {$display_name} value: {$password_function}('{$col_value}')";
            }
        }
    }

    return $msg;
}

////

?>
