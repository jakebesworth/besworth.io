<?php

/* dbx.php - SynApp2 simple database abstraction layer
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: dbx.php,v 1.14 2011/06/18 18:08:54 richard Exp $
*/

class dbx_base
{
    var $m_connection = null; // TODO: not implemented
    var $m_database = null; // TODO: not implemented

    var $m_connection_string = null;

    var $m_errors = null;
    var $m_error_dup = '';
    var $m_res_query = null;

    function dbx_base()
    {
    }

    function get_engine()
    {
        $engine = ENGINE_MYSQL;

        ////

        $engine_inc = get_config_dir() . 'engine.inc.php';

        if (file_exists($engine_inc))
        {
            include($engine_inc); // NOTE: use to redefine $engine (e.g. $engine = ENGINE_OCI;)
        }

        return $engine;
    }

    function set_connection_string($connection_string)
    {
        $this->m_connection_string = $connection_string;
    }

    function get_connection_string()
    {
        return $this->m_connection_string;
    }

    function put_error($e, $n = null)
    {
        if (!empty($n))
        {
            $this->m_errors[] = $n;
        }

        if (!empty($e))
        {
            $this->m_errors[] = $e;
        }
    }

    function get_errors()
    {
        return $this->m_errors;
    }

    function clear_errors()
    {
        $this->m_errors = null;
        $this->m_error_dup = '';
    }

    function get_error_dup()
    {
        return $this->m_error_dup;
    }

    function is_connected()
    {
        return $this->get_connection() != null;
    }

    function query($q)
    {
        $this->m_res_query = null;

        return $this->m_res_query != null;
    }

    function &get_query_records($q)
    {
        $result = null;

        if ($this->query($q))
        {
            while ($rec = $this->fetch_assoc())
            {
                $result[] = $rec;
            }
        }

        return $result;
    }

    function get_query_value($q)
    {
        $result = null;

        $recs = $this->get_query_records($q);

        if (!empty($recs) && count($recs[0]))
        {
            $result = current($recs[0]);
        }

        return $result;
    }

    function parse_date_value($date_value)
    {
        $ymd = array('y'=>0, 'm'=>0, 'd'=>0);

        if (!empty($date_value) && preg_match('/^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$/', $date_value))
        {
            list($ymd['y'], $ymd['m'], $ymd['d']) = sscanf($date_value, "%d-%d-%d");
        }

        return $ymd;
    }

    function get_insert_id_query($pk_name, $q)
    {
        return $q;
    }

    function get_keymap_table_query($q)
    {
        return $q;
    }

    function get_sql_calc_found_rows()
    {
        return '';
    }

    function format_regex_term($col_name, $regexp, $options = null)
    {
        return "dbx_base::format_regex_term() - needs implementation for database engine: " . $this->get_engine();
    }
};

////////

// PHP4 'static' members
//
$g_shared_mysql_connection = null;
$g_shared_mysql_database = null;

class mysql_dbx extends dbx_base
{
    function mysql_dbx()
    {
    }

    function connect($u, $p, $h)
    {
        global $g_shared_mysql_connection;
        global $g_shared_mysql_database;

        $result = false;

        $this->m_connection = null;
        $this->m_database = null;

        $g_shared_mysql_connection = null;
        $g_shared_mysql_database = null;

        if (!is_callable('mysql_connect'))
        {
            $this->put_error('connect() - MySQL driver not available');
        }
        else if (!($g_shared_mysql_connection = @mysql_connect($h, $u, $p)))
        {
            $this->put_error('connect() - connection failed');
            $this->put_error(mysql_error(), mysql_errno());
        }
        else
        {
            $result = true; // success
        }

        if ($result && get_charset_map()->get_charset_eng())
        {
            if (is_callable('mysql_set_charset'))
            {
                mysql_set_charset(get_charset_map()->get_charset_eng()); // PHP 5 >= 5.2.3
            }
            else
            {
                mysql_query('set names ' . get_charset_map()->get_charset_eng());
            }
        }

        return $result;
    }

    function get_connection()
    {
        global $g_shared_mysql_connection;

        return $this->m_connection ? $this->m_connection : $g_shared_mysql_connection;
    }

    function close()
    {
        return mysql_close($this->get_connection());
    }

    function is_shared_connection()
    {
        global $g_shared_mysql_connection;

        return empty($this->m_connection) && !empty($g_shared_mysql_connection);
    }

    function select_db($db_name)
    {
        global $g_shared_mysql_database;

        $this->m_database = null;

        if (!$this->is_connected())
        {
            $this->put_error('select_db() - not connected');
        }
        else if (!mysql_select_db($db_name, $this->get_connection()))
        {
            $this->put_error(mysql_error(), mysql_errno());
        }
        else
        {
            if ($this->is_shared_connection())
            {
                $g_shared_mysql_database = $db_name; // success
            }
            else
            {
                $this->m_database = $db_name; // success
            }
        }

        return $this->is_db_selected();
    }

    function is_db_selected()
    {
        global $g_shared_mysql_database;

        return !empty($this->m_database) || !empty($g_shared_mysql_database);
    }

    function escape_sql_term($term)
    {
        return is_string($term) ? mysql_real_escape_string($term) : $term ;
    }

    function query($q)
    {
        $result = false;

        parent::query($q);

        if (!$this->is_connected())
        {
            $this->put_error('query() - not connected');
        }
        else if (!$this->is_db_selected())
        {
            $this->put_error('query() - no database is selected');
        }
        else if (!($this->m_res_query = mysql_query($q)))
        {
            $errno = mysql_errno();

            if ($errno == 1062)
            {
                $this->m_error_dup = mysql_error();
            }
            else
            {
                $this->put_error('query() - ' . $q);
                $this->put_error(mysql_error(), $errno);
            }
        }
        else
        {
            $result = true; // success
        }

        return $result;
    }

    function fetch_assoc()
    {
        $result = null;

        if (empty($this->m_res_query))
        {
            $this->put_error('fetch_assoc() - empty resource');
        }
        else if ($this->m_res_query === true)
        {
            // query was ok - no records
        }
        else
        {
            $result = mysql_fetch_assoc($this->m_res_query);
        }

        return $result;
    }

    function get_table_names()
    {
        $table_names = null;

        if ($this->query('show tables'))
        {
            while ($recs = $this->fetch_assoc())
            {
                $table_names[] = current($recs);
            }
        }

        return $table_names;
    }

    function get_col_info($table_name)
    {
        $col_info = null;

        if ($this->query("show full columns from $table_name"))
        {
            while ($recs = $this->fetch_assoc())
            {
                $col_info[] = $recs;
            }
        }

        return $col_info;
    }

    function get_datepicker_format()
    {
        return 'YYYY-MM-DD';
    }

    function parse_date_value($date_value)
    {
        return dbx_base::parse_date_value($date_value);
    }

    function get_limited_query($q, $limit, $offset)
    {
        $row_l = 1 + $offset;      // row - lower limit
        $row_u = $offset + $limit; // row - upper limit
        $limit_expr = $limit ? " where a1._row_no_ between $row_l and $row_u" : '' ;

        return
"
select * from
(
select @rownum:=@rownum+1 as _row_no_, a2.* from (select @rownum:=0) as a3,
(
$q
) as a2
) as a1{$limit_expr}
";
    }

    function get_insert_offset_query($pk_name, $id, $q)
    {
        return
"
select * from
(
    select @rownum:=@rownum+1 as _row_no_, {$pk_name} from (select @rownum:=0) as a3,
    (
        $q
    ) as a2
) as a1
where a1.{$pk_name} = '$id'
";
    }

    function get_create_keymap_table_query()
    {
        return
"
CREATE TABLE ". KEYMAP . " (
  id int(10) unsigned NOT NULL auto_increment,
  table_name varchar(32) NOT NULL,
  col_name varchar(32) NOT NULL,
  join_table varchar(32) NOT NULL,
  join_col varchar(32) NOT NULL,
  PRIMARY KEY  (id)
);
";
    }

    function create_keymap_table()
    {
        $this->query($this->get_create_keymap_table_query());
    }

    function get_sql_calc_found_rows()
    {
        return 'SQL_CALC_FOUND_ROWS ';
    }

    function insert_id()
    {
        return mysql_insert_id();
    }

    function affected_rows()
    {
        return mysql_affected_rows();
    }

    function format_regex_term($col_name, $regexp, $options = null)
    {
        return "{$col_name} regexp '{$regexp}'";
    }
};

////////

// PHP4 'static' members
//
$g_shared_oci_connection = null;
$g_shared_oci_database = null;

class oci_dbx extends dbx_base
{
    var $m_insert_id = null;

    function oci_dbx()
    {
        $this->m_connection_string = '/XE'; // DEFAULT: Express Edition, SEE: http://php.net/manual/en/function.oci-connect.php
    }

    function connect($u, $p, $h)
    {
        global $g_shared_oci_connection;
        global $g_shared_oci_database;

        $result = false;

        $this->m_connection = null;
        $this->m_database = null;

        $g_shared_oci_connection = null;
        $g_shared_oci_database = null;

        if (!is_callable('oci_connect'))
        {
            $this->put_error('connect() - oci driver not available');
        }
        else if (!($g_shared_oci_connection = (get_charset_map()->get_charset_eng() ?
                                               @oci_connect($u, $p, "{$h}{$this->m_connection_string}", get_charset_map()->get_charset_eng()) :
                                               @oci_connect($u, $p, "{$h}{$this->m_connection_string}"))))
        {
            $this->put_error('connect() - connection failed');
            $this->put_error($this->get_message(oci_error()));
        }
        else
        {
            $g_shared_oci_database = $u;
            $result = true; // success
        }

        return $result;
    }

    function get_connection()
    {
        global $g_shared_oci_connection;

        return $this->m_connection ? $this->m_connection : $g_shared_oci_connection;
    }

    function close()
    {
        return oci_close($this->get_connection());
    }

    function get_message($e)
    {
        return isset($e['message']) ? $e['message'] : '' ;
    }

    function is_shared_connection()
    {
        global $g_shared_oci_connection;

        return empty($this->m_connection) && !empty($g_shared_oci_connection);
    }

    function select_db($db_name)
    {
        global $g_shared_oci_database;

        return $this->get_connection() != null && !empty($db_name) && ($this->m_database == $db_name || $g_shared_oci_database == $db_name);
    }

    function is_db_selected()
    {
        global $g_shared_oci_database;

        return !empty($this->m_database) || !empty($g_shared_oci_database);
    }

    function escape_sql_term($term)
    {
        return is_string($term) ? str_replace("'", "''", $term) : $term ;
    }

    function query($q)
    {
        $result = false;

        parent::query($q);

        if (!$this->is_connected())
        {
            $this->put_error('query() - not connected');
        }
        else if (!$this->is_db_selected())
        {
            $this->put_error('query() - no database is selected');
        }
        else if (!($this->m_res_query = ociparse($this->get_connection(), $q)))
        {
            $this->put_error($this->get_message(oci_error($this->get_connection())));
        }
        else if (!$this->bind_execute())
        {
            $e = oci_error($this->m_res_query);

            if (isset($e['code']) && $e['code'] == 1)
            {
                $this->m_error_dup = $this->get_message($e);
            }
            else
            {
                $this->put_error($this->get_message($e));
            }

            $this->m_res_query = null;
        }
        else if (!ocicommit($this->get_connection()))
        {
            $this->put_error($this->get_message(oci_error($this->get_connection())));
        }
        else
        {
            $result = true; // success
        }

        return $result;
    }

    function bind_execute()
    {
        if ($this->m_insert_id)
        {
            $this->m_insert_id = (int)0; // re-init to numeric (int) value
            @oci_bind_by_name($this->m_res_query, ":insert_id", $this->m_insert_id, -1, SQLT_INT); // TBD: Warning ORA-01036: ??
        }

        return @ociexecute($this->m_res_query, OCI_DEFAULT);
    }

    function fetch_assoc()
    {
        $a = null;

        if (!empty($this->m_res_query) && oci_statement_type($this->m_res_query) == 'SELECT')
        {
            $a = @oci_fetch_assoc($this->m_res_query);
        }

        return $a;
    }

    function get_table_names()
    {
        $table_names = null;

        if ($this->query('select table_name from user_tables'))
        {
            while ($recs = $this->fetch_assoc())
            {
                $table_names[] = current($recs);
            }
        }

        return $table_names;
    }

    function get_col_info($table_name)
    {
        $col_info = null;

        // NOTE: SQL>COMMENT ON COLUMN myTableName.myColumnName IS 'foo'

        $q = "select USER_TAB_COLUMNS.*, USER_COL_COMMENTS.COMMENTS, USER_CONS_COLUMNS.COLUMN_NAME as PRI
              from USER_TAB_COLUMNS
              left join USER_COL_COMMENTS on USER_COL_COMMENTS.TABLE_NAME = USER_TAB_COLUMNS.TABLE_NAME and
                                             USER_COL_COMMENTS.COLUMN_NAME = USER_TAB_COLUMNS.COLUMN_NAME
              left join USER_CONSTRAINTS on USER_CONSTRAINTS.TABLE_NAME = USER_TAB_COLUMNS.TABLE_NAME and
                                            USER_CONSTRAINTS.CONSTRAINT_TYPE = 'P'
              left join USER_CONS_COLUMNS on USER_CONS_COLUMNS.TABLE_NAME = USER_TAB_COLUMNS.TABLE_NAME and
                                             USER_CONS_COLUMNS.CONSTRAINT_NAME = USER_CONSTRAINTS.CONSTRAINT_NAME and
                                             USER_CONS_COLUMNS.COLUMN_NAME = USER_TAB_COLUMNS.COLUMN_NAME
              where USER_TAB_COLUMNS.TABLE_NAME = '$table_name'
              order by USER_TAB_COLUMNS.COLUMN_ID";

        if ($this->query($q))
        {
            while ($rec = $this->fetch_assoc())
            {
                $data_type = null;

                if (preg_match('/^TIMESTAMP\(/', $rec['DATA_TYPE']))
                {
                    $rec['DATA_TYPE'] = 'TIMESTAMP'; // clip - e.g. (6)
                }

                switch ($rec['DATA_TYPE'])
                {
                case 'INTEGER':
                case 'NUMERIC':
                case 'NUMBER':
                    $f = !empty($rec['DATA_SCALE']) || $rec['DATA_SCALE'] == '0' ? $rec['DATA_SCALE'] : '' ; // fractional part
                    $w = !empty($rec['DATA_PRECISION']) ? $rec['DATA_PRECISION'] - $f : $rec['DATA_LENGTH'] ; // whole part
                    if ($f == '0')
                    {
                        $data_type = "INTEGER({$w})";
                    }
                    else if ($f != '')
                    {
                        $data_type = "DECIMAL({$w},{$f})";
                    }
                    else
                    {
                        $data_type = "FLOAT";
                    }
                    break;
                case 'CHAR':
                case 'VARCHAR':
                case 'VARCHAR2':
                    $data_type = "CHAR({$rec['DATA_LENGTH']})";
                    break;
                case 'DATE':
                case 'TIMESTAMP': // NOTE: SQL>default SYSTIMESTAMP not null
                    $data_type = $rec['DATA_TYPE'];
                    break;
                default:
                    // ok - ignore
                    break;
                }

                if ($data_type)
                {
                    $info = array(
                                'Field' => $rec['COLUMN_NAME'],
                                'Type' => $data_type,
                                'Collation' => '',
                                'Null' => ($rec['NULLABLE'] == 'Y' ? 'YES' : 'NO'),
                                'Key' => $rec['PRI'] == $rec['COLUMN_NAME'] ? 'PRI' : '',
                                'Default' => $rec['DATA_DEFAULT'], // NULL is ok
                                'Extra' => '',
                                'Privileges' => '',
                                'Comment' => !is_null($rec['COMMENTS']) ? $rec['COMMENTS'] : ''
                                );

                    $col_info[] = $info;
                }
            }
        }

        return $col_info;
    }

    function get_datepicker_format()
    {
        return 'DD-MON-YY';
    }

    function parse_date_value($date_value)
    {
        $ymd = array('y'=>0, 'm'=>0, 'd'=>0);

        if (!empty($date_value) && preg_match('/^[0-9]{1,2}-[a-zA-Z]{3}-[0-9]{1,2}$/', $date_value))
        {
            $qconvert = "select to_char(to_date('" . $date_value . "', '" . $this->get_datepicker_format() . "'), 'YYYY-MM-DD') from dual";
            $dbx = new oci_dbx();
            $ymd = dbx_base::parse_date_value($dbx->get_query_value($qconvert));
        }

        return $ymd;
    }

    function get_limited_query($q, $limit, $offset)
    {
        $row_l = 1 + $offset;      // row - lower limit
        $row_u = $offset + $limit; // row - upper limit
        $limit_expr = $limit ? " where a1.\"_row_no_\" between $row_l and $row_u" : '' ;

        return
"
select * from
(
select rownum as \"_row_no_\", a2.* from
(
$q
) a2
) a1{$limit_expr}
";
    }

    function get_insert_id_query($pk_name, $q)
    {
        $this->m_insert_id = $pk_name;
        return "{$q} returning $pk_name into :insert_id";
    }

    function get_insert_offset_query($pk_name, $id, $q)
    {
        return
"
select * from
(
    select rownum as \"_row_no_\", {$pk_name} from
    (
        $q
    ) a2
) a1
where a1.{$pk_name} = '$id'
";
    }

    function get_keymap_table_query($q)
    {
        return str_replace(KEYMAP, ('"' . KEYMAP . '"'), $q);
    }

    function get_create_keymap_table_query()
    {
        return
"
CREATE TABLE \"" . KEYMAP . "\" (
  id NUMBER(10,0) NOT NULL,
  table_name VARCHAR2(32) NOT NULL,
  col_name VARCHAR2(32) NOT NULL,
  join_table VARCHAR2(32) NOT NULL,
  join_col VARCHAR2(32) NOT NULL,
  PRIMARY KEY (id)
)
";
    }

    function get_create_keymap_sequence_query()
    {
        return 'create sequence "' . KEYMAP . '_SEQ"';
    }

    function get_create_keymap_trigger_query()
    {
        return 'create trigger "BI_' . KEYMAP . '" before insert on "' . KEYMAP . '" for each row begin select "' . KEYMAP . '_SEQ".nextval into :NEW.id from dual; end;';
    }

    function create_keymap_table()
    {
        $this->query($this->get_create_keymap_table_query());
        $this->query($this->get_create_keymap_sequence_query());
        $this->query($this->get_create_keymap_trigger_query());
    }

    function insert_id()
    {
        return $this->m_insert_id;
    }

    function affected_rows()
    {
        $result = 0;

        if (is_callable('oci_num_rows'))
        {
            $result = oci_num_rows($this->m_res_query); // >= PHP5
        }
        else
        {
            $result = ocirowcount($this->m_res_query); // PHP4
        }

        return $result;
    }

    function format_regex_term($col_name, $regexp, $options = null)
    {
        return "regexp_like({$col_name}, '{$regexp}')";
    }
};

////

define('ENGINE_MYSQL', '_mysql_');
define('ENGINE_OCI', '_oci_');

function &new_dbx($engine)
{
    $dbx = null;

    switch ($engine)
    {
    case ENGINE_MYSQL:
        $dbx = new mysql_dbx();
        break;
    case ENGINE_OCI:
        $dbx = new oci_dbx();
        break;
    default:
        // trigger_error(); // unknown/unsupported database $engine
    }

    return $dbx;
}

////

?>
