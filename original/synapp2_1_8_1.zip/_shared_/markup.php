<?php

/* markup.php - SynApp2 markup language generator
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: markup.php,v 1.46 2011/06/18 18:05:57 richard Exp $
*/

class markup
{
    var $m_action = null;
    var $m_dbx = null;
    var $m_custom = null;
    var $m_schema = null;

    // intermediate buffers
    //
    var $m_CSS = array(); // view style elements
    var $m_VML = array(); // view markup language elements
    var $m_RPT = array(); // view markup report filter/constraint elements (fform)
    var $m_IML = array(); // view markup language elements (iform)
    var $m_TML = array(); // view markup language elements (tform)
    var $m_XCH = array(); // view exchange objects
    var $m_MAP = array(); // view element id maps
    var $m_OVL = array(); // view form overlay elements
    var $m_INC = array(); // inc file elements

    var $m_fk_info = array();
    var $m_caption_info = array();

    // final output buffers
    //
    var $m_ADH = array(); // adhoc elements
    var $m_ADF = array(); // adhoc validation feedback elements
    var $m_IDD = array(); // drag 'n drop item id's
    var $m_TDD = array(); // drag 'n drop target id's

    ////

    // TODO: refactor into a class
    //
    var $m_sources = array();
    var $m_attributes = array();
    var $m_activity = array(); // TODO: not used

    function reset_sources_attributes_activity()
    {
        $this->m_sources = array();
        $this->m_attributes = array();
        $this->m_activity = array();
    }

    function set_attribute($k, $n, $v = null)
    {
        if (!empty($k) && in_array($n, array('is_raw', 'is_protected')))
        {
            if (!isset($this->m_attributes[$k]))
            {
                $this->m_attributes[$k] = array('is_raw'=>false, 'is_protected'=>false);
            }
        }

        $this->m_attributes[$k][$n] = isset($v); // add support for more value types as needed
    }

    function get_attribute($k, $n)
    {
        return isset($this->m_attributes[$k][$n]) ? $this->m_attributes[$k][$n] : null ;
    }

    function get_source($k)
    {
        return isset($this->m_sources[$k]) ? $this->m_sources[$k] : null ;
    }

    function set_source($k, $expr, &$activity, $alternate_appid = null)
    {
        $appid = $alternate_appid ? $alternate_appid : $this->get_active_appid() ;

        if ($k &&
            ((!empty($expr) && !isset($this->m_sources[$k])) ||
             (isset($this->m_sources[$k]) && $this->m_sources[$k] != $expr)))
        {
            $this->set_attribute($k, 'is_raw', true);
            $this->m_sources[$k] = $expr;
            eval('$this->m_custom->m_data' . "[APPID]['{$appid}']" .  $k . ' = "place_holder";');
            $activity[$k] = $expr; // $this->m_sources[$k] = $expr; // TODO:
        }
    }

    function get_protected_value($custom_get_value, &$is_protected)
    {
        $is_protected = $this->get_attribute($this->m_custom->get_last_key(), 'is_protected');

        return $custom_get_value;
    }

    ////

    function markup(&$action, &$dbx, &$custom, &$schema, $active = false)
    {
        $this->m_action = &$action;
        $this->m_dbx = &$dbx;
        $this->m_custom = &$custom;
        $this->m_schema = &$schema;

        if ($active)
        {
            $this->build();
        }
    }

    function is_synapp2()
    {
        return strtolower($this->m_action->get_appid()) == SYNAPP2;
    }

    function get_active_appid()
    {
        $active_appid = null;

        if (!$this->is_synapp2() && $this->m_dbx->is_db_selected())
        {
            $active_appid = $this->m_action->get_appid();
        }

        return $active_appid;
    }

    function get_active_qid()
    {
        $active_qid = null;

        $qid = $this->m_action->get_col_var('active_tab_name');

        if ($map = $this->get_qid_table_names_map())
        {
            $active_qid = isset($map[$qid]) ? $qid : key($map) ; // default to first
        }

        return $active_qid;
    }

    function get_qid_table_names_map()
    {
        $qid_table_names_map = null;

        if (($table_names = $this->m_schema->get_table_names()) && !empty($table_names))
        {
            foreach ($table_names as $table_name)
            {
                if (!$this->m_schema->is_sys_table($table_name)) // TODO: TBD: provide additional control here??
                {
                    $qid_table_names_map[$table_name] = $table_name;
                }
            }
        }

        if ($qid_table_names = $this->m_custom->get_qid_table_names())
        {
            foreach ($qid_table_names as $qid => $table_name)
            {
                $qid_table_names_map[$qid] = $table_name;
            }
        }

        return $qid_table_names_map;
    }

    function reset_intermediate_buffers()
    {
        $this->m_CSS = array();
        $this->m_VML = array();
        $this->m_RPT = array();
        $this->m_IML = array();
        $this->m_TML = array();
        $this->m_XCH = array();
        $this->m_MAP = array();
        $this->m_OVL = array();
        $this->m_INC = array();

        $this->m_fk_info = array();
        $this->m_caption_info = array();
    }

    function build()
    {
        if ($this->m_action->is_adhoc())
        {
            if ($this->m_action->get_qid() == '_app_nav_')
            {
                $this->app_nav_gen($this->m_action->get_appid(),
                                   $this->m_action->get_pid(),
                                   $this->m_action->get_rid(),
                                   $this->m_action->get_col_var('document_pathname'),
                                   $this->m_schema->get_table_names());
            }
            else if ($this->m_action->get_qid() == '_sub_nav_')
            {
                $this->sub_nav_gen($this->m_action->get_appid(),
                                   $this->m_action->get_pid(),
                                   $this->m_action->get_col_var('_sub_nav_options_'),
                                   $this->m_action->get_col_var('_sub_nav_active_'),
                                   $this->m_action->get_col_var('_sub_nav_callback_'),
                                   $this->m_action->get_col_var('_sub_nav_style_'));
            }
            else if ($this->m_custom->is_auth_appid_username(login_username(), SYNAPP2))
            {
                if (preg_match('/^_keymap_(process|show)_/', $this->m_action->get_qid()))
                {
                    $this->nav_handler_keymap($this->get_active_appid(), $this->get_active_qid());
                }
                else if (preg_match('/^_options(_process_|_show_)(.*)_$/', $this->m_action->get_qid(), $qid_tokens))
                {
                    $this->nav_handler_options($this->get_active_appid(), $this->get_active_qid(), $qid_tokens);
                }
                else if (preg_match('/^_pagegen_(process|show)_/', $this->m_action->get_qid()))
                {
                    $this->nav_handler_pagegen($this->get_active_appid(), $this->get_active_qid());
                }
                else if (preg_match('/^_tools(_process_|_show_)(.*)_$/', $this->m_action->get_qid(), $qid_tokens))
                {
                    $this->nav_handler_tools($this->m_action->get_appid(), $qid_tokens);
                }
            }
        }
    }

    ////

    function app_nav_gen($appid, $pid, $rid, $document_pathname, $table_names)
    {
        if (!empty($appid) && !empty($pid) && !empty($document_pathname))
        {
            $appdir = "../{$appid}/"; // TODO: configurable
            $shared = "../_shared_/"; // TODO: configurable
            $file_ext = '.htm'; // TODO: configurable

            $nav_tab_info = $this->m_custom->get_nav_incl_tabs();

            $tab_names = array_merge($table_names, array_keys($nav_tab_info));

            if ($qid_table_names = $this->m_custom->get_qid_table_names())
            {
                $tab_names = array_merge($tab_names, array_keys($qid_table_names));
            }

            $tab_names_iter = $this->m_custom->get_nav_tab_order_map($tab_names);

            $active_tab_name = basename($document_pathname);

            if (!empty($tab_names_iter))
            {
                $lines_nav = array();

                $lines_nav[] = "<ul id=\"nav\">";

                foreach ($tab_names_iter as $tab_name)
                {
                    $tab_info = isset($nav_tab_info[$tab_name]) ? $nav_tab_info[$tab_name] : $tab_name ;
                    $tab_href = is_array($tab_info) ? $tab_info[A_HREF] : $tab_info ;
                    $tab_text = is_array($tab_info) ? $tab_info[A_TEXT] : fmt_display_name($tab_href, false) ;

                    if ($this->m_schema->is_sys_table($tab_href) ||
                        $this->m_custom->is_nav_omit_tab($tab_href, $appid) ||
                        !$this->m_custom->is_auth_pid_username($tab_href, login_username()) ||
                        !file_exists("{$appdir}{$tab_href}{$file_ext}"))
                    {
                        continue;
                    }

                    $class_nav_state = ($tab_href . $file_ext == $active_tab_name) ? ' class="class_nav_active"' : ' class="class_nav_inactive"';

                    $lines_nav[] = "<li id=\"id__nav__{$tab_href}\"><a href=\"{$appdir}{$tab_href}{$file_ext}\"{$class_nav_state}>{$tab_text}</a></li>";
                }

                if ($this->m_custom->is_auth_pid_username('reports', login_username()))
                {
                    $class_nav_state = ($pid == 'reports') ? ' class="class_nav_active"' : ' class="class_nav_inactive"';

                    $lines_nav[] = "<li id=\"id__nav__reports\"><a href=\"{$shared}reports{$file_ext}?appid={$appid}\"{$class_nav_state}>Reports</a></li>";
                }

                $lines_nav[] = "<li id=\"id__nav__logout\"><a href=\"{$shared}logout.htm?appid={$appid}\" class=\"class_nav_inactive\">Logout</a></li>";

                $lines_nav[] = "</ul>";

                foreach ($lines_nav as $line)
                {
                    $this->m_ADH[] = $line;
                }

                ////

                if ($pid == 'reports')
                {
                    $lines_rpt = array();

                    $rpt_tab_info = $this->m_custom->get_rpt_incl_tabs();
                    $tab_names = array_merge($table_names, array_keys($rpt_tab_info));

                    if ($qid_table_names = $this->m_custom->get_qid_table_names())
                    {
                        $tab_names = array_merge($tab_names, array_keys($qid_table_names));
                    }

                    $tab_names_iter = $this->m_custom->get_rpt_tab_order_map($tab_names);

                    if (!empty($tab_names_iter))
                    {
                        $lines_rpt[] = "<ul id=\"rpt\">";

                        foreach ($tab_names_iter as $tab_name)
                        {
                            if ($this->m_schema->is_sys_table($tab_name) ||
                                $this->m_custom->is_rpt_omit_tab($tab_name, $appid) ||
                                !$this->m_custom->is_auth_rid_username($tab_name, login_username()) ||
                                !file_exists("{$appdir}{$tab_name}.report{$file_ext}"))
                            {
                                continue;
                            }

                            $class_rpt_state = ($rid == $tab_name) ? ' class="class_rpt_active"' : ' class="class_rpt_inactive"';

                            $tab_text = fmt_display_name($tab_name, false);

                            $lines_rpt[] = "<li id=\"id__rpt__{$tab_name}\"><a href=\"{$shared}reports{$file_ext}?appid={$appid}&amp;reportid={$tab_name}\"{$class_rpt_state}>{$tab_text}</a></li>";
                        }

                        $lines_rpt[] = "</ul>";
                    }

                    foreach ($lines_rpt as $line)
                    {
                        $this->m_ADH[] = $line;
                    }
                }
            }
        }
    }

    function sub_nav_omit($token)
    {
        $result = false;

        if (!$this->get_active_appid() && !preg_match('/^(users)$/i', $token)) // MAGIC:
        {
            $result = true;
        }

        return $result;
    }

    function sub_nav_gen($appid, $pid, $sub_nav_options, $sub_nav_active, $sub_nav_callback, $sub_nav_style = 'select')
    {
        if (!empty($appid) && !empty($pid))
        {
            $select_name = "{$pid}_sub_nav_options"; // name not used to submit selected value

            ////

            if (empty($sub_nav_options))
            {
                $sub_nav_options = null;

                if ($this->m_custom->is_auth_appid_username(login_username(), SYNAPP2) && $this->get_active_appid() && ($table_names = $this->m_schema->get_table_names()) && !empty($table_names))
                {
                    foreach ($table_names as $table_name)
                    {
                        if (!$this->m_schema->is_sys_table($table_name)) // TODO: TBD: provide additional control here??
                        {
                            $sub_nav_options[$table_name] = $table_name;
                        }
                    }

                    if ($qid_table_names = $this->m_custom->get_qid_table_names())
                    {
                        foreach ($qid_table_names as $qid => $table_name)
                        {
                            $sub_nav_options[$qid] = "{$qid} ({$table_name})";
                        }
                    }
                }
            }
            else
            {
                $tokens = is_string($sub_nav_options) && !empty($sub_nav_options) ? explode_csv($sub_nav_options) : null ;

                $sub_nav_options = null;

                if (!empty($tokens))
                {
                    foreach ($tokens as $token)
                    {
                        if (!$this->sub_nav_omit($token))
                        {
                            $sub_nav_options[$token] = $token;
                        }
                    }
                }
            }

            ////

            if (!empty($sub_nav_options) && !empty($sub_nav_callback))
            {
                $tabs = $sub_nav_options;

                if (!empty($tabs))
                {
                    $lines_nav = array();

                    switch ($sub_nav_style)
                    {
                    default:
                    case 'select':
                        $lines_nav[] = "<select name=\"{$select_name}\" onchange=\"{$sub_nav_callback}(this.value);\">";
                        break;
                    case 'ul':
                        $lines_nav[] = "<ul id=\"rpt\">"; // TODO: need id value
                        break;
                    }

                    if (!isset($sub_nav_options[$sub_nav_active]))
                    {
                        $sub_nav_active = null;
                    }

                    foreach ($tabs as $tab_value => $tab_text)
                    {
                        if (empty($sub_nav_active))
                        {
                            $sub_nav_active = $tab_value;
                        }

                        switch ($sub_nav_style)
                        {
                        default:
                        case 'select':
                            $select_state = ($tab_value == $sub_nav_active) ? ' selected="selected" ' : ' ';
                            $lines_nav[] = "<option value=\"{$tab_value}\"{$select_state} />{$tab_text}";
                            break;
                        case 'ul':
                            $class_nav_state = ($tab_value == $sub_nav_active) ? ' class="class_rpt_active"' : ' class="class_rpt_inactive"';
                            $lines_nav[] = "<li><a href=\"#\" onclick=\"{$sub_nav_callback}('{$tab_value}');\"{$class_nav_state}>{$tab_text}</a></li>";
                            break;
                        }
                    }

                    switch ($sub_nav_style)
                    {
                    default:
                    case 'select':
                        $lines_nav[] = "</select>";
                        break;
                    case 'ul':
                        $lines_nav[] = "</ul>";
                        break;
                    }

                    foreach ($lines_nav as $line)
                    {
                        $this->m_ADH[] = $line;
                    }
                }
            }
            else
            {
                $this->m_ADH[] = $sub_nav_style == 'select' ? "<select name=\"{$select_name}\"><option value=\"\" />-- no information --</select>" : '' ;
            }
        }
        else
        {
            $this->m_ADH[] = '';
        }
    }

    ////

    function nav_handler_keymap($appid, $qid)
    {
        if ($this->m_action->get_qid() == '_keymap_process_')
        {
            $this->keymap_process($appid, $qid);
        }

        $this->keymap_show($appid, $qid, $this->m_ADH);
    }

    function fkey_options($table_name, &$keys_info, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $elements[] = "<option value=\"\" />";

        $join_tables = array_keys($keys_info); // support nested iteration of $keys_info via reference (TDB: pass by value may be better??)

        foreach ($join_tables as $join_table)
        {
            if ($join_table != $table_name)
            {
                $table_key_info = $keys_info[$join_table]; // this, hopefully, leaves current($keys_info) unchanged

                foreach ($table_key_info as $key_info)
                {
                    if ($key_info['is_pk'] && $key_info[JOIN_TABLE] != $table_name)
                    {
                        $elements[] = "<option value=\"{$key_info[JOIN_TABLE]}.{$key_info[JOIN_COL]}\" />{$key_info[JOIN_TABLE]}.{$key_info[JOIN_COL]}";
                        break;
                    }
                }
            }
        }

        $elements[] = "<option value=\"delete\" /> -- delete -- ";
    }

    function keymap_show($appid, $qid, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        if (!empty($appid) &&
            !empty($qid) &&
            ($basis_table = $this->m_custom->get_table($qid)) &&
            in_array($basis_table, $this->m_schema->get_table_names()) &&
            ($keys_info = $this->m_schema->get_keys_info()) &&
            !empty($keys_info[$basis_table]))
        {
            $elements[] = "<div class=\"class_keymap\">";
            $elements[] = "<table id=\"id_table_{$basis_table}\" cellspacing=\"0\">";
            $elements[] = "<thead>";
            $elements[] = "<tr><th class=\"class_keymap_table_name\" colspan=\"4\"><strong>" . $this->m_custom->get_database($appid) . ".{$basis_table}</strong></th></tr>";
            $elements[] = "<tr><th></th><th>Col Name</th><th>Join Table</th><th>Join Col</th></tr>";
            $elements[] = "</thead>";
            $elements[] = "<tbody>";

            $fk_count = 0;

            foreach ($keys_info[$basis_table] as $key_info)
            {
                if ($key_info['is_pk'])
                {
                    $key_tag = ' (PK)';
                    $elements[] = "<tr><td></td><td>{$key_info[COL_NAME]}$key_tag</td><td>{$key_info[JOIN_TABLE]}</td><td>{$key_info[JOIN_COL]}</td></tr>";
                }
                else
                {
                    $key_tag = !empty($key_info[JOIN_TABLE]) ? ' (FK' . (++$fk_count) . ')' : '' ;
                    $elements[] = "<tr><td><input type=\"radio\" name=\"_fkey_\" value=\"{$key_info[TABLE_NAME]}.{$key_info[COL_NAME]}\" /></td><td>{$key_info[COL_NAME]}$key_tag</td><td>{$key_info[JOIN_TABLE]}</td><td>{$key_info[JOIN_COL]}</td></tr>";
                }
            }

            $elements[] = "</tbody>";
            $elements[] = "<tfoot>";
            $elements[] = "<tr><th></th><th></th><th class=\"class_keymap_select\" colspan=\"2\">";
            $elements[] = "<select name=\"_jkey_$basis_table\" title=\"Select &lt;JoinTable.JoinCol&gt;\" onchange=\"submit_keymap();\">";

            $this->fkey_options($basis_table, $keys_info, $elements);

            $elements[] = "</select>";
            $elements[] = "</th></tr>";
            $elements[] = "</tfoot>";
            $elements[] = "</table>";
            $elements[] = "</div>";
        }
        else
        {
            $elements[] = '';
        }
    }

    function keymap_process($appid, $qid)
    {
        if (!empty($appid) &&
            !empty($qid) &&
            ($_fkey_ = $this->m_action->get_col_var('_fkey_')))
        {
            list($table_name, $col_name) = explode('.', $_fkey_);

            if (($_jkey_ = $this->m_action->get_col_var("_jkey_$table_name")) !== false)
            {
                assert('!empty($table_name)');
                assert('!empty($col_name)');

                if (!empty($table_name) && !empty($table_name) && !empty($_jkey_))
                {
                    $affected_rows = 0;

                    if ($_jkey_ == 'delete')
                    {
                        if ($this->m_schema->is_table_present(KEYMAP))
                        {
                            $q = $this->m_dbx->get_keymap_table_query("delete from " . KEYMAP . " where table_name='$table_name' and col_name='$col_name'");
                            $this->m_dbx->query($q);
                            $affected_rows = $this->m_dbx->affected_rows();
                        }
                    }
                    else
                    {
                        list($join_table, $join_col) = explode('.', $_jkey_);

                        assert('!empty($join_table)');
                        assert('!empty($join_col)');

                        if (!empty($join_table) && !empty($join_col))
                        {
                            if (!$this->m_schema->is_table_present(KEYMAP))
                            {
                                $this->m_dbx->create_keymap_table();
                            }
                            else
                            {
                                $q = $this->m_dbx->get_keymap_table_query("update " . KEYMAP . " set join_table='$join_table', join_col='$join_col' where table_name='$table_name' and col_name='$col_name'");
                                $this->m_dbx->query($q);
                                $affected_rows = $this->m_dbx->affected_rows();
                            }

                            if ($affected_rows < 1)
                            {
                                $q = $this->m_dbx->get_keymap_table_query("insert into " . KEYMAP . " (table_name, col_name, join_table, join_col) values ('$table_name', '$col_name', '$join_table', '$join_col')");
                                $this->m_dbx->query($q);
                                $affected_rows = $this->m_dbx->affected_rows();
                                assert('$affected_rows == 1');
                            }
                        }
                    }
                }
            }
        }
    }

    function nav_handler_options($active_appid, $active_qid, $argv)
    {
        if (!empty($active_appid) &&
            !empty($active_qid) &&
            is_array($argv) &&
            count($argv) == 3)
        {
            list($request_qid, $action, $form) = $argv;

            $validator = '';
            $processor = '';

            if ($action == '_process_')
            {
                $processor = 'options_process_' . $form;

                ////

                $pfx = 'options_validate_';
                $sfx = 'general';

                switch ($form) // deal with a few special cases
                {
                case 'display':
                    $sfx = 'display';
                    break;
                case 'extra':
                    $sfx = 'extra';
                    break;
                case 'reporting':
                    $sfx = 'reporting_title';
                    break;
                default:
                    break;
                }

                $validator = $pfx . $sfx;
            }

            $this->inc_sources($active_appid);

            $items_changed = null;

            if ($processor && (!$validator || call_user_func(array($this, $validator))))
            {
                $activity = null;
                call_user_func_array(array($this, $processor), array($active_qid, &$activity));
                $items_changed = $activity ? count($activity) : 0 ;
                $this->inc_gen($active_appid, $activity);
            }

            call_user_func_array(array($this, "options_show_{$form}"), array($active_qid, $items_changed, &$this->m_ADH));
        }
        else
        {
            $this->m_ADH[] = '';
        }
    }

    ////

    function get_options_SFORM($qid, $col_name)
    {
        $id = "{$qid}__SFORM__{$col_name}";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Omit:</label>" . $this->get_element_select("{$id}__COL_OMIT", $this->get_protected_value($this->m_custom->get_col_option($qid, SFORM, $col_name, COL_OMIT), $is_protected), array('0'=>'No', '1'=>'Yes'), $is_protected) . '<br />';
        $markup .= "<label>Size:</label>" . $this->get_element_input_text("{$id}__COL_SIZE", $this->get_protected_value($this->m_custom->get_col_option($qid, SFORM, $col_name, COL_SIZE), $is_protected), $is_protected) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_DFORM($qid, $col_name)
    {
        $id = "{$qid}__DFORM__{$col_name}";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Omit:</label>" . $this->get_element_select("{$id}__COL_OMIT", $this->get_protected_value($this->m_custom->get_col_option($qid, DFORM, $col_name, COL_OMIT), $is_protected), array('0'=>'No', '1'=>'Yes'), $is_protected) . '<br />';
        $markup .= "<label>Size:</label>" . $this->get_element_input_text("{$id}__COL_SIZE", $this->get_protected_value($this->m_custom->get_col_option($qid, DFORM, $col_name, COL_SIZE), $is_protected), $is_protected) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_TFORM($qid, $col_name)
    {
        $id = "{$qid}__TFORM__{$col_name}";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Omit:</label>" . $this->get_element_select("{$id}__COL_OMIT", $this->get_protected_value($this->m_custom->get_col_option($qid, TFORM, $col_name, COL_OMIT), $is_protected), array('0'=>'No', '1'=>'Yes'), $is_protected) . '<br />';
        $markup .= "<label>Size:</label>" . $this->get_element_input_text("{$id}__COL_SIZE", $this->get_protected_value($this->m_custom->get_col_option($qid, TFORM, $col_name, COL_SIZE), $is_protected), $is_protected) . '<br />';
        $markup .= "<label>Align:</label>" . $this->get_element_select("{$id}__COL_ALIGN", $this->get_protected_value($this->m_custom->get_col_option($qid, TFORM, $col_name, COL_ALIGN), $is_protected), array(USE_DEFAULT=>USE_DEFAULT, ALIGN_L=>'Left', ALIGN_C=>'Center', ALIGN_R=>'Right'), $is_protected) . '<br />';
        //$markup .= "<label>Format:</label>" . $this->get_element_input_text("{$id}__COL_FORMAT", $this->get_protected_value($this->m_custom->get_col_option($qid, TFORM, $col_name, COL_FORMAT), $is_protected), $is_protected, 24) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_TFORM_all($qid)
    {
        $id = "{$qid}__TFORM";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Rows:</label>" . $this->get_element_input_text("{$id}__LIMIT_ROWS", $this->get_protected_value($this->m_custom->get_form_limit_rows($qid, TFORM), $is_protected), $is_protected) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_FFORM($qid, $col_name)
    {
        $id = "{$qid}__FFORM__{$col_name}";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Omit:</label>" . $this->get_element_select("{$id}__COL_OMIT", $this->get_protected_value($this->m_custom->get_col_option($qid, FFORM, $col_name, COL_OMIT), $is_protected), array('0'=>'No', '1'=>'Yes'), $is_protected) . '<br />';
        $markup .= "<label>Size:</label>" . $this->get_element_input_text("{$id}__COL_SIZE", $this->get_protected_value($this->m_custom->get_col_option($qid, FFORM, $col_name, COL_SIZE), $is_protected), $is_protected) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_RFORM($qid, $col_name)
    {
        $id = "{$qid}__RFORM__{$col_name}";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Omit:</label>" . $this->get_element_select("{$id}__COL_OMIT", $this->get_protected_value($this->m_custom->get_col_option($qid, RFORM, $col_name, COL_OMIT), $is_protected), array('0'=>'No', '1'=>'Yes'), $is_protected) . '<br />';
        $markup .= "<label>Size:</label>" . $this->get_element_input_text("{$id}__COL_SIZE", $this->get_protected_value($this->m_custom->get_col_option($qid, RFORM, $col_name, COL_SIZE), $is_protected), $is_protected) . '<br />';
        $markup .= "<label>Align:</label>" . $this->get_element_select("{$id}__COL_ALIGN", $this->get_protected_value($this->m_custom->get_col_option($qid, RFORM, $col_name, COL_ALIGN), $is_protected), array(USE_DEFAULT=>USE_DEFAULT, ALIGN_L=>'Left', ALIGN_C=>'Center', ALIGN_R=>'Right'), $is_protected) . '<br />';
        $markup .= "<label>Format:</label>" . $this->get_element_input_text("{$id}__COL_FORMAT", $this->get_protected_value($this->m_custom->get_col_option($qid, RFORM, $col_name, COL_FORMAT), $is_protected), $is_protected, 24) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_IFORM($qid, $col_name)
    {
        $id = "{$qid}__IFORM__{$col_name}";

        $markup = '';

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label>Omit:</label>" . $this->get_element_select("{$id}__COL_OMIT", $this->get_protected_value($this->m_custom->get_col_option($qid, IFORM, $col_name, COL_OMIT), $is_protected), array('0'=>'No', '1'=>'Yes'), $is_protected) . '<br />';
        $markup .= "<label>Editor:</label>" . $this->get_element_select("{$id}__COL_EDITOR", $this->get_protected_value($this->m_custom->get_col_option($qid, IFORM, $col_name, COL_EDITOR), $is_protected), array(USE_DEFAULT=>USE_DEFAULT, EDITOR_INPUT=>'&lt;' . EDITOR_INPUT . '&gt;', EDITOR_TEXTAREA=>'&lt;' . EDITOR_TEXTAREA . '&gt;'), $is_protected) . '<br />';
        $markup .= "<label>Size:</label>" . $this->get_element_input_text("{$id}__COL_SIZE", $this->get_protected_value($this->m_custom->get_col_option($qid, IFORM, $col_name, COL_SIZE), $is_protected), $is_protected) . '<br />';
        $markup .= "<label>Rows:</label>" . $this->get_element_input_text("{$id}__COL_EDITOR_ROWS", $this->get_protected_value($this->m_custom->get_col_option($qid, IFORM, $col_name, COL_EDITOR_ROWS), $is_protected), $is_protected) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_options_reporting($qid)
    {
        include_once('report.php');

        ////

        $id = "id_{$qid}";

        $markup = '';

        $this->get_protected_value($this->m_custom->get_form_title(RFORM, $qid, true), $is_title_protected);
        $title_source = $this->get_source($this->m_custom->get_last_key());
        $title_name = 'title_expr';

        put_payload_rec($title_name, $title_source);

        $markup .= "<div id=\"{$id}\" class=\"class_form_std\">";
        $markup .= "<label><em>Title</em>:</label><span id=\"id_{$title_name}\" title=\"" . TOOLTIP_PHP_EXPR . "\">" . $this->get_element_input_text($title_name, '', $is_title_protected, 72) . '</span><br />';
        $markup .= "<label>Page Size:</label>" . $this->get_element_select("{$id}__RPT_PAGE_SIZE", $this->get_protected_value($this->m_custom->get_option_value($qid, RPT_PAGE_SIZE), $is_option_protected), array(USE_DEFAULT=>USE_DEFAULT, PAGE_SIZE_LETTER=>PAGE_SIZE_LETTER, PAGE_SIZE_LEGAL=>PAGE_SIZE_LEGAL, PAGE_SIZE_A3=>PAGE_SIZE_A3, PAGE_SIZE_A4=>PAGE_SIZE_A4, PAGE_SIZE_A5=>PAGE_SIZE_A5), $is_option_protected) . '<br />';
        $markup .= "<label>Orient:</label>" . $this->get_element_select("{$id}__RPT_PAGE_ORIENTATION", $this->get_protected_value($this->m_custom->get_option_value($qid, RPT_PAGE_ORIENTATION), $is_option_protected), array(USE_DEFAULT=>USE_DEFAULT, PAGE_ORIENTATION_PORTRAIT=>PAGE_ORIENTATION_PORTRAIT, PAGE_ORIENTATION_LANDSCAPE=>PAGE_ORIENTATION_LANDSCAPE), $is_option_protected) . '<br />';
        $markup .= "<label>Font Size:</label>" . $this->get_element_select("{$id}__RPT_FONT_SIZE", $this->get_protected_value($this->m_custom->get_option_value($qid, RPT_FONT_SIZE), $is_option_protected), array(USE_DEFAULT=>USE_DEFAULT, 6=>'6', 8=>'8', 10=>'10', 12=>'12'), $is_option_protected) . '<br />';
        $markup .= "<label>Family:</label>" . $this->get_element_select("{$id}__RPT_FONT_FAMILY", $this->get_protected_value($this->m_custom->get_option_value($qid, RPT_FONT_FAMILY), $is_option_protected), array_merge(array(USE_DEFAULT=>USE_DEFAULT), get_charset_fonts()), $is_option_protected) . '<br />';
        $markup .= "<label>Border:</label>" . $this->get_element_select("{$id}__RPT_CELL_BORDER", $this->get_protected_value($this->m_custom->get_option_value($qid, RPT_CELL_BORDER), $is_option_protected), array(USE_DEFAULT=>USE_DEFAULT, SWITCH_OFF=>SWITCH_OFF, SWITCH_ON=>SWITCH_ON), $is_option_protected) . '<br />';
        $markup .= "<label>Shade:</label>" . $this->get_element_select("{$id}__RPT_ROW_SHADE", $this->get_protected_value($this->m_custom->get_option_value($qid, RPT_ROW_SHADE), $is_option_protected), array(USE_DEFAULT=>USE_DEFAULT, SWITCH_OFF=>SWITCH_OFF, SWITCH_ON=>SWITCH_ON), $is_option_protected) . '<br />';
        $markup .= "</div>";

        return $markup;
    }

    function get_element_input_text($input_name, $value = '', $is_protected = false, $input_size = 5)
    {
        $protect = $is_protected ? ' readonly="readonly" disabled="disabled"' : '' ;

        return "<input{$protect} type=\"text\" name=\"{$input_name}\" value=\"{$value}\" size=\"{$input_size}\" />";
    }

    function get_element_select($select_name, $selected_value, $options, $is_protected = false, $well_formed = true)
    {
        // NOTE: markup must be well-formed to return via xml

        $tcl = $well_formed ? ' /' : '' ; // tag closure - depends on !DOCTYPE

        $protect = $is_protected ? ' disabled="disabled"' : '' ;

        if (empty($selected_value))
        {
            $selected_value = USE_DEFAULT;
        }

        $select_options = '';

        if (!empty($options))
        {
            foreach ($options as $option_value => $option_text)
            {
                $selected = $option_value == $selected_value ? ' selected="selected"' : '' ;
                $select_options .= "<option value=\"{$option_value}\"{$selected}{$tcl}>{$option_text}";
            }
        }

        return "<select{$protect} name=\"{$select_name}\">{$select_options}</select>";
    }

    function get_element_select_multi_line($select_name, $selected_value, $options, $is_protected = false, $size = 5, $handler = '', $well_formed = true)
    {
        // NOTE: markup must be well-formed to return via xml

        $tcl = $well_formed ? ' /' : '' ; // tag closure - depends on !DOCTYPE

        $is_no_choice = 0;

        if (empty($options))
        {
            $options[''] = '-- n/a --';
            $is_no_choice++;
        }

        $protect = $is_protected || $is_no_choice ? ' disabled="disabled"' : '' ;

        if ($size < 1)
        {
            $size = 1;
        }

        $select_options = '';

        if (!empty($options))
        {
            $select_first = !isset($options[$selected_value]);

            foreach ($options as $option_value => $option_text)
            {
                $selected = $select_first || $option_value == $selected_value ? ' selected="selected"' : '' ;
                $select_options .= "<option value=\"{$option_value}\"{$selected}{$tcl}>{$option_text}";
                $select_first = false;
            }
        }

        $onchange = !empty($handler) ? " onchange=\"{$handler}(this);\"" : '' ;

        return "<select{$protect} name=\"{$select_name}\" size=\"{$size}\"{$onchange}>{$select_options}</select>";
    }

    function get_table_columns($basis_table, $basis_col, $is_include_fk_cols = false)
    {
        $table_cols = array();

        if ($basis_table && $basis_col)
        {
            $paths = $this->m_schema->get_paths($basis_table);

            if (!empty($paths))
            {
                foreach ($paths as $path_index => $path)
                {
                    foreach ($path[PATH] as $node_index => $path_node)
                    {
                        if (!$node_index)
                        {
                            if ($path_node[COL_NAME] != $basis_col)
                            {
                                break; // skip path
                            }

                            continue; // skip basis node
                        }

                        $table_name = $path_node[TABLE_NAME];

                        if ($table_name)
                        {
                            $col_names = $this->m_schema->get_col_names($table_name);

                            if (!empty($col_names))
                            {
                                foreach ($col_names as $col_name)
                                {
                                    $is_pk = $this->m_schema->is_pk($table_name, $col_name);
                                    $is_fk = $this->m_schema->is_fk($table_name, $col_name);

                                    if (!$is_pk && (!$is_fk || $is_include_fk_cols))
                                    {
                                        $table_cols["{$table_name}.{$col_name}"] = "{$table_name}.{$col_name}";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return $table_cols;
    }

    ////

    function options_show_display($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $table_name = $this->m_custom->get_table($qid);

        if (in_array($table_name, $this->m_schema->get_table_names()))
        {
            $elements[] = "<div class=\"class_nav_col\">";

            $th = "<th></th><th>Search Form</th><th>Display Form</th><th>Select Form</th><th>Input Form</th><th>Report Form</th><th>Report Column</th>";

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Column Display Attributes</div>";
            $elements[] = "<table id=\"id_options_table\" class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $cols_info = $this->m_schema->get_table_cols_info($table_name);

            if (!empty($cols_info))
            {
                $cols = array();

                $fk_count = 0;

                foreach ($cols_info as $col_info)
                {
                    $col_name = $col_info['Field'];
                    $col_type_detail = $this->m_schema->get_col_type_detail($col_info);

                    $is_pk = $this->m_schema->is_pk($table_name, $col_name);
                    $is_fk = $this->m_schema->is_fk($table_name, $col_name);

                    if (!$is_pk)
                    {
                        $elements[] = "<tr>{$th}</tr>";

                        $elements[] = "<tr>";

                        $info = $col_type_detail['type'];

                        if (!empty($col_type_detail['maxlength']))
                        {
                            $info .= (' ' . $col_type_detail['maxlength']);
                        }

                        $info .= ($is_fk ? ' (FK' . (++$fk_count) . ')' : '');
                        $expanded_name = $is_fk ? ", {$table_name}_{$col_name}" : '' ;
                        $display_name = $this->m_schema->get_col_display_name($col_info);

                        if (empty($display_name))
                        {
                            $display_name = fmt_display_name(!empty($expanded_name) ? $expanded_name : $col_name);
                        }

                        $elements[] = "<th><big>{$display_name}</big><small><br/><br/>{$col_name}{$expanded_name}<br /><br />{$info}</small></th>";

                        $elements[] = "<td>" . $this->get_options_SFORM($qid, $col_name) . "</td>";
                        $elements[] = "<td>" . $this->get_options_DFORM($qid, $col_name) . "</td>";
                        $elements[] = "<td>" . $this->get_options_TFORM($qid, $col_name) . "</td>";
                        $elements[] = "<td>" . $this->get_options_IFORM($qid, $col_name) . "</td>";
                        $elements[] = "<td>" . $this->get_options_FFORM($qid, $col_name) . "</td>";
                        $elements[] = "<td>" . $this->get_options_RFORM($qid, $col_name) . "</td>";

                        $elements[] = "</tr>";

                        ////

                        $xtra = $this->m_custom->get_extra($table_name . '.' . $col_name, $qid);

                        if (!empty($xtra))
                        {
                            foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                            {
                                $elements[] = "<tr>{$th}</tr>";

                                $elements[] = "<tr>";

                                $info = '<em>EXTRA</em>';
                                $display_name = fmt_display_name($xtra_col_alias, false);

                                $elements[] = "<th><big>{$display_name}</big><small><br/><br/>{$xtra_col_alias}<br /><br />{$info}</small></th>";

                                $elements[] = "<td>" . $this->get_options_SFORM($qid, $xtra_col_alias) . "</td>";
                                $elements[] = "<td>" . $this->get_options_DFORM($qid, $xtra_col_alias) . "</td>";
                                $elements[] = "<td>" . $this->get_options_TFORM($qid, $xtra_col_alias) . "</td>";
                                $elements[] = "<td>" . ' ' . "</td>"; // skip IFORM
                                $elements[] = "<td>" . $this->get_options_FFORM($qid, $xtra_col_alias) . "</td>";
                                $elements[] = "<td>" . $this->get_options_RFORM($qid, $xtra_col_alias) . "</td>";

                                $elements[] = "</tr>";
                            }
                        }
                    }
                }
            }

            $elements[] = "<tr>{$th}</tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>All Columns</th>";
            $elements[] = "<td></td>";
            $elements[] = "<td></td>";
            $elements[] = "<td>" . $this->get_options_TFORM_all($qid) . "</td>";
            $elements[] = "<td></td>";
            $elements[] = "<td></td>";
            $elements[] = "<td></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input type=\"button\" value=\"Process Column Display Attributes\" title=\"Process Column Display Attributes\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
            $elements[] = "<div class=\"class_layout_vsep_std\"></div>";
            $elements[] = "<div class=\"class_layout_hsep_std\"></div>";
            $elements[] = "</div><!-- nav_col -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_display($basis_qid, &$activity)
    {
        $basis_table = $this->m_custom->get_table($basis_qid);
        $col_vars = $this->m_action->get_col_vars();

        if (in_array($basis_table, $this->m_schema->get_table_names()) && !empty($col_vars))
        {
            foreach ($col_vars as $n => $col_var)
            {
                $tokens = explode('__', $n);

                if (count($tokens) == 4)
                {
                    list($qid, $form_key, $col_name, $option_key) = $tokens;

                    assert($qid == $basis_qid);

                    $this->m_custom->set_col_option($qid, constant($form_key), $col_name, constant($option_key), $col_var['v'], $activity);

                    // TODO: HACK: KLUGE: manage shadow value for macro expand column
                    //
                    $table_name = $this->m_custom->get_table($qid);

                    if ($this->m_schema->is_fk($table_name, $col_name))
                    {
                        $this->m_custom->set_col_option($qid, constant($form_key), "{$table_name}_{$col_name}", constant($option_key), $col_var['v'], $activity); // TODO: encapsulate
                    }
                    //
                    ////
                }
            }

            ////

            $n = "{$basis_qid}__TFORM__LIMIT_ROWS";

            $option_value = isset($col_vars[$n]['v']) ? $col_vars[$n]['v'] : USE_DEFAULT ;

            $this->m_custom->set_form_limit_rows($basis_qid, TFORM, $option_value, $activity);
        }
    }

    function options_show_macro($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $basis_col = $this->m_action->get_col_var('basis_cols');
        $alias_col = null;
        $table_col = $this->m_action->get_col_var('table_cols');

        $basis_cols = null;
        $table_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            foreach ($col_names as $col_name)
            {
                if ($this->m_schema->is_fk($basis_table, $col_name))
                {
                    $basis_cols[$col_name] = $col_name;

                    $macro = $this->m_custom->get_macro("{$basis_table}.{$col_name}", $qid);

                    if (isset($macro))
                    {
                        $basis_cols[$col_name] .= ' [1]';
                    }
                }
            }

            if (!empty($basis_cols))
            {
                if (empty($basis_cols[$basis_col]))
                {
                    $basis_col = current(array_keys($basis_cols));
                }

                $alias_col = "{$basis_table}_{$basis_col}";
                $table_cols = $this->get_table_columns($basis_table, $basis_col);
                $col_expr = $this->get_protected_value($this->m_custom->get_macro("{$basis_table}.{$basis_col}", $qid), $is_protected);

                if (isset($col_expr))
                {
                    $table_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $table_cols);
                }
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Macro Column Expressions</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Basis Column</th><th>Column Alias</th><th>Table Columns</th><th>SQL <em>[SELECT]</em> Column Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>MACRO</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('basis_cols', $basis_col, $basis_cols, false, min($select_size, count($basis_cols)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">{$alias_col}</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('table_cols', $table_col, $table_cols, false, min($select_size, count($table_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_SQL_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process Macro Column Expression\" title=\"Process Macro Column Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_macro($qid, &$activity)
    {
        $basis_table = $this->m_custom->get_table($qid);
        $col_expr = $this->m_action->get_col_var('col_expr');

        $basis_col = $this->m_action->get_col_var('basis_cols');

        if (in_array($basis_table, $this->m_schema->get_table_names()) &&
            in_array($basis_col, $this->m_schema->get_col_names($basis_table)) &&
            isset($col_expr))
        {
            $key_str = $this->m_custom->set_macro($qid, "{$basis_table}.{$basis_col}", $col_expr, $activity);
        }
    }

    function options_show_list_macro($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $basis_col = $this->m_action->get_col_var('basis_cols');
        $alias_col = null;
        $table_col = $this->m_action->get_col_var('table_cols');

        $basis_cols = null;
        $table_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            foreach ($col_names as $col_name)
            {
                if ($this->m_schema->is_fk($basis_table, $col_name))
                {
                    $basis_cols[$col_name] = $col_name;

                    $macro = $this->m_custom->get_list_macro("{$basis_table}.{$col_name}", $qid);

                    if (isset($macro))
                    {
                        $basis_cols[$col_name] .= ' [1]';
                    }
                }
            }

            if (!empty($basis_cols))
            {
                if (empty($basis_cols[$basis_col]))
                {
                    $basis_col = current(array_keys($basis_cols));
                }

                $alias_col = "{$basis_table}_{$basis_col}";
                $table_cols = $this->get_table_columns($basis_table, $basis_col);
                $col_expr = $this->get_protected_value($this->m_custom->get_list_macro("{$basis_table}.{$basis_col}", $qid), $is_protected);

                if (isset($col_expr))
                {
                    $table_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $table_cols);
                }
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - List Macro Column Expressions</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Basis Column</th><th>Column Alias</th><th>Table Columns</th><th>SQL <em>[SELECT]</em> Column Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>LIST_MACRO</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('basis_cols', $basis_col, $basis_cols, false, min($select_size, count($basis_cols)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">{$alias_col}</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('table_cols', $table_col, $table_cols, false, min($select_size, count($table_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_SQL_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process List Macro Column Expression\" title=\"Process List Macro Column Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_list_macro($qid, &$activity)
    {
        $basis_table = $this->m_custom->get_table($qid);
        $col_expr = $this->m_action->get_col_var('col_expr');

        $basis_col = $this->m_action->get_col_var('basis_cols');

        if (in_array($basis_table, $this->m_schema->get_table_names()) &&
            in_array($basis_col, $this->m_schema->get_col_names($basis_table)) &&
            isset($col_expr))
        {
            $key_str = $this->m_custom->set_list_macro($qid, "{$basis_table}.{$basis_col}", $col_expr, $activity);
        }
    }

    function options_show_list_macro_order($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $basis_col = $this->m_action->get_col_var('basis_cols');
        $alias_col = null;
        $table_col = $this->m_action->get_col_var('table_cols');

        $basis_cols = null;
        $table_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            foreach ($col_names as $col_name)
            {
                if ($this->m_schema->is_fk($basis_table, $col_name))
                {
                    $basis_cols[$col_name] = $col_name;

                    $macro = $this->m_custom->get_list_macro_order("{$basis_table}.{$col_name}", $qid);

                    if (isset($macro))
                    {
                        $basis_cols[$col_name] .= ' [1]';
                    }
                }
            }

            if (!empty($basis_cols))
            {
                if (empty($basis_cols[$basis_col]))
                {
                    $basis_col = current(array_keys($basis_cols));
                }

                $alias_col = "{$basis_table}_{$basis_col}";
                $table_cols = $this->get_table_columns($basis_table, $basis_col);
                $col_expr = $this->get_protected_value($this->m_custom->get_list_macro_order("{$basis_table}.{$basis_col}", $qid), $is_protected);

                if (isset($col_expr))
                {
                    $table_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $table_cols);
                }
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - List Macro Order Expressions</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Basis Column</th><th>Column Alias</th><th>Table Columns</th><th>SQL <em>[ORDER BY]</em> Column Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>LIST_MACRO_ORDER</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('basis_cols', $basis_col, $basis_cols, false, min($select_size, count($basis_cols)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">{$alias_col}</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('table_cols', $table_col, $table_cols, false, min($select_size, count($table_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_SQL_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process List Macro Order Expression\" title=\"Process List Macro Order Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_list_macro_order($qid, &$activity)
    {
        $basis_table = $this->m_custom->get_table($qid);
        $col_expr = $this->m_action->get_col_var('col_expr');

        $basis_col = $this->m_action->get_col_var('basis_cols');

        if (in_array($basis_table, $this->m_schema->get_table_names()) &&
            in_array($basis_col, $this->m_schema->get_col_names($basis_table)) &&
            isset($col_expr))
        {
            $key_str = $this->m_custom->set_list_macro_order($qid, "{$basis_table}.{$basis_col}", $col_expr, $activity);
        }
    }

    function options_show_extra($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $basis_col = $this->m_action->get_col_var('basis_cols');
        $alias_col = $this->m_action->get_col_var('alias_cols');;
        $table_col = $this->m_action->get_col_var('table_cols');

        $basis_cols = null;
        $alias_cols = null;
        $table_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            $basis_table_cols = null;

            if (!empty($basis_col) && !in_array($basis_col, $col_names))
            {
                $basis_col = null; // arm trigger for default value assignment
            }

            foreach ($col_names as $col_name)
            {
                $basis_table_cols["{$basis_table}.{$col_name}"] = "{$basis_table}.{$col_name}";

                if (!empty($table_col) && isset($basis_table_cols[$table_col]))
                {
                    $table_col = null; // avoid setting default selection to basis_table column
                }

                $basis_cols[$col_name] = $col_name;

                if (empty($basis_col))
                {
                    $basis_col = $col_name; // provide reasonable default value
                }

                $xtra = $this->m_custom->get_extra($basis_table . '.' . $col_name, $qid);

                if (!empty($xtra))
                {
                    $basis_cols[$col_name] .= ' [' . count($xtra) . ']';
                }
            }

            if ($basis_col)
            {
                $xtra = $this->m_custom->get_extra($basis_table . '.' . $basis_col, $qid);

                $alias_expr = $this->m_action->get_col_var('alias_expr');

                if (!empty($alias_expr))
                {
                    if (!isset($xtra[$alias_expr]))
                    {
                        $xtra[$alias_expr] = $col_expr = '';
                    }

                    $alias_col = $alias_expr;
                }
                else if (!empty($alias_col) && !isset($xtra[$alias_col]))
                {
                    $alias_col = null;
                }

                if (!empty($xtra))
                {
                    foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                    {
                        $alias_cols[$xtra_col_alias] = $xtra_col_alias;

                        if (empty($alias_col))
                        {
                            $alias_col = $xtra_col_alias; // provide reasonable default value
                        }

                        if ($xtra_col_alias == $alias_col)
                        {
                            $this->get_protected_value($this->m_custom->get_extra_col_expr($basis_table . '.' . $basis_col, $alias_col, $qid), $is_protected);
                            $col_expr = $this->get_source($this->m_custom->get_last_key());
                        }
                    }
                }

                $table_cols = array_merge($this->get_table_columns($basis_table, $basis_col), $basis_table_cols);

                if (!empty($col_expr))
                {
                    $table_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $table_cols);
                }
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Extra Column Expressions</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Basis Column</th><th>Column Alias</th><th>Table Columns</th><th>PHP &gt;&gt; SQL <em>[SELECT]</em> Column Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>EXTRA</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('basis_cols', $basis_col, $basis_cols, false, min($select_size, count($basis_cols)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_input_text('alias_expr', '', false, 10) . "</td>" .
                          "<td style=\"border:0\"><button type=\"button\" name=\"alias_ins\" title=\"Insert\" onclick=\"on_show();\">&gt;&gt;</button></td>" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('alias_cols', $alias_col, $alias_cols, false, min($select_size, count($alias_cols)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('table_cols', $table_col, $table_cols, false, min($select_size, count($table_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_PHP_SQL_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process Extra Column Expression\" title=\"Process Extra Column Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_extra($qid, &$activity)
    {
        $basis_table = $this->m_custom->get_table($qid);
        $col_expr = $this->m_action->get_col_var('col_expr');

        $basis_col = $this->m_action->get_col_var('basis_cols');
        $alias_col = $this->m_action->get_col_var('alias_cols');

        if (in_array($basis_table, $this->m_schema->get_table_names()) &&
            in_array($basis_col, $this->m_schema->get_col_names($basis_table)) &&
            !empty($alias_col) &&
            !empty($col_expr))
        {
            $this->m_custom->get_extra_col_expr("{$basis_table}.{$basis_col}", $alias_col, $qid);
            $this->set_source($this->m_custom->get_last_key(), $col_expr, $activity);
        }
    }

    function options_show_order($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $query_col = $this->m_action->get_col_var('query_cols');

        $query_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            foreach ($col_names as $col_name)
            {
                $query_cols[$col_name] = $col_name;

                if ($this->m_schema->is_fk($basis_table, $col_name))
                {
                    $expand = $this->m_custom->get_macro("{$basis_table}.{$col_name}", $qid);

                    if (isset($expand))
                    {
                        $expand = "MACRO | {$expand}"; // i.e. using explicit MACRO definition
                    }
                    else
                    {
                        $expand = $this->m_schema->get_value_col($basis_table, $col_name);

                        if (!empty($expand))
                        {
                            $expand = "Auto | {$expand}"; // i.e. using first non-key column from parent table
                        }
                        else
                        {
                            $expand = "Raw | {$basis_table}.{$col_name}"; // i.e. no non-key parent table column available, using raw fk column
                        }
                    }

                    $query_cols["{$basis_table}_{$col_name}"] = "{$basis_table}_{$col_name} | {$expand}";
                }

                $xtra = $this->m_custom->get_extra("{$basis_table}.{$col_name}", $qid);

                if (!empty($xtra))
                {
                    foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                    {
                        $this->get_protected_value($this->m_custom->get_extra_col_expr($basis_table . '.' . $col_name, $xtra_col_alias, $qid), $is_protected);
                        $source_expr = $this->get_source($this->m_custom->get_last_key());
                        $query_cols[$xtra_col_alias] = "{$xtra_col_alias} | EXTRA | {$source_expr}";
                    }
                }
            }

            if (!empty($query_col) && !isset($query_cols[$query_col]))
            {
                $query_col = ''; // trigger default to first element
            }

            $order_expr = $this->get_protected_value($this->m_custom->get_order($qid), $is_protected);

            $is_source = $this->get_source($this->m_custom->get_last_key()) != null;

            if ($is_source || (!$is_source && $order_expr != ($basis_table . '.' . $this->m_custom->get_pk_name($basis_table))))
            {
                $col_expr = $order_expr;

                $query_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $query_cols);
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Query Order Expression</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Query Result Columns</th><th>SQL <em>[ORDER BY]</em> Column Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>ORDER</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('query_cols', $query_col, $query_cols, false, min($select_size, count($query_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_SQL_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process Order Expression\" title=\"Process Order Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_order($qid, &$activity)
    {
        $col_expr = $this->m_action->get_col_var('col_expr');

        if (in_array($this->m_custom->get_table($qid), $this->m_schema->get_table_names()) && isset($col_expr))
        {
            $key_str = $this->m_custom->set_order($qid, $col_expr, $activity);
        }
    }

    function options_show_col_order($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $form_key = $this->m_action->get_col_var('form_keys');
        $query_col = $this->m_action->get_col_var('query_cols');

        $query_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            $form_keys['RFORM'] = 'RFORM | Report';
            $form_keys['FFORM'] = 'FFORM | Report Form';
            $form_keys['IFORM'] = 'IFORM | Input Form';
            $form_keys['TFORM'] = 'TFORM | Select Form';
            $form_keys['DFORM'] = 'DFORM | Display Form';
            $form_keys['SFORM'] = 'SFORM | Search Form';

            foreach ($form_keys as $k => $t)
            {
                if ($this->m_custom->get_col_order(constant($k), $qid))
                {
                    $form_keys[$k] .= ' [1]';

                    if (empty($form_key))
                    {
                        $form_key = $k; // select as default
                    }
                }
            }

            if (empty($form_key))
            {
                $form_key = 'RFORM'; // select as default
            }

            foreach ($col_names as $col_name)
            {
                $query_cols[$col_name] = $col_name;

                if ($this->m_schema->is_fk($basis_table, $col_name))
                {
                    $expand = $this->m_custom->get_macro("{$basis_table}.{$col_name}", $qid);

                    if (isset($expand))
                    {
                        $expand = "MACRO | {$expand}"; // i.e. using explicit MACRO definition
                    }
                    else
                    {
                        $expand = $this->m_schema->get_value_col($basis_table, $col_name);

                        if (!empty($expand))
                        {
                            $expand = "Auto | {$expand}"; // i.e. using first non-key column from parent table
                        }
                        else
                        {
                            $expand = "Raw | {$basis_table}.{$col_name}"; // i.e. no non-key parent table column available, using raw fk column
                        }
                    }

                    $query_cols["{$basis_table}_{$col_name}"] = "{$basis_table}_{$col_name} | {$expand}";
                }

                $xtra = $this->m_custom->get_extra("{$basis_table}.{$col_name}", $qid);

                if (!empty($xtra))
                {
                    foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                    {
                        $this->get_protected_value($this->m_custom->get_extra_col_expr($basis_table . '.' . $col_name, $xtra_col_alias, $qid), $is_protected);
                        $source_expr = $this->get_source($this->m_custom->get_last_key());
                        $query_cols[$xtra_col_alias] = "{$xtra_col_alias} | EXTRA | {$source_expr}";
                    }
                }
            }

            if (!empty($query_col) && !isset($query_cols[$query_col]))
            {
                $query_col = ''; // trigger default to first element
            }

            $col_expr = $this->get_protected_value($this->m_custom->get_col_order(constant($form_key), $qid), $is_protected);

            if (!empty($col_expr))
            {
                $query_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $query_cols);
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Col Order Expression</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Form Keys</th><th>Query Result Columns</th><th>CSV Column Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>COL_ORDER</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('form_keys', $form_key, $form_keys, false, count($form_keys), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('query_cols', $query_col, $query_cols, false, min($select_size, count($query_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_CSV_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process Col Order Expression\" title=\"Process Col Order Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_col_order($qid, &$activity)
    {
        $form_key = $this->m_action->get_col_var('form_keys');
        $col_expr = $this->m_action->get_col_var('col_expr');

        if (in_array($this->m_custom->get_table($qid), $this->m_schema->get_table_names()) && !empty($col_expr))
        {
            $key_str = $this->m_custom->set_col_order($qid, constant($form_key), $col_expr, $activity);
        }
    }

    function options_show_detail_summary_cols($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_table = $this->m_custom->get_table($qid);

        $expr_index = $this->m_action->get_col_var('expr_indexes');;
        $query_col = $this->m_action->get_col_var('query_cols');

        $expr_indexes = null;
        $query_cols = null;

        $col_expr = null;
        $is_protected = false;

        ////

        $col_names = $this->m_schema->get_col_names($basis_table);

        if (!empty($col_names))
        {
            foreach ($col_names as $col_name)
            {
                $query_cols[$col_name] = $col_name;

                if ($this->m_schema->is_fk($basis_table, $col_name))
                {
                    $expand = $this->m_custom->get_macro("{$basis_table}.{$col_name}", $qid);

                    if (isset($expand))
                    {
                        $expand = "MACRO | {$expand}"; // i.e. using explicit MACRO definition
                    }
                    else
                    {
                        $expand = $this->m_schema->get_value_col($basis_table, $col_name);

                        if (!empty($expand))
                        {
                            $expand = "Auto | {$expand}"; // i.e. using first non-key column from parent table
                        }
                        else
                        {
                            $expand = "Raw | {$basis_table}.{$col_name}"; // i.e. no non-key parent table column available, using raw fk column
                        }
                    }

                    $query_cols["{$basis_table}_{$col_name}"] = "{$basis_table}_{$col_name} | {$expand}";
                }

                $xtra = $this->m_custom->get_extra("{$basis_table}.{$col_name}", $qid);

                if (!empty($xtra))
                {
                    foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                    {
                        $this->get_protected_value($this->m_custom->get_extra_col_expr($basis_table . '.' . $col_name, $xtra_col_alias, $qid), $is_protected);
                        $source_expr = $this->get_source($this->m_custom->get_last_key());
                        $query_cols[$xtra_col_alias] = "{$xtra_col_alias} | EXTRA | {$source_expr}";
                    }
                }
            }

            $sum_cols = $this->m_custom->get_detail_summary_cols($qid);

            $expr_index_new = $this->m_action->get_col_var('expr_index_new');

            if (is_numeric($expr_index_new))
            {
                $expr_index_new = max(0, (int)$expr_index_new);

                if (!isset($sum_cols[$expr_index_new]))
                {
                    $sum_cols[$expr_index_new] = $col_expr = '';
                }

                $expr_index = $expr_index_new;

                ksort($sum_cols);
            }
            else if (isset($expr_index) && !isset($sum_cols[$expr_index]))
            {
                $expr_index = null; // arm trigger for default value assignment
            }

            if (!empty($sum_cols))
            {
                foreach ($sum_cols as $sum_col_index => $sum_col_expr_elements)
                {
                    if (!isset($expr_index))
                    {
                        $expr_index = $sum_col_index; // provide reasonable default value
                    }

                    $expr_indexes[$sum_col_index] = $sum_col_index;

                    if ($sum_col_index == $expr_index && is_array($sum_col_expr_elements))
                    {
                        $col_expr = $this->get_protected_value($this->m_custom->get_detail_summary_col_expr($expr_index, $qid), $is_protected);
                    }
                }
            }

            if (!empty($col_expr))
            {
                $query_cols = array_merge(array(USE_DEFAULT => USE_DEFAULT), $query_cols);
            }

            ////

            put_payload_rec('col_expr', $col_expr);

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Detail Summary Cols Expressions</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Expression Index</th><th>Query Result Columns</th><th>Detail Summary Expression</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>DETAIL_SUMMARY_COLS</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_input_text('expr_index_new', '', false, 10) . "</td>" .
                          "<td style=\"border:0\"><button type=\"button\" name=\"alias_ins\" title=\"Insert\" onclick=\"on_show();\">&gt;&gt;</button></td>" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('expr_indexes', $expr_index, $expr_indexes, false, min($select_size, count($expr_indexes)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td id=\"id_insert_term\" style=\"border:0\">" . $this->get_element_select_multi_line('query_cols', $query_col, $query_cols, false, min($select_size, count($query_cols))) . "</td>" .
                          "<td style=\"border:0\"><button{$disable} type=\"button\" name=\"insert_term\" title=\"Insert\" onclick=\"insert_term();\">&gt;&gt;</button></td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table>";
            $elements[] = "<tr style=\"border:0\">";
            $elements[] = "<td id=\"id_col_expr\" style=\"border:0\" title=\"" . TOOLTIP_CSV_EXPR . "\">" . $this->get_element_input_text('col_expr', '', $is_protected, (int)max($expr_size, $expr_pad * strlen($col_expr))) . "</td>";
            $elements[] = "</tr>";
            $elements[] = "<tr style=\"border:0\">";
            $elements[] = "<td style=\"border:0\"><em>summary_col_name[, group_col_name[, suppress_left_N_columns]]</em></td>";
            $elements[] = "</tr>";
            $elements[] = "</table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input{$disable} type=\"button\" value=\"Process Extra Column Expression\" title=\"Process Extra Column Expression\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_detail_summary_cols($qid, &$activity)
    {
        $col_expr = $this->m_action->get_col_var('col_expr');

        $expr_index = $this->m_action->get_col_var('expr_indexes');

        if (in_array($this->m_custom->get_table($qid), $this->m_schema->get_table_names()) && isset($expr_index) && !empty($col_expr))
        {
            $key_str = $this->m_custom->set_detail_summary_cols($qid, $expr_index, $col_expr, $activity);
        }
    }

    function options_show_reporting($qid, $items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        if (in_array($this->m_custom->get_table($qid), $this->m_schema->get_table_names()))
        {
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Options Form - Reporting</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th>Customization Items</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<td>" . $this->get_options_reporting($qid, $this->m_sources) . "</td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<input type=\"button\" value=\"Process Reporting Options\" title=\"Process Reporting Options\" onclick=\"on_process();\" />";

            if (isset($items_changed))
            {
                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function options_process_reporting($qid, &$activity)
    {
        $col_vars = $this->m_action->get_col_vars();

        if (in_array($this->m_custom->get_table($qid), $this->m_schema->get_table_names()) && !empty($col_vars))
        {
            foreach ($col_vars as $n => $col_var)
            {
                if ($n == 'title_expr')
                {
                    $this->m_custom->get_form_title(RFORM, $qid, true);
                    $this->set_source($this->m_custom->get_last_key(), $col_var['v'], $activity);
                }
                else
                {
                    $tokens = explode('__', $n);

                    if (count($tokens) == 2)
                    {
                        list($pfx, $option_key) = $tokens;

                        $this->m_custom->set_option_value($qid, constant($option_key), $col_var['v'], $activity);
                    }
                }
            }
        }
    }

    ////

    function nav_handler_pagegen($appid, $qid)
    {
        define('PID_PAGEGEN', 'pagegen'); // TODO: TEMP: DEBUG:
        define('BASIS_PAGE_OUTFILE', '_basis_page_outfile_');
        define('BASIS_PAGE_TEMPLATE', '_basis_page_template_');
        define('BASIS_PAGE_ENABLE', '_basis_page_enable_');
        define('REPORT_PAGE_OUTFILE', '_report_page_outfile_');
        define('REPORT_PAGE_TEMPLATE', '_report_page_template_');
        define('REPORT_PAGE_ENABLE', '_report_page_enable_');

        $activity = null;
        $pagegen_log = array();

        ////

        $basis_table_name = $this->m_custom->get_table($qid);
        $table_names = $this->m_schema->get_table_names();

        $is_regen = $this->m_action->get_col_var('regenerate_all') == 'on';

        if ($this->m_action->get_qid() == '_pagegen_process_' && !empty($basis_table_name))
        {
            if (!$is_regen)
            {
                $this->m_custom->set_state_var($qid, PID_PAGEGEN, BASIS_PAGE_OUTFILE, $this->m_action->get_col_var(BASIS_PAGE_OUTFILE), $activity);
                $this->m_custom->set_state_var($qid, PID_PAGEGEN, BASIS_PAGE_TEMPLATE, $this->m_action->get_col_var(BASIS_PAGE_TEMPLATE), $activity);
                $this->m_custom->set_state_var($qid, PID_PAGEGEN, BASIS_PAGE_ENABLE, ($this->m_action->get_col_var(BASIS_PAGE_ENABLE) == 'on' ? 'on' : 'off'), $activity);

                $this->m_custom->set_state_var($qid, PID_PAGEGEN, REPORT_PAGE_OUTFILE, $this->m_action->get_col_var(REPORT_PAGE_OUTFILE), $activity);
                $this->m_custom->set_state_var($qid, PID_PAGEGEN, REPORT_PAGE_TEMPLATE, $this->m_action->get_col_var(REPORT_PAGE_TEMPLATE), $activity);
                $this->m_custom->set_state_var($qid, PID_PAGEGEN, REPORT_PAGE_ENABLE, ($this->m_action->get_col_var(REPORT_PAGE_ENABLE) == 'on' ? 'on' : 'off'), $activity);
            }

            $basis_iter = $this->get_qid_table_names_map();

            foreach ($basis_iter as $basis_qid => $basis_table)
            {
                if ($is_regen || $basis_qid == $qid)
                {
                    if ($this->pagegen_process($appid, $basis_qid, $basis_table, $table_names, $pagegen_log, $activity, $is_regen))
                    {
                        break; // error
                    }
                }
            }

            if (!$is_regen)
            {
                $this->inc_gen($appid, $activity);
            }
        }

        $this->pagegen_show($appid, $qid, $basis_table_name, $table_names, $pagegen_log, $this->m_ADH, $is_regen);
    }

    function pagegen_show($appid, $qid, $basis_table_name, $table_names, &$pagegen_log, &$elements, $is_regen)
    {
        // NOTE: markup must be well-formed to return via xml

        if (!empty($appid) &&
            !empty($basis_table_name) &&
            !empty($table_names) &&
            in_array($basis_table_name, $table_names) &&
            ($paths = $this->m_schema->get_paths($basis_table_name)) &&
            !empty($paths))
        {
            $shared = "../_shared_/"; // TODO: configurable

            if (!($basis_page_outfile = $this->m_custom->get_state_var($qid, PID_PAGEGEN, BASIS_PAGE_OUTFILE)))
            {
                $basis_page_outfile = $qid . '.htm';
            }

            if (!($basis_page_template = $this->m_custom->get_state_var($qid, PID_PAGEGEN, BASIS_PAGE_TEMPLATE)))
            {
                $basis_page_template = 'template.htm';
            }

            $basis_page_enable = $this->m_custom->get_state_var($qid, PID_PAGEGEN, BASIS_PAGE_ENABLE) != 'off' ? ' checked="checked"' : '' ;

            if (!($report_page_outfile = $this->m_custom->get_state_var($qid, PID_PAGEGEN, REPORT_PAGE_OUTFILE)))
            {
                $report_page_outfile = $qid . '.report.htm';
            }

            if (!($report_page_template = $this->m_custom->get_state_var($qid, PID_PAGEGEN, REPORT_PAGE_TEMPLATE)))
            {
                $report_page_template = 'template.report.htm';
            }

            $report_page_enable = $this->m_custom->get_state_var($qid, PID_PAGEGEN, REPORT_PAGE_ENABLE) != 'off' ? ' checked="checked"' : '' ;

            $regenerate_all = $is_regen ? ' checked="checked"' : '' ;
            $caption = !$is_regen ? $this->m_custom->get_database($appid) . ".{$basis_table_name}"  : 'all from stored settings' ;


            ////

            $elements[] = "<div class=\"class_nav_col\">";

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Page Settings - <strong>{$caption}</strong></div>";

            if (!$is_regen)
            {
                $elements[] = "<div class=\"class_form_std\">";
                $elements[] = "<label>Basis Page:</label><input type=\"text\" name=\"" . BASIS_PAGE_OUTFILE . "\" value=\"{$basis_page_outfile}\" /><br />";
                $elements[] = "<label>Basis Page Template:</label><input type=\"text\" name=\"" . BASIS_PAGE_TEMPLATE . "\" value=\"{$basis_page_template}\" />";
                $elements[] = "<input type=\"checkbox\" name=\"" . BASIS_PAGE_ENABLE . "\" title=\"Enable basis page markup generation\"{$basis_page_enable} /><br />";
                $elements[] = "<label>Report Page:</label><input type=\"text\" name=\"" . REPORT_PAGE_OUTFILE . "\" value=\"{$report_page_outfile}\" /><br />";
                $elements[] = "<label>Report Page Template:</label><input type=\"text\" name=\"" . REPORT_PAGE_TEMPLATE . "\" value=\"{$report_page_template}\" />";
                $elements[] = "<input type=\"checkbox\" name=\"" . REPORT_PAGE_ENABLE . "\" title=\"Enable report page markup generation\"{$report_page_enable} /><br />";
                $elements[] = "</div><!-- class_form_std -->";
            }

            $elements[] = "<div class=\"class_vsep_std\"></div>";
            $elements[] = "<div style=\"margin-left:1em;height:2em;\" ><input type=\"button\" value=\"Run PageGen\" title=\"Run PageGen\" onclick=\"pagegen_process();\" />";
            $elements[] = "<label style=\"margin-left:3em;\">Regenerate All:</label>";
            $elements[] = "<input style=\"vertical-align:middle;\" type=\"checkbox\" name=\"regenerate_all\" title=\"Regenerate All\"{$regenerate_all} onclick=\"pagegen_show();\" /></div>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";

            ////

            $elements[] = "<div class=\"class_layout_group_caption_std\">Page Status</div>";
            $elements[] = "<div class=\"class_log_area\">";

            if (!empty($pagegen_log))
            {
                $elements[] = "PageGen started...<br />";

                foreach ($pagegen_log as $element)
                {
                    $elements[] = "$element<br />";
                }

                $elements[] = 'PageGen done.<br />';
            }

            $appdir = get_app_dir($appid);

            $elements[] = "Basis Page file: ";

            if (file_exists($appdir . $basis_page_outfile))
            {
                $pathname = $appdir . $basis_page_outfile;
                $filetime = date("Y-m-d H:i:s", filemtime($pathname));
                $elements[] = "<a href=\"{$pathname}\">{$basis_page_outfile}</a> ({$filetime})<br />";
            }
            else
            {
                $elements[] = "<em>{$basis_page_outfile}</em> - not found<br />";
            }

            $elements[] = "Report Page file: ";

            if (file_exists($appdir . $report_page_outfile))
            {
                $pathname = $appdir . $report_page_outfile;
                $filetime = date("Y-m-d H:i:s", filemtime($pathname));
                $href = "{$shared}reports.htm?appid={$appid}&amp;reportid={$qid}";
                $elements[] = "<a href=\"{$href}\">{$report_page_outfile}</a> ({$filetime})<br />";
            }
            else
            {
                $elements[] = "<em>{$report_page_outfile}</em> - not found<br />";
            }

            $elements[] = "</div><!-- class_log_area -->";

            $elements[] = "</div><!-- class_layout_group_std -->\n";

            ////

            $elements[] = "</div><!-- class_nav_col -->\n";

            ////

            if (!$is_regen)
            {
                $elements[] = "<div class=\"class_nav_col\">";

                ////

                $elements[] = "<div class=\"class_layout_group_std\">";
                $elements[] = "<div class=\"class_layout_group_caption_std\">Page Flow</div>";
                $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
                $elements[] = "<tbody>";

                ////

                $topo_paths = array();

                foreach ($paths as $path_index => $path)
                {
                    $topo_key = '';

                    foreach ($path[PATH] as $node_index => $path_node)
                    {
                        $table_name = $path_node[TABLE_NAME];
                        $col_name = $path_node[COL_NAME];
                        $topo_key .= $table_name . sprintf('%02d', $this->m_schema->get_col_index($table_name, $col_name)) . $col_name;
                    }

                    $topo_paths[$topo_key] = array(PATH=>$path[PATH], 'path_index'=>$path_index);
                }

                ksort($topo_paths);

                ////

                $tiers = array();
                $tier_cols = count($topo_paths);

                $tier_index = 0;
                $col_name = $this->m_custom->get_pk_name($basis_table_name);
                $basis_index = $this->m_schema->get_col_index($basis_table_name, $col_name);
                $basis_key = '_basis_key_' . sprintf('%02d', $basis_index);
                $node_key =  $col_name . $basis_key;

                $tiers[$tier_index][$node_key]['table'] = $basis_table_name;
                $tiers[$tier_index][$node_key]['colspan'] = $tier_cols;
                $tiers[$tier_index][$node_key]['align'] = 0;
                $tiers[$tier_index][$node_key]['path_index'] = null;
                $tiers[$tier_index][$node_key]['basis_index'] = $basis_index;

                $col_index = 0;

                foreach ($topo_paths as $path_info)
                {
                    $path = &$path_info[PATH];
                    $path_index = $path_info['path_index'];

                    $basis_index = $this->m_schema->get_col_index($basis_table_name, $path[0][COL_NAME]);
                    $basis_key = '_basis_key_' . sprintf('%02d', $basis_index);

                    foreach ($path as $node_index => $path_node)
                    {
                        $tier_index = $node_index + 1;

                        if (!empty($path_node[JOIN_TABLE]))
                        {
                            $node_key = $path_node[COL_NAME] . $basis_key;

                            if (!isset($tiers[$tier_index][$node_key]['colspan']))
                            {
                                $tiers[$tier_index][$node_key]['table'] = $path_node[JOIN_TABLE];
                                $tiers[$tier_index][$node_key]['colspan'] = 1;
                                $tiers[$tier_index][$node_key]['align'] = $col_index;
                                $tiers[$tier_index][$node_key]['path_index'] = $path_index;
                                $tiers[$tier_index][$node_key]['basis_index'] = $basis_index;
                            }
                            else
                            {
                                $tiers[$tier_index][$node_key]['colspan'] += 1;
                            }
                        }
                    }

                    $col_index++;
                }

                ////

                $table_tr = array();

                foreach ($tiers as $tier_index => $tier)
                {
                    $col_index = 0;

                    $tr = '';
                    $tr_clear = '';
                    $fk_num = 0; // TODO: HACK: KLUGE: basis_key should only depend on FK columns

                    foreach ($tier as $node_key => $tier_col)
                    {
                        list($col_name, $basis_key) = explode('_basis_key_', $node_key);

                        $table = $tier_col['table'];
                        $colspan = $tier_col['colspan'];
                        $align = $tier_col['align'];
                        $path_index = $tier_col['path_index'];
                        $basis_index = $tier_col['basis_index'];

                        while ($col_index < $align)
                        {
                            $tr .= '<td></td>';
                            $col_index++;
                        }

                        ////

                        $button_state = '';

                        if (($tier_table_rec = $this->m_custom->get_tier_table($qid, '_basis_key_' . $basis_key)) &&
                             !empty($tier_table_rec) &&
                             $tier_table_rec[PATH_INDEX] == $path_index &&
                             $tier_table_rec[TIER_TABLE] == $table)
                        {
                            $button_state = ' checked="checked" ';
                        }

                        ////

                        if ($tier_index == 1)
                        {
                            $fk_num++;
                            $tr_clear .= "<td colspan=\"$colspan\">(FK{$fk_num})<br /><button title=\"Clear\" onclick=\"clear_tier_table('_basis_key_{$basis_key}');\">Clear</button></td>";
                        }

                        $input_radio = $tier_index ? "<br /><input type=\"radio\" name=\"_basis_key_$basis_key\" value=\"$path_index,$table\"{$button_state} />" : '' ;

                        $tr .= "<td colspan=\"$colspan\">$table<br />($col_name)$input_radio</td>";

                        $col_index += $colspan;
                    }

                    while ($col_index < $tier_cols)
                    {
                        $tr .= '<td></td>';
                        $col_index++;
                    }

                    if (!empty($tr_clear))
                    {
                        array_unshift($table_tr, "<tr>{$tr_clear}</tr>");
                    }

                    array_unshift($table_tr, "<tr>{$tr}</tr>");
                }

                ////

                if (!empty($table_tr))
                {
                    foreach ($table_tr as $tr)
                    {
                        $elements[] = $tr;
                    }
                }

                ////

                $elements[] = "</tbody>";
                $elements[] = "</table>";
                $elements[] = "</div><!-- class_layout_group_std -->";

                ////

                $elements[] = "</div><!-- class_nav_col -->\n";
            }
        }
        else
        {
            $elements[] = '';
        }
    }

    function pagegen_process($appid, $qid, $basis_table_name, $table_names, &$pagegen_log, &$activity, $is_regen)
    {
        $error_flag = false;

        $this->reset_intermediate_buffers();

        if (!empty($appid) &&
            !empty($qid) &&
            !empty($basis_table_name) &&
            !empty($table_names) &&
            ($paths = $this->m_schema->get_paths($basis_table_name)) &&
            !empty($paths) &&
            in_array($basis_table_name, $table_names))
        {
            $basis_page_outfile = $this->m_custom->get_state_var($qid, PID_PAGEGEN, BASIS_PAGE_OUTFILE);
            $basis_page_template = $this->m_custom->get_state_var($qid, PID_PAGEGEN, BASIS_PAGE_TEMPLATE);
            $basis_page_enable = $this->m_custom->get_state_var($qid, PID_PAGEGEN, BASIS_PAGE_ENABLE) == 'on';

            $report_page_outfile = $this->m_custom->get_state_var($qid, PID_PAGEGEN, REPORT_PAGE_OUTFILE);
            $report_page_template = $this->m_custom->get_state_var($qid, PID_PAGEGEN, REPORT_PAGE_TEMPLATE);
            $report_page_enable = $this->m_custom->get_state_var($qid, PID_PAGEGEN, REPORT_PAGE_ENABLE) == 'on';

            ////

            if ($basis_page_enable)
            {
                $log_legend = 'Basis Page';

                if (empty($basis_page_outfile))
                {
                    $pagegen_log[] = "{$log_legend} - filename may not be blank/empty";
                    $error_flag = true;
                }
                else
                {
                    $log_sentinel = count($pagegen_log);

                    if (preg_match('/[^0-9a-z\.\_\-\(\)]/i', $basis_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - filename contains disallowed characters";
                        $error_flag = true;
                    }

                    if (!preg_match('/^[0-9a-z]/i', $basis_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - filename must begin with a letter or digit";
                        $error_flag = true;
                    }

                    if (!preg_match('/.htm$/', $basis_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - filename extention must be: .htm"; // TODO: replace hard-coded value in various places
                        $error_flag = true;
                    }

                    if ($log_sentinel == count($pagegen_log) &&
                        file_exists(get_app_dir($appid) . $basis_page_outfile) &&
                        !@is_writable(get_app_dir($appid). $basis_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - file is not writable";
                        //$error_flag = true; // TODO: more testing needed - for now, just log the issue and continue
                    }
                }

                if (!file_exists(get_app_dir(SYNAPP2) . $basis_page_template))
                {
                    $pagegen_log[] = "{$log_legend} Template - file not found: $basis_page_template";
                    $error_flag = true;
                }
            }

            if ($report_page_enable)
            {
                $log_legend = 'Report Page';

                if (empty($report_page_outfile))
                {
                    $pagegen_log[] = "{$log_legend} - filename may not be blank/empty";
                    $error_flag = true;
                }
                else
                {
                    $log_sentinel = count($pagegen_log);

                    if (preg_match('/[^0-9a-z\.\_\-\(\)]/i', $report_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - filename contains disallowed characters";
                        $error_flag = true;
                    }

                    if (!preg_match('/^[0-9a-z]/i', $report_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - filename must begin with a letter or digit";
                        $error_flag = true;
                    }

                    if (!preg_match('/.report.htm$/', $report_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - filename extention must be: .report.htm"; // TODO: replace hard-coded value in various places
                        $error_flag = true;
                    }

                    if ($log_sentinel == count($pagegen_log) &&
                        file_exists(get_app_dir($appid) . $report_page_outfile) &&
                        !@is_writable(get_app_dir($appid) . $report_page_outfile))
                    {
                        $pagegen_log[] = "{$log_legend} - file is not writable";
                        //$error_flag = true; // TODO: more testing needed - for now, just log the issue and continue
                    }
                }

                if (!file_exists(get_app_dir(SYNAPP2) . $report_page_template))
                {
                    $pagegen_log[] = "{$log_legend} Template - file not found: $report_page_template";
                    $error_flag = true;
                }
            }

            if (!$error_flag && $is_regen)
            {
                if (!file_exists(get_app_dir($appid) . $basis_page_outfile))
                {
                    //$basis_page_enable = false; // TODO: TBD: should the file have to exist??
                }

                if (!file_exists(get_app_dir($appid) . $report_page_outfile))
                {
                    //$report_page_enable = false; // TODO: TBD: should the file have to exist??
                }
            }

            if (!$error_flag && ($basis_page_enable || $report_page_enable))
            {
                $active_paths = null;

                ////

                $col_count = $this->m_schema->get_table_col_count($basis_table_name);

                for ($basis_index = 0; $basis_index < $col_count; $basis_index++)
                {
                    $basis_key = '_basis_key_' . sprintf('%02d', $basis_index);

                    // detect var by fishing with generated name

                    if (!$is_regen)
                    {
                        $col_var = $this->m_action->get_col_var($basis_key);

                        if (!empty($col_var) || (empty($col_var) && $this->m_custom->get_tier_table($qid, $basis_key)))
                        {
                            $this->m_custom->set_tier_table($qid, $basis_key, (!empty($col_var) ? $col_var : ''), $activity); // set value (or stage delete)
                        }

                        if (!empty($col_var))
                        {
                            list($path_index, $tier_table) = explode(',', $col_var);
                            $active_paths[$path_index] = $tier_table;
                        }
                    }
                    else
                    {
                        if ($tier_table_rec = $this->m_custom->get_tier_table($qid, $basis_key))
                        {
                            $active_paths[$tier_table_rec[PATH_INDEX]] = $tier_table_rec[TIER_TABLE];
                        }
                    }
                }

                ////

                $flow_elements = array();

                $this->gen_flow_element($flow_elements, $qid);

                if (!empty($active_paths))
                {
                    $ipath = 0;

                    foreach ($active_paths as $path_index => $tier_table)
                    {
                        $path_nodes = &$paths[$path_index][PATH];

                        $inode = 0;

                        foreach ($path_nodes as $path_node)
                        {
                            if ($path_node[TABLE_NAME] == $tier_table)
                            {
                                break;
                            }

                            $fk_full_name = $path_node[TABLE_NAME] . '.' . $path_node[COL_NAME];

                            $is_prime = $ipath == 0;
                            $is_basis = $inode == 0;
                            $is_indepedent = $is_basis && !$is_prime;
                            $is_constraint = !$is_indepedent;

                            $this->m_fk_info[$fk_full_name] = array('is_prime'=>$is_prime,
                                                                    'is_basis'=>$is_basis,
                                                                    'is_constraint'=>$is_constraint,
                                                                    'is_independent'=>$is_indepedent,
                                                                    'nav'=>$ipath);

                            $this->gen_flow_element($flow_elements, $qid, $ipath, $inode, $path_node);

                            $inode++;
                        }

                        $ipath++;
                    }

                    ////

                    $ipath = 0;

                    foreach ($active_paths as $path_index => $tier_table)
                    {
                        $path_nodes = &$paths[$path_index][PATH];
                        $this->gather_page_markup($qid, $tier_table, $basis_table_name, $path_nodes, $ipath, $ipath + 1 == count($active_paths));
                        $ipath++;
                    }
                }
                else
                {
                    $path_nodes = array(array(TABLE_NAME=>$basis_table_name, COL_NAME=>null, JOIN_TABLE=>null, JOIN_COL=>null));
                    $this->gather_page_markup($qid, '', $basis_table_name, $path_nodes);
                }

                ////

                $this->m_XCH[] = "set_appid('" . $this->m_action->get_appid() . "');";
                $this->m_XCH[] = "set_pid('{$qid}');";

                ////

                ksort($flow_elements);

                $this->m_MAP = array_merge($this->m_MAP, array_values($flow_elements));

                ////

                if (!empty($this->m_caption_info))
                {
                    foreach ($this->m_caption_info as $caption_key => $info)
                    {
                        if (isset($this->m_VML[$caption_key]))
                        {
                            $this->m_VML[$caption_key] = str_replace('<!--{caption_info}-->', " ({$info})", $this->m_VML[$caption_key]);
                        }
                    }
                }

                ////

                if ($basis_page_enable)
                {
                    $basis_page_result = $this->page_gen($appid, $basis_page_outfile, $basis_page_template);

                    if ($basis_page_result)
                    {
                        $components = explode('/', $_SERVER['PHP_SELF']);

                        if (!empty($components))
                        {
                            $href = str_replace(array_pop($components), $basis_page_result, $_SERVER['PHP_SELF']);
                            $pagegen_log[] = "generated: <a href=\"{$href}\">{$basis_page_outfile}</a> (" . date ("Y-m-d H:i:s", filemtime($basis_page_result)) . ")";
                        }
                    }
                }

                ////

                if ($report_page_enable)
                {
                    $report_page_result = $this->page_gen($appid, $report_page_outfile, $report_page_template);

                    if ($report_page_result)
                    {
                        $components = explode('/', $_SERVER['PHP_SELF']);

                        if (!empty($components))
                        {
                            $reportid = str_replace('.htm', '', str_replace('.report', '', $report_page_outfile));
                            $href = str_replace(array_pop($components), "reports.htm?appid={$appid}&amp;reportid={$reportid}", $_SERVER['PHP_SELF']);
                            $pagegen_log[] = "generated: <a href=\"{$href}\">{$report_page_outfile}</a> (" . date ("Y-m-d H:i:s", filemtime($report_page_result)) . ")";
                        }
                    }
                }

                ////

                if (!$is_regen)
                {
                    // HACK: KLUGE: we get away with reusing the dirty markup instance because the templates employ only a few specific output tokens
                    $pagegen_log[] = ($this->page_gen($appid, $appid, 'template.index.html') ? "created" : "skipped") . " <a href=\"" . get_app_dir($appid) . "index.html\">index.html</a>";
                    $this->m_XCH = array(); // reset this markup member while others still have data!
                    $this->m_XCH[] = "set_appid('{$appid}');";
                    $this->m_XCH[] = "set_pid('welcome');";
                    $pagegen_log[] = ($this->page_gen($appid, $appid, 'template.welcome.htm') ? "created" : "skipped") . " <a href=\"" . get_app_dir($appid) . "welcome.htm\">welcome.htm</a>";
                }
            }
        }

        if ($error_flag)
        {
            $pagegen_log[] = 'unable to continue';
        }

        return $error_flag;
    }

    function gather_page_markup($basis_qid, $tier_table, $basis_table, &$path_nodes, $ipath = 0, $ilast=true)
    {
        $sep = "\n<!-- //// -->\n";

        if (!empty($path_nodes) && is_array($path_nodes))
        {
            $is_prime = $ipath == 0;
            $is_standalone_table = $is_prime && count($path_nodes) == 1;

            ////

            $this->m_VML[] = "<div class=\"class_nav_col\">";

            ////

            $skip_flag = !empty($tier_table);

            for ($j = count($path_nodes) - 1; $j >= 0; $j--)
            {
                $table_name = $path_nodes[$j][TABLE_NAME];
                $is_basis_table = $table_name == $basis_table;
                $qid = $is_basis_table ? $basis_qid : $table_name ;

                ////

                $nav = sprintf("%02d", $ipath);
                $navqid = "{$nav}__{$qid}";
                $flow_container_id = "id__tform__{$navqid}";
                $limit_rows = $this->m_custom->get_form_limit_rows($qid, TFORM);

                ////

                $is_tier_table = empty($tier_table) ? true : $table_name == $tier_table;
                $is_key_table = !$is_prime && $j == 1;
                $is_constraint_table = $is_prime && $j == 1;

                $is_mid_table = !$is_basis_table && !$is_key_table && !$is_tier_table;

                ////

                if ($skip_flag)
                {
                    if ($is_tier_table)
                    {
                        $skip_flag = false;
                    }
                    else
                    {
                        continue;
                    }
                }

                ////

                if ($is_prime || (!$is_prime && !$is_basis_table))
                {
                    $sform_layout_class = $is_tier_table ? 'class_layout_group_std' : 'class_layout_group_hid' ;
                    $dform_layout_class = $is_tier_table ? 'class_layout_group_hid' : 'class_layout_group_std' ;
                    $tform_layout_class = $is_basis_table || $is_key_table ? 'class_layout_group_std' : 'class_layout_group_ovl' ;
                    $iform_layout_class = 'class_layout_group_iform';
                    $fform_layout_class = 'class_layout_group_std';

                    ////

                    $this->gather_form_elements($this->m_IML, $qid, "id__iform__$navqid", $iform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);

                    if (!$is_basis_table || $is_standalone_table)
                    {
                        $this->m_VML[] = $sep;

                        $this->gather_form_elements($this->m_VML, $qid, "id__sform__$navqid", $sform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);

                        if (!$is_basis_table)
                        {
                            $this->gather_form_elements($this->m_VML, $qid, "id__dform__$navqid", $dform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);
                            $this->gather_form_elements($this->m_VML, $qid, "id__tform__$navqid", $tform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);
                        }
                        else
                        {
                            $this->gather_form_elements($this->m_TML, $qid, "id__tform__$navqid", $tform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);
                        }
                    }
                    else
                    {
                        $this->gather_form_elements($this->m_TML, $qid, "id__tform__$navqid", $tform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);
                    }

                    if ($is_basis_table)
                    {
                        $this->gather_form_elements($this->m_RPT, $qid, "id__fform__$navqid", $fform_layout_class, $ipath, $is_basis_table, $is_key_table, $is_standalone_table);
                    }

                    if (!$is_basis_table || $is_standalone_table)
                    {
                        $this->m_OVL[] = "reg_overlay(\"$flow_container_id\", \"id__sform__$navqid\", \"search\");";

                        if (!$is_basis_table)
                        {
                            $this->m_OVL[] = "reg_overlay(\"$flow_container_id\", \"id__dform__$navqid\", \"display\");";
                        }
                    }

                    $this->m_OVL[] = "reg_overlay(\"$flow_container_id\", \"id__iform__$navqid\", \"input\");";
                    $this->m_OVL[] = "reg_overlay(\"$flow_container_id\", \"id__tform__$navqid\", \"select\", {$limit_rows});";
                    $this->m_OVL[] = "reg_overlay(\"$flow_container_id\", \"id__aform__$navqid\", \"stat\");";
                }
            }

            ////

            $this->m_VML[] = "</div><!-- nav_col -->";

            ////

            if ($ilast && !empty($this->m_TML))
            {
                $this->m_VML[] = $sep;
                $this->m_VML[] = "<div class=\"class_layout_vsep_std\"></div>";
                $this->m_VML[] = "<div class=\"class_layout_hsep_std\"></div>";
                $this->m_VML[] = '';
                $this->m_VML[] = "<div id=\"id_basis_div\" class=\"class_nav_col\">";
                $this->m_VML = array_merge($this->m_VML, $this->m_TML);
                $this->m_VML[] = "</div><!-- id_basis_div -->";
            }

            ////

            if (!empty($this->m_VML))
            {
                $this->m_VML[] = $sep;
            }
        }
    }

    function gather_form_elements(&$vml, $qid, $id_pfx, $layout_class, $nav, $is_basis_table = false, $is_key_table = false, $is_standalone_table = false)
    {
        $sform = strpos($id_pfx, 'sform') !== false;
        $tform = strpos($id_pfx, 'tform') !== false;
        $dform = strpos($id_pfx, 'dform') !== false;
        $iform = strpos($id_pfx, 'iform') !== false;
        $fform = strpos($id_pfx, 'fform') !== false;

        $form_key = constant(strtoupper(substr($id_pfx, 4, 5)));

        $table_name = $this->m_custom->get_table($qid);

        $col_name_iter = $this->m_custom->get_form_col_order_map($form_key, $this->m_schema->get_col_names($table_name), $qid);

        if (!empty($col_name_iter))
        {
            $ffb = array();
            $frm = array();
            $tbl = array();
            $th = '';
            $tbl_extra = array();
            $th_extra = '';
            $lookups = array();
            $lookup_cols = array();
            $well_formed = false; // TODO: configurable
            $tcl = $well_formed ? ' /' : '' ; // tag closure - depends on !DOCTYPE

            $img = '../_shared_/img/'; // TODO: configurable
            $caption_qid_table = fmt_display_name($table_name, false);
            $nav_tab_info = $this->m_custom->get_nav_incl_tabs();
            $caption_fform = isset($nav_tab_info[$qid][A_TEXT]) ? $nav_tab_info[$qid][A_TEXT] : fmt_display_name($qid, false) ;

            $navqid = sprintf("%02d__%s", $nav, $qid);

            if ($tform)
            {
                $tbl[] = "\n<td axis=\"_row_id_\"><input type=\"checkbox\"{$tcl}></td>\n<td axis=\"_row_no_\">&nbsp;</td>"; // setup for record counter
            }

            foreach ($col_name_iter as $col_name)
            {
                if (!($col_info = $this->m_schema->find_col_info($table_name, $col_name)))
                {
                    continue; // skip extra column
                }

                $is_pk = $this->m_schema->is_pk($table_name, $col_name);

                if (!$is_pk)
                {
                    $xtra = $this->m_custom->get_extra($table_name . '.' . $col_name, $qid);

                    $is_fk = $this->m_schema->is_fk($table_name, $col_name);
                    $is_auto = $this->m_schema->is_auto($table_name, $col_name);
                    $is_blind = $this->m_schema->is_blind($table_name, $col_name);

                    $full_name = $table_name . '.' . $col_name;

                    $is_constraint = !empty($this->m_fk_info[$full_name]) ? $this->m_fk_info[$full_name]['is_constraint'] : false ; // TODO: encapsulate
                    $is_independent = !empty($this->m_fk_info[$full_name]) ? $this->m_fk_info[$full_name]['is_independent'] : false ; // TODO: encapsulate

                    $col_display_name = $this->m_schema->get_col_display_name($col_info) ;
                    $col_type_detail = $this->m_schema->get_col_type_detail($col_info);

                    $col_id = "{$id_pfx}__{$col_name}";

                    ////

                    $col_editor_default = $iform && ($col_type_detail['type'] == 'TEXT' || $col_type_detail['maxlength'] > 80) ? EDITOR_TEXTAREA : EDITOR_INPUT ;
                    $col_editor = $this->m_custom->get_form_col_editor($form_key, $col_name, $col_editor_default, $qid);
                    $col_editor_readonly = '';
                    $col_editor_size = '';
                    $col_editor_maxlength = '';

                    if ($col_editor == EDITOR_TEXTAREA)
                    {
                        $col_editor_cols = $this->m_custom->get_form_col_size($form_key, $col_name, 80, $qid);
                        $col_editor_rows = $this->m_custom->get_form_col_editor_rows($form_key, $col_name, 3, $qid);
                        $col_editor_size = " cols=\"{$col_editor_cols}\" rows=\"{$col_editor_rows}\"";
                    }
                    else
                    {
                        if (!empty($col_type_detail['maxlength']))
                        {
                            $maxlength = $col_type_detail['maxlength'];
                            $col_size = $this->m_custom->get_form_col_size($form_key, $col_name, min(80, (!$is_fk ? $maxlength : 40)), $qid);
                            $col_editor_maxlength = " maxlength=\"{$maxlength}\"";
                        }
                        else
                        {
                            $col_size = $this->m_custom->get_form_col_size($form_key, $col_name, 40, $qid);
                        }

                        $col_editor_size = " size=\"{$col_size}\"";
                    }

                    ////

                    if (!$tform)
                    {
                        $element = '';
                        $xtra_elements = null;

                        $is_form_omit_col = ($dform && $this->m_custom->is_form_omit_col(DFORM, $col_name, $qid)) ||
                                            ($sform && $this->m_custom->is_form_omit_col(SFORM, $col_name, $qid)) ||
                                            ($iform && $this->m_custom->is_form_omit_col(IFORM, $col_name, $qid)) ||
                                            ($fform && $this->m_custom->is_form_omit_col(FFORM, $col_name, $qid));

                        if ($iform && ($is_fk || $this->m_schema->is_set($table_name, $col_name)))
                        {
                            if ($is_form_omit_col)
                            {
                                // NOTE: this could possibly be ok if the column value is managed automatically

                                if ($is_fk)
                                {
                                    //add_debug_msg('WARNING - fk COL_OMIT ' . $col_name); // TODO: TBD: warning message??
                                }
                            }
                            else
                            {
                                if ($is_constraint)
                                {
                                    $fk_expand_qid = $this->m_custom->get_parent_name($table_name, $col_name);
                                    $fk_expand_select_id = sprintf("id__tform__%02d__%s", $this->m_fk_info[$full_name]['nav'], $fk_expand_qid);

                                    $lookups[] = array(JOIN_TABLE=>$fk_expand_qid,
                                                       JOIN_COL=>$col_name,
                                                       'reg_expr'=>"reg_lookup('{$id_pfx}', {qid:'{$fk_expand_qid}', select_id:'{$fk_expand_select_id}'});");
                                }
                                else if ($is_independent)
                                {
                                    $element = "<input readonly id=\"$col_id\" type=\"text\" name=\"{$table_name}_{$col_name}\"{$col_editor_size}{$tcl}><br{$tcl}>"; // TODO: encapsulate

                                    $this->m_MAP[] = "reg_blind('{$col_id}');"; // TODO: HACK: KLUGE: properly register independent key elements

                                    $fk_expand_qid = $this->m_custom->get_parent_name($table_name, $col_name);
                                    $fk_expand_select_id = sprintf("id__tform__%02d__%s", $this->m_fk_info[$full_name]['nav'], $fk_expand_qid);

                                    $lookups[] = array(JOIN_TABLE=>$fk_expand_qid,
                                                       JOIN_COL=>$col_name,
                                                       'reg_expr'=>"reg_lookup('{$id_pfx}', {qid:'{$fk_expand_qid}', select_id:'{$fk_expand_select_id}'});");
                                }
                                else
                                {
                                    $element = "<select id=\"$col_id\" name=\"$col_name\" onchange=\"process_change(this);\"><option value=\"\"{$tcl}></select><br{$tcl}>";

                                    if ($is_fk) // i.e. not is_set (not an enum)
                                    {
                                        $fk_expand_qid = $this->m_custom->get_parent_name($table_name, $col_name);

                                        $lookups[] = array(JOIN_TABLE=>$fk_expand_qid,
                                                           JOIN_COL=>$col_name,
                                                           'reg_expr'=>"reg_lookup('{$id_pfx}', {qid:'{$fk_expand_qid}', basis_id:'{$col_id}'});");
                                    }
                                }
                            }
                        }
                        else
                        {
                            $col_editor_readonly = $dform || ($iform && ($is_auto || $is_blind)) ? ' readonly' : '' ;

                            if (!$is_form_omit_col && ((!$fform && !$is_constraint) || ($fform && $col_type_detail['type'] != 'DATE')))
                            {
                                $input_name = !$is_fk ? $col_name : "{$table_name}_{$col_name}" ; // TODO: encapsulate

                                if ($col_editor == EDITOR_TEXTAREA)
                                {
                                    $element = "<textarea{$col_editor_readonly} id=\"{$col_id}\" name=\"{$input_name}\"{$col_editor_size}></textarea><br{$tcl}>";
                                }
                                else
                                {
                                    if (!$iform || !empty($col_editor_readonly))
                                    {
                                        $col_editor_maxlength = '';
                                    }

                                    $element = "<input{$col_editor_readonly} id=\"{$col_id}\" type=\"text\" name=\"{$input_name}\"{$col_editor_maxlength}{$col_editor_size}{$tcl}><br{$tcl}>";
                                }
                            }

                            if (($sform || $dform) && !empty($xtra))
                            {
                                foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                                {
                                    if (!($sform && $this->m_custom->is_form_omit_col(SFORM, $xtra_col_alias, $qid)) &&
                                        !($dform && $this->m_custom->is_form_omit_col(DFORM, $xtra_col_alias, $qid)))
                                    {
                                        $xlen = $this->m_custom->get_form_col_size($form_key, $xtra_col_alias, 40, $qid);
                                        $xtra_elements[] = "<label for=\"{$col_id}_{$xtra_col_alias}\">" . fmt_display_name($xtra_col_alias, false) . ":</label>";
                                        $xtra_elements[] = "<input{$col_editor_readonly} id=\"{$col_id}_{$xtra_col_alias}\" type=\"text\" name=\"{$xtra_col_alias}\" size=\"{$xlen}\"{$tcl}><br{$tcl}>";
                                    }
                                }
                            }

                            if ($iform && !$is_form_omit_col)
                            {
                                if ($is_blind)
                                {
                                    $this->m_MAP[] = "reg_blind('{$col_id}');";
                                }
                                else
                                {
                                    $lookup_cols[] = $col_name;

                                    if ($col_type_detail['type'] == 'DATE')
                                    {
                                        $datepicker_format =  $this->m_dbx->get_datepicker_format();
                                        $this->m_MAP[] = "reg_date('{$col_id}', '{$datepicker_format}');";
                                    }
                                }
                            }

                            ////

                            if ($fform)
                            {
                                if (!$is_form_omit_col && $col_type_detail['type'] == 'DATE')
                                {
                                    $datepicker_format =  $this->m_dbx->get_datepicker_format();
                                    $xlen = strlen($datepicker_format);
                                    $xtra_elements[] = "<label for=\"{$col_id}_beg\">{$col_display_name} >= :</label>";
                                    $xtra_elements[] = "<input id=\"{$col_id}_beg\" type=\"text\" name=\"{$col_name}[]\" size=\"{$xlen}\"{$tcl}><br{$tcl}>";
                                    $xtra_elements[] = "<label for=\"{$col_id}_end\"><= :</label>";
                                    $xtra_elements[] = "<input id=\"{$col_id}_end\" type=\"text\" name=\"{$col_name}[]\" size=\"{$xlen}\"{$tcl}><br{$tcl}>";
                                    $xtra_elements[] = "<script type=\"text/javascript\">";
                                    $xtra_elements[] = "reg_date('{$col_id}_beg', '{$datepicker_format}');";
                                    $xtra_elements[] = "reg_date('{$col_id}_end', '{$datepicker_format}');";
                                    $xtra_elements[] = "</script>";
                                }

                                if (!empty($xtra))
                                {
                                    foreach ($xtra as $xtra_col_alias => $xtra_col_expr)
                                    {
                                        if (!$this->m_custom->is_form_omit_col(FFORM, $xtra_col_alias, $qid))
                                        {
                                            $is_xtra_markup = false;

                                            ////

                                            $xtra_tokens = explode('.', $xtra_col_expr);

                                            if (is_array($xtra_tokens) && count($xtra_tokens) == 2)
                                            {
                                                $xtra_table_name = $xtra_tokens[0];
                                                $xtra_col_name = $xtra_tokens[1];

                                                $col_type = strtoupper($this->m_schema->find_col_info($xtra_table_name, $xtra_col_name, 'Type'));

                                                if ($col_type == 'DATE')
                                                {
                                                    $datepicker_format =  $this->m_dbx->get_datepicker_format();
                                                    $xlen = strlen($datepicker_format);
                                                    $xtra_elements[] = "<label for=\"{$col_id}_{$xtra_col_alias}_beg\">" . fmt_display_name($xtra_col_alias, false) . " >= :</label>";
                                                    $xtra_elements[] = "<input id=\"{$col_id}_{$xtra_col_alias}_beg\" type=\"text\" name=\"{$xtra_col_alias}[]\" size=\"{$xlen}\"{$tcl}><br{$tcl}>";
                                                    $xtra_elements[] = "<label for=\"{$col_id}_{$xtra_col_alias}_end\"><= :</label>";
                                                    $xtra_elements[] = "<input id=\"{$col_id}_{$xtra_col_alias}_end\" type=\"text\" name=\"{$xtra_col_alias}[]\" size=\"{$xlen}\"{$tcl}><br{$tcl}>";
                                                    $xtra_elements[] = "<script type=\"text/javascript\">";
                                                    $xtra_elements[] = "reg_date('{$col_id}_{$xtra_col_alias}_beg', '{$datepicker_format}');";
                                                    $xtra_elements[] = "reg_date('{$col_id}_{$xtra_col_alias}_end', '{$datepicker_format}');";
                                                    $xtra_elements[] = "</script>";
                                                    $is_xtra_markup = true;
                                                }
                                            }

                                            ////

                                            if (!$is_xtra_markup)
                                            {
                                                $xlen = $this->m_custom->get_form_col_size($form_key, $xtra_col_alias, 40, $qid);
                                                $xtra_elements[] = "<label for=\"{$col_id}_{$xtra_col_alias}\">" . fmt_display_name($xtra_col_alias, false) . ":</label>";
                                                $xtra_elements[] = "<input id=\"{$col_id}_{$xtra_col_alias}\" type=\"text\" name=\"{$xtra_col_alias}\" size=\"{$xlen}\"{$tcl}><br{$tcl}>";
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!empty($element))
                        {
                            $frm[] = "<label for=\"$col_id\">{$col_display_name}:</label>";
                            $frm[] = $element;

                            if ($iform)
                            {
                                $ffb[] = "<label for=\"$col_id\"></label>";
                            }
                        }

                        if (!empty($xtra_elements))
                        {
                            $frm = array_merge($frm, $xtra_elements);
                        }
                    }
                    else if ($tform)
                    {
                        $tform_xtra_col_names = !empty($xtra) ? array_keys($xtra) : array() ;

                        $tform_col_name_iter = !empty($tform_xtra_col_names) ? $this->m_custom->get_form_col_order_map($form_key, $tform_xtra_col_names, $qid) : array() ;

                        if (!in_array($col_name, $tform_col_name_iter))
                        {
                            array_unshift($tform_col_name_iter, $col_name);
                        }

                        foreach ($tform_col_name_iter as $tform_col_name)
                        {
                            if ($tform_col_name != $col_name && !in_array($tform_col_name, $tform_xtra_col_names))
                            {
                                continue; // skip unknown column (in/from the col_order_map)
                            }

                            $is_tform_omit_col = ($tform_col_name == $col_name && $is_constraint) || $this->m_custom->is_form_omit_col($form_key, $tform_col_name, $qid);

                            if (!$is_tform_omit_col)
                            {
                                $td_style = '';

                                $col_size = $this->m_custom->get_col_option($qid, $form_key, $tform_col_name, COL_SIZE);

                                if (!empty($col_size))
                                {
                                    $td_style .= "width:{$col_size}em;white-space:normal;";
                                }

                                switch ($this->m_custom->get_col_option($qid, $form_key, $tform_col_name, COL_ALIGN))
                                {
                                case ALIGN_L:
                                    $td_style .= 'text-align:left;';
                                    break;
                                case ALIGN_C:
                                    $td_style .= 'text-align:center;';
                                    break;
                                case ALIGN_J:
                                    $td_style .= 'text-align:justitfy;';
                                    break;
                                case ALIGN_R:
                                    $td_style .= 'text-align:right;';
                                    break;
                                default:
                                    break; // do nothing
                                }

                                if (!empty($td_style))
                                {
                                    $td_style = " style=\"{$td_style}\"";
                                }

                                $tform_col_heading = $tform_col_name != $col_name ? fmt_display_name($tform_col_name) : $col_display_name ;
                                $th .= "\n<th>{$tform_col_heading}</th>";
                                $axis_name = (!$is_fk || $tform_col_name != $col_name) ? $tform_col_name : "{$table_name}_{$col_name}" ; // TODO: TBD: '_'??
                                $tbl[] = "\n<td axis=\"$axis_name\"{$td_style}>&nbsp;</td>";
                            }
                        }
                        //
                        // end - foreach ($tform_col_name_iter ...

                        if ($is_fk && isset($this->m_fk_info[$full_name]['nav']))
                        {
                            $parent_name = $this->m_custom->get_parent_name($table_name, $col_name);

                            if (strcasecmp($parent_name, $col_display_name)) // test != case insensitive
                            {
                                $parent_navqid = sprintf("%02d__%s", $this->m_fk_info[$full_name]['nav'], $parent_name);

                                $this->m_caption_info['dform' . $parent_navqid] = $col_display_name;
                                $this->m_caption_info['sform' . $parent_navqid] = $col_display_name;
                                $this->m_caption_info['tform' . $parent_navqid] = $col_display_name;
                                $this->m_caption_info['iform' . $parent_navqid] = $col_display_name;
                            }
                        }
                    }
                }
            }
            //
            // end - foreach ($col_name_iter ...

            ////

            if (!empty($lookups) && !empty($lookup_cols))
            {
                foreach ($lookups as $details)
                {
                    $parent_cols_info = $this->m_schema->get_table_cols_info($details[JOIN_TABLE], $details[JOIN_COL]);

                    assert('!empty($parent_cols_info)');

                    if (!empty($parent_cols_info))
                    {
                        $matches = null;

                        foreach ($lookup_cols as $i => $lookup_col_name)
                        {
                            if ($this->m_custom->get_fetch($lookup_col_name, $details[JOIN_TABLE]))
                            {
                                $matches[$lookup_col_name] = $i; // now we have a reason for the lookup
                            }
                            else
                            {
                                foreach ($parent_cols_info as $parent_col_info)
                                {
                                    if ($parent_col_info['Field'] == $lookup_col_name)
                                    {
                                        $matches[$lookup_col_name] = $i; // now we have a reason for the lookup
                                    }
                                }
                            }
                        }

                        $is_lookup_needed = !empty($matches);

                        if ($is_lookup_needed)
                        {
                            foreach ($matches as $lookup_col_name => $i)
                            {
                                unset($lookup_cols[$i]);
                            }
                        }

                        $this->m_MAP[] = ($is_lookup_needed ? '' : '//') . $details['reg_expr'];
                    }
                }
            }

            ////

            if (!empty($tbl))
            {
                $subquery = $this->m_custom->get_subquery($table_name);

                if (!empty($subquery))
                {
                    foreach ($subquery as $col_name => $col_expr)
                    {
                        $th_extra .= "\n<th>" . fmt_display_name($col_name, false) . '</th>';
                        $tbl_extra[] = "\n<td axis=\"$col_name\">&nbsp;</td>";
                    }
                }
            }

            if (!empty($tbl_extra))
            {
                $th .= $th_extra;
                $tbl = array_merge($tbl, $tbl_extra);
            }

            ////

            if (!empty($frm))
            {
                $vml[] = "<div id=\"{$id_pfx}\" class=\"{$layout_class}\">";

                $id_form = "{$id_pfx}__form";

                if ($iform)
                {
                    $vml[] = "<div id=\"{$id_pfx}__caption\" class=\"class_layout_group_caption_std\">Input Form - {$caption_qid_table}</div>";

                }
                else if ($sform)
                {
                    $vml[] = "<div id=\"{$id_pfx}__caption\" class=\"class_layout_group_caption_std\">Search Form - {$caption_qid_table}</div>";
                }
                else if ($dform)
                {
                    $vml[] = "<div id=\"{$id_pfx}__caption\" class=\"class_layout_group_caption_std\">Display Form - {$caption_qid_table}</div>";
                }
                else if ($fform)
                {
                    $vml[] = "<div id=\"{$id_pfx}__caption\" class=\"class_layout_group_caption_std\">Report Form - {$caption_fform}</div>";
                    $vml[] = "<form id=\"$id_form\" action=\"../_shared_/action.php\" method=\"post\" name=\"_report_form_\">";
                }

                if (!empty($ffb))
                {
                    $vml[] = "<div id=\"{$id_pfx}_feedback\" class=\"class_form_std_feedback\">";
                    $vml = array_merge($vml, $ffb);
                    $vml[] = "</div><!-- class_form_std_feedback -->";
                }

                if (!empty($frm))
                {
                    $vml[] = "<div class=\"class_form_std\">";
                    $vml = array_merge($vml, $frm);
                    if ($fform)
                    {
                        $vml[] = "<input type=\"hidden\" name=\"_request_appid_\" value=\"" . $this->m_action->get_appid() . "\">";
                        $vml[] = "<input type=\"hidden\" name=\"_request_pid_\" value=\"reports\">"; // ASSUME: MAGIC: _pid_ for AUTH_PID
                        $vml[] = "<input type=\"hidden\" name=\"_request_qid_\" value=\"$qid\">";
                        $vml[] = "<input type=\"hidden\" name=\"_request_rid_\" value=\"$qid\">"; // ASSUME: MAGIC: _rid_ for AUTH_RID
                        $vml[] = "<input type=\"hidden\" name=\"_request_mode_\" value=\"report\">";
                        $vml[] = "<input type=\"hidden\" name=\"_request_show_response_\" value=\"0\">";
                        $vml[] = "<div class=\"class_vsep_std\"></div>";
                        $vml[] = "<label>Download Export:</label>" . $this->get_element_select("_request_export_", 0, array('0'=>'No', '1'=>'Yes'), false, $well_formed) . "<br{$tcl}>";
                    }
                    $vml[] = "</div><!-- class_form_std -->";
                }

                if ($sform)
                {
                    $vml[] = "<div class=\"class_vsep_std\"></div>";

                    $vml[] = "<div class=\"class_control_bar\">";
                    $vml['sform' . $navqid] = "<div class=\"class_control_bar_caption\">{$caption_qid_table}<!--{caption_info}--></div>";
                    $vml[] = "<div class=\"class_control_bar_controls\">";

                    $vml[] = "<button type=\"button\" name=\"do_search\" title=\"Search\"><img src=\"{$img}action_search.gif\" alt=\"Search\"{$tcl}></button>";
                    $vml[] = "<button type=\"button\" name=\"do_reset\" title=\"Reset\"><img src=\"{$img}action_reset.gif\" alt=\"Reset\"{$tcl}></button>";
                    $vml[] = "<button type=\"button\" name=\"do_add\" title=\"Add\"><img src=\"{$img}action_add.gif\" alt=\"Add\"{$tcl}></button>";

                    $vml[] = "</div><!-- class_control_bar_controls -->";
                    $vml[] = "<div class=\"class_control_bar_prompt\">Fill in values and then click Search</div>";
                    $vml[] = "</div><!-- class_control_bar -->";
                }
                else if ($iform)
                {
                    $vml[] = "<div class=\"class_vsep_std\"></div>";
                    $vml[] = "<button type=\"button\" name=\"do_exchange\" title=\"Ok\">Ok</button>";
                    $vml[] = "<button type=\"button\" name=\"do_cancel\" title=\"Cancel\">Cancel</button>";
                }
                else if ($fform)
                {
                    $vml[] = "<div class=\"class_vsep_std\"></div>";

                    $vml[] = "<div class=\"class_control_bar\">";
                    $vml[] = "<div class=\"class_control_bar_caption\">{$caption_fform}<!--{caption_info}--></div>";
                    $vml[] = "<div class=\"class_control_bar_controls\">";

                    $vml[] = "<button type=\"submit\" title=\"Report\"><img src=\"{$img}action_report.gif\" alt=\"Report\"{$tcl}></button>"; // omit name attribute

                    $vml[] = "</div><!-- class_control_bar_controls -->";
                    $vml[] = "<div class=\"class_control_bar_prompt\">Fill in values and then click Report</div>";
                    $vml[] = "</div><!-- class_control_bar -->";

                    $vml[] = "</form><!-- $id_form -->";
                }

                ////

                $vml[] = "</div><!-- $id_pfx -->";
            }
            else if (!empty($tbl))
            {
                $vml[] = "<div id=\"$id_pfx\" class=\"{$layout_class}\">";
                $vml[] = "<div id=\"{$id_pfx}__caption\" class=\"class_layout_group_caption_std\">Select Form - {$caption_qid_table}<span id=\"{$id_pfx}__found_rows\"></span></div>";

                ////

                $vml[] = "<table id=\"{$id_pfx}__table\"  class=\"class_table_std\" cellspacing=\"0\">";

                if (!empty($th))
                {
                    $vml[] = '<thead>';
                    $vml[] = "<tr>\n<th><input type=\"checkbox\"{$tcl}></th>\n<th>&nbsp;</th>$th\n</tr>";
                    $vml[] = '</thead>';
                }

                $vml[] = "<tbody>";

                $tr = "<tr>";

                foreach ($tbl as $element)
                {
                    $tr .= $element;
                }

                $tr .= "\n</tr>";

                $vml[] = $tr;

                $vml[] = "</tbody>";
                $vml[] = "</table>";

                ////

                $stat_cols = $this->m_custom->get_fetch_cols($qid);

                if (!empty($stat_cols))
                {
                    $id_pfx_aform = "id__aform__$navqid";

                    $aml = array();

                    foreach ($stat_cols as $stat_col_name => $stat_col_expr)
                    {
                        if ($this->m_custom->is_form_omit_col(AFORM, $stat_col_name, $qid))
                        {
                            continue; // ASSUME: is lookup - skip
                        }

                        $stat_col_display_name = fmt_display_name($stat_col_name, false);

                        $stat_col_style = '';

                        switch ($this->m_custom->get_col_option($qid, AFORM, $stat_col_name, COL_ALIGN))
                        {
                        case ALIGN_L:
                            $stat_col_style .= 'text-align:left;';
                            break;
                        case ALIGN_C:
                            $stat_col_style .= 'text-align:center;';
                            break;
                        case ALIGN_R:
                        case ALIGN_J:
                        default:
                            $stat_col_style .= 'text-align:right;';
                            break;
                        }

                        if (!empty($stat_col_style))
                        {
                            $stat_col_style = " style=\"{$stat_col_style}\"";
                        }

                        $stat_col_size = $this->m_custom->get_form_col_size(AFORM, $stat_col_name, 10, $qid);

                        $aml[] = "<label>{$stat_col_display_name}:</label>";
                        $aml[] = "<input readonly id=\"{$id_pfx_aform}__{$stat_col_name}\" type=\"text\" name=\"{$stat_col_name}\" size=\"{$stat_col_size}\"{$stat_col_style}{$tcl}><br{$tcl}>";

                        $this->m_MAP[] = "reg_blind('{$id_pfx_aform}__{$stat_col_name}');";
                    }

                    if (!empty($aml))
                    {
                        $vml[] = "<div class=\"class_vsep_std\"></div>";
                        $vml[] = "<div id=\"{$id_pfx_aform}\" class=\"class_form_std class_form_stat\">";

                        $vml = array_merge($vml, $aml);

                        $vml[] = "</div><!-- class_form_stat -->";
                    }
                }

                ////

                $vml[] = "<div class=\"class_vsep_std\"></div>";

                $vml[] = "<div class=\"class_control_bar\">";
                $vml['tform' . $navqid] = "<div class=\"class_control_bar_caption\">{$caption_qid_table}<!--{caption_info}--></div>";
                $vml[] = "<div class=\"class_control_bar_controls\">";

                $vml[] = "<button type=\"button\" name=\"do_nav_first\" title=\"First\"><img src=\"{$img}action_nav_first.gif\" alt=\"First\"{$tcl}></button>";
                $vml[] = "<button type=\"button\" name=\"do_nav_up\" title=\"PgUp\"><img src=\"{$img}action_nav_up.gif\" alt=\"PgUp\"{$tcl}></button>";
                $vml[] = "<button type=\"button\" name=\"do_nav_dn\" title=\"PgDn\"><img src=\"{$img}action_nav_dn.gif\" alt=\"PgDn\"{$tcl}></button>";
                $vml[] = "<button type=\"button\" name=\"do_nav_last\" title=\"Last\"><img src=\"{$img}action_nav_last.gif\" alt=\"Last\"{$tcl}></button>";

                $vml[] = "<button type=\"button\" name=\"do_nav_close\" title=\"Close\"><img src=\"{$img}action_close.gif\" alt=\"Close\"{$tcl}></button>";

                $vml[] = "<button type=\"button\" name=\"do_add\" title=\"Add\"><img src=\"{$img}action_add.gif\" alt=\"Add\"{$tcl}></button>";
                $vml[] = "<button type=\"button\" name=\"do_edit\" title=\"Edit\"><img src=\"{$img}action_edit.gif\" alt=\"Edit\"{$tcl}></button>";
                $vml[] = "<button type=\"button\" name=\"do_delete\" title=\"Delete\"><img src=\"{$img}action_remove.gif\" alt=\"Delete\"{$tcl}></button>";

                if (!$is_key_table && !$is_basis_table)
                {
                    $vml[] = "<button type=\"button\" name=\"do_nav_select\" title=\"Select\"><img src=\"{$img}action_nav_select.gif\" alt=\"Select\"{$tcl}></button>";
                }

                $vml[] = "</div><!-- class_control_bar_controls -->";
                $vml[] = "<div class=\"class_control_bar_prompt\">Navigate records, select a record and then click Edit (or click Add to create a new record)</div>";
                $vml[] = "</div><!-- class_control_bar -->";

                ////

                $vml[] = "</div><!-- $id_pfx -->";
            }

            if (!$iform && !$fform)
            {
                $vml[] = '';
                $vml[] = "<div class=\"class_layout_vsep_std\"></div>";
                $vml[] = "<div class=\"class_layout_hsep_std\"></div>";
            }

            $vml[] = '';
        }
    }

    function gen_flow_element(&$flow_elements, $basis_qid, $ipath = 0, $inode = 0, $path_node = null)
    {
        static $iseq = null;
        static $basis = null;

        if ($path_node === null) // test for implicit reset [between pages]
        {
            $iseq = null;
            $basis = null;
        }

        ////

        $nav = sprintf("%02d", $ipath);

        if ($iseq === null)
        {
            $iseq = 99;
            $flow_elements[$nav . sprintf("%02d", $iseq--)] = "reg_flow('id__tform__{$nav}__{$basis_qid}', {_qid_:'{$basis_qid}'});";
        }
        else if (!empty($path_node))
        {
            if ($inode == 0)
            {
                $basis = $path_node[COL_NAME];
            }

            $flow_elements[$nav . sprintf("%02d", $iseq--)] = "reg_flow('id__tform__{$nav}__{$path_node[JOIN_TABLE]}', {_qid_:'{$path_node[JOIN_TABLE]}', _basis_:'{$basis}', _table_:'{$path_node[TABLE_NAME]}', _key_:'{$path_node[COL_NAME]}'});";
        }
    }

    function page_gen($appid, $filename, $template)
    {
        $result = '';

        $appdir = null;

        if (empty($appid) || empty($filename) || empty($template) || !($appdir = mkdir_app_dir($appid)))
        {
            return $result;
        }

        ////

        $tokens = explode('.', $filename);

        $title = array_shift($tokens);

        if ($template == 'template.index.html' ||
            $template == 'template.welcome.htm')
        {
            $filename = str_replace('template.', '', $template);

            if (file_exists($appdir . $filename))
            {
                return $result;
            }
        }

        ////

        $input =  get_app_dir(SYNAPP2) . $template; // TODO: configurable template dir
        $output = $appdir . $filename;

        $lines_in = array();

        if ($lines_in = file($input))
        {
            $lines_out = array();

            $changes = false;
            $skip = false;

            $version_on = false;
            $title_on = false;
            $herald_on = false;

            $css_on = false;
            $vml_on = false;
            $rpt_on = false;
            $iml_on = false;
            $xch_on = false;
            $map_on = false;
            $ovl_on = false;
            $nav_on = false;
            $inc_on = false;

            foreach ($lines_in as $line)
            {
                if (strpos($line, '<!--{version}-->') === 0)
                {
                    $version_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/version}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{title}-->') === 0)
                {
                    $title_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/title}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{herald}-->') === 0)
                {
                    $herald_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/herald}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{css}-->') === 0)
                {
                    $css_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/css}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{iform}-->') === 0)
                {
                    $iml_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/iform}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{group}-->') === 0)
                {
                    $vml_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/group}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{rpt}-->') === 0)
                {
                    $rpt_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/rpt}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '//<!--{xch}-->') === 0)
                {
                    $xch_on = true;
                    $skip = true;
                }
                else if (strpos($line, '//<!--{/xch}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '//<!--{map}-->') === 0)
                {
                    $map_on = true;
                    $skip = true;
                }
                else if (strpos($line, '//<!--{/map}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '//<!--{ovl}-->') === 0)
                {
                    $ovl_on = true;
                    $skip = true;
                }
                else if (strpos($line, '//<!--{/ovl}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '<!--{nav}-->') === 0)
                {
                    $nav_on = true;
                    $skip = true;
                }
                else if (strpos($line, '<!--{/nav}-->') === 0)
                {
                    $skip = false;
                }
                else if (strpos($line, '//<!--{inc}-->') === 0)
                {
                    $inc_on = true;
                    $skip = true;
                    continue; // discard tag $line
                }
                else if (strpos($line, '//<!--{/inc}-->') === 0)
                {
                    $skip = false;
                    continue; // discard tag $line
                }
                else if ($skip)
                {
                    continue;
                }

                $lines_out[] = $line;

                if ($version_on)
                {
                    $lines_out[] = '<!-- ' . get_version() . " -->\n";

                    $version_on = false;
                }
                else if ($title_on)
                {
                    $lines_out[] = "<title>\n";
                    $lines_out[] = fmt_display_name($title) . "\n";
                    $lines_out[] = "</title>\n";
                    $changes = true; // SAFETY: affect output ONLY if we actually insert markup

                    $title_on = false;
                }
                else if ($herald_on)
                {
                    $lines_out[] = fmt_display_name($title) . "\n";
                    $changes = true; // SAFETY: affect output ONLY if we actually insert markup

                    $herald_on = false;
                }
                else if ($css_on)
                {
                    if (!empty($this->m_CSS))
                    {
                        $lines_out[] = "<style type=\"text/css\">\n";

                        foreach ($this->m_CSS as $markup)
                        {
                            $lines_out[] = $markup . "\n";
                        }

                        $lines_out[] = "</style>\n";

                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $css_on = false;
                }
                else if ($iml_on)
                {
                    foreach ($this->m_IML as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $iml_on = false;
                }
                else if ($vml_on)
                {
                    foreach ($this->m_VML as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $vml_on = false;
                }
                else if ($rpt_on)
                {
                    foreach ($this->m_RPT as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $rpt_on = false;
                }
                else if ($xch_on)
                {
                    foreach ($this->m_XCH as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $xch_on = false;
                }
                else if ($map_on)
                {
                    foreach ($this->m_MAP as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $map_on = false;
                }
                else if ($ovl_on)
                {
                    foreach ($this->m_OVL as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $ovl_on = false;
                }
                else if ($nav_on)
                {
                    foreach ($this->m_NAV as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $nav_on = false;
                }
                else if ($inc_on)
                {
                    foreach ($this->m_INC as $markup)
                    {
                        $lines_out[] = $markup . "\n";
                        $changes = true; // SAFETY: affect output ONLY if we actually insert markup
                    }

                    $inc_on = false;
                }
            }

            if ($changes)
            {
                if (!writeFileContents($output, $lines_out))
                {
                    add_debug_msg("writeFileContents('$output') - failed"); // TODO: error message
                }

                $result = $output;
            }
            else
            {
                // TODO: output unaffected - message?
            }
        }

        return $result;
    }

    function inc_gen($appid, &$activity)
    {
        $result = '';

        $appdir = null;

        if (empty($appid) || !($appdir = mkdir_app_dir($appid)))
        {
            return $result;
        }

        ////

        $template_inc_filename = 'template.inc.php';
        $custom_inc_filename = 'custom.inc.php';
        $synapp2_inc_filename = 'synapp2.inc.php';

        if (!file_exists($appdir . $custom_inc_filename))
        {
            $this->m_INC = array();

            $this->m_INC[] = "// add your application specific customization code here";
            $this->m_INC[] = "";

            // HACK: KLUGE: we get away with reusing the dirty markup instance because the templates employ only a few specific output tokens
            $this->page_gen($appid, $custom_inc_filename, $template_inc_filename);
        }

        if (!file_exists($appdir . $synapp2_inc_filename))
        {
            $this->m_INC = array();

            $this->m_INC[] = "// WARNING: this file contains SynApp2 generated content, manual edits may be overwritten";
            $this->m_INC[] = "//";
            $this->m_INC[] = "//<!--{inc}-->";
            $this->m_INC[] = "//<!--{/inc}-->";
            $this->m_INC[] = "//";
            $this->m_INC[] = "// WARNING: this file contains SynApp2 generated content, manual edits may be overwritten";
            $this->m_INC[] = "";

            // HACK: KLUGE: we get away with reusing the dirty markup instance because the templates employ only a few specific output tokens
            $this->page_gen($appid, $synapp2_inc_filename, $template_inc_filename);
        }

        ////

        $input =  $appdir . $synapp2_inc_filename;
        $output = $input;

        if (!file_exists($input) || empty($activity))
        {
            return $result;
        }

        ////

        $lines_in = array();

        if ($lines_in = file($input))
        {
            $lines_out = array();

            $changes = false;
            $inc_on = false;

            foreach ($lines_in as $line)
            {
                if ($inc_on)
                {
                    if ($item = $this->m_custom->match_line($line))
                    {
                    //
                    // process existing line - delete or update as needed

                        $key_str = $item['key'];

                        if (isset($activity[$key_str]))
                        {
                        //
                        // process activity for this line

                            $changes = true;

                            if (empty($activity[$key_str]) || $activity[$key_str] == USE_DEFAULT)
                            {
                                eval('unset($this->m_custom->m_data' . "[APPID]['{$appid}']" .  $key_str . ');'); // delete from memory

                                unset($activity[$key_str]); // processing complete

                                continue; // delete line
                            }

                            $delim = $this->get_attribute($key_str, 'is_raw') ? '' : '"' ;

                            $line = '$this->m_data' . "[APPID]['{$appid}']" . $key_str . " = {$delim}" . $activity[$key_str] . "{$delim};\n"; // update line

                            unset($activity[$key_str]); // processing complete
                        }
                        // else
                        // {
                        //     unchanged line
                        // }
                    }
                }
                else if (strpos($line, '//<!--{inc}-->') === 0)
                {
                    $inc_on = true;
                }

                if ($inc_on && strpos($line, '//<!--{/inc}-->') === 0)
                {
                    $inc_on = false;

                    if (!empty($activity))
                    {
                    //
                    // process remaining activity as new line(s)

                        foreach ($activity as $key_str => $expr)
                        {
                            if (empty($expr) || $expr == USE_DEFAULT)
                            {
                                continue;
                            }

                            $changes = true;

                            $delim = $this->get_attribute($key_str, 'is_raw') ? '' : '"' ;

                            $lines_out[] = '$this->m_data' . "[APPID]['{$appid}']" . $key_str . " = {$delim}" . $expr . "{$delim};\n"; // add line
                        }

                        $activity = null; // all processing complete
                    }
                }

                $lines_out[] = $line; // record unchanged, updated or added line
            }

            if ($changes)
            {
                if (!writeFileContents($output, $lines_out))
                {
                    add_debug_msg("writeFileContents('$output') - failed"); // TODO: error message
                }

                ////

                $this->reset_sources_attributes_activity();
                $this->inc_sources($appid);

                ////

                $result = $output;
            }
            else
            {
                // TODO: output unaffected - message?
            }
        }

        return $result;
    }

    function inc_sources($appid)
    {
        $appdir = null;

        if (!empty($appid) && ($appdir = get_app_dir($appid)))
        {
            $inputs[] = $appdir . 'custom.inc.php';
            $inputs[] = $appdir . 'synapp2.inc.php';

            foreach ($inputs as $input)
            {
                if (file_exists($input))
                {
                    $is_protected = strpos($input, 'custom') > 0;

                    $lines_in = array();

                    if ($lines_in = file($input))
                    {
                        foreach ($lines_in as $line)
                        {
                            if ($item = $this->m_custom->match_line($line))
                            {
                                if ($is_protected || isset($this->m_sources[$item['key']]))
                                {
                                    $this->set_attribute($item['key'], 'is_protected', true);
                                }

                                $this->m_sources[$item['key']] = $item['expr'];
                            }
                        }
                    }
                }
            }
        }
    }

    ////

    function nav_handler_tools($appid, $argv)
    {
        if (is_array($argv) && count($argv) == 3)
        {
            list($request_qid, $action, $form) = $argv;

            if ($this->sub_nav_omit($form)) // TODO: HACK: KLUGE:
            {
                $action = null;
                $form = 'users'; // MAGIC:
            }

            $validator = '';
            $processor = '';

            if ($action == '_process_')
            {
                $processor = 'tools_process_' . $form;

                ////

                $pfx = 'tools_validate_';
                $sfx = 'general';

                switch ($form) // deal with a few special cases
                {
                case 'queryid':
                    $sfx = 'queryid';
                    break;
                default:
                    break;
                }

                $validator = $pfx . $sfx;
            }

            $this->inc_sources($appid);

            $items_changed = null;

            if ($processor && (!$validator || call_user_func(array($this, $validator))))
            {
                $activity = null;
                call_user_func_array(array($this, $processor), array(&$activity));
                $items_changed = $activity ? count($activity) : 0 ;
                $this->inc_gen($appid, $activity);
            }

            call_user_func_array(array($this, "tools_show_{$form}"), array($items_changed, &$this->m_ADH));
        }
        else
        {
            $this->m_ADH[] = '';
        }
    }

    function tools_show_structure($items_changed, &$elements)
    {
        $database = $this->m_custom->get_database();
        $table_names = $this->m_schema->get_table_names();

        if (!empty($table_names))
        {
            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Tools Form - Database Structure: <strong>{$database}</strong></div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            foreach ($table_names as $table_name)
            {
                if ($this->m_schema->is_sys_table($table_name))
                {
                    continue;
                }

                $elements[] = "<tr><th></th><th>Display</th><th>Column</th><th>Key</th><th>Type</th><th>Null</th><th>Default</th><th>Comment</th></tr>";

                $cols_info = $this->m_schema->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    $table_cell = "<th rowspan=\"" . count($cols_info) . "\">{$table_name}</th>";

                    foreach ($cols_info as $col_info)
                    {
                        $col_name = $col_info['Field'];

                        $display = $this->m_schema->is_pk($table_name, $col_info['Field']) ? '--' : fmt_display_name($this->m_schema->get_col_display_name($col_info)) ;
                        $not_null = preg_match('/^Y/i', $col_info['Null']) ? '' : 'NOT NULL' ;
                        $auto_increment = preg_match('/auto_increment/i', $col_info['Extra']) ? 'AUTO_INCREMENT ' : '' ;
                        $key_info = $col_info['Key'];

                        if ($this->m_schema->is_fk($table_name, $col_name))
                        {
                            $sep = empty($key_info) ? '' : ', ' ;
                            $join_table = $this->m_custom->get_parent_name($table_name, $col_name);
                            $join_col = $this->m_custom->get_parent_join_col($join_table, $table_name, $col_name);
                            $key_info = "{$key_info}{$sep}FK ( <strong>{$join_table}.{$join_col}</strong> )";
                        }

                        $elements[] = "<tr>" .
                                      $table_cell .
                                      "<td style=\"text-align:right;\"><strong><em>{$display}</em></strong></td>" .
                                      "<td>{$col_name}</td>" .
                                      "<td>{$key_info}</td>" .
                                      "<td>{$col_info['Type']}</td>" .
                                      "<td>{$not_null}</td>" .
                                      "<td>{$auto_increment}{$col_info['Default']}</td>" .
                                      "<td>{$col_info['Comment']}</td>" .
                                      "</tr>";

                        $table_cell = '';
                    }
                }
            }

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";

            if (isset($items_changed))
            {
//                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";

        }
        else
        {
            $elements[] = '';
        }
    }

    function tools_process_structure(&$activity)
    {
        // not implemented
    }

    function tools_show_queryid($items_changed, &$elements)
    {
        // NOTE: markup must be well-formed to return via xml

        $basis_item = $this->m_action->get_col_var('basis_items');
        $basis_items = null;

        $dependent_item = null;
        $dependent_items = null;
        $dependent_expr = null;

        $is_protected = false;

        ////

        $basis_iter = $this->get_qid_table_names_map();

        if (!empty($basis_iter))
        {
            if (!isset($basis_iter[$basis_item]))
            {
                $basis_item = null; // arm trigger for default value assignment
            }

            $dependent_counts = null;

            foreach ($basis_iter as $basis_qid => $basis_table)
            {
                if ($basis_qid == $basis_table)
                {
                    if (empty($basis_item))
                    {
                        $basis_item = $basis_qid;
                    }

                    $basis_items[$basis_qid] = "{$basis_qid} ({$basis_table})";
                }
                else
                {
                    if ($basis_table == $basis_item)
                    {
                       $dependent_items[$basis_qid] = "{$basis_qid} ({$basis_table})";
                    }

                    $dependent_counts[$basis_table] = !isset($dependent_counts[$basis_table]) ? 1 : $dependent_counts[$basis_table] + 1 ;
                }
            }

            if (!empty($dependent_counts))
            {
                foreach ($dependent_counts as $basis_table => $dependent_count)
                {
                    if (isset($basis_items[$basis_table]))
                    {
                        $basis_items[$basis_table] .= " [$dependent_count]";
                    }
                }
            }

            ////

            $img = '../_shared_/img/'; // TODO: configurable
            $select_size = 12; // TODO: configurable
            $expr_size = 72; // TODO: configurable
            $expr_pad = 1.5; // TODO: configurable
            $disable = $is_protected ? ' disabled="disabled"' : '' ;

            ////

            $elements[] = "<div class=\"class_layout_group_std\">";
            $elements[] = "<div class=\"class_layout_group_caption_std\">Tools Form - Secondary QueryID (table) Mapping</div>";
            $elements[] = "<table class=\"class_table_std\" cellspacing=\"0\">";
            $elements[] = "<tbody>";

            $elements[] = "<tr><th></th><th>Basis QueryID (or table)</th><th>Secondary QueryID (table)</th></tr>";

            $elements[] = "<tr>";
            $elements[] = "<th>QID TABLE</th>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('basis_items', $basis_item, $basis_items, false, min($select_size, count($basis_items)), 'on_show') . "</td>" .
                          "</tr></table></td>";
            $elements[] = "<td><table><tr style=\"border:0\">" .
                          "<td style=\"border:0\">" . $this->get_element_input_text('dependent_expr', '', false, 24) . "</td>" .
                          "<td style=\"border:0\"><button type=\"button\" name=\"insert\" title=\"Insert\" onclick=\"on_process();\">&gt;&gt;</button></td>" .
                          "<td style=\"border:0\">" . $this->get_element_select_multi_line('dependent_items', $dependent_item, $dependent_items, false, min($select_size, count($dependent_items))) . "</td>" .
                          "<td style=\"border:0\"><button type=\"button\" name=\"delete\" title=\"Delete\" onclick=\"on_process(true);\">Delete</button></td>" .
                          "</tr></table></td>";
            $elements[] = "</tr>";

            $elements[] = "</tbody>";
            $elements[] = "</table>";
            $elements[] = "<div class=\"class_vsep_std\"></div>";

            if (isset($items_changed))
            {
//                $elements[] = " {$items_changed} item" . ($items_changed == 1 ? '' : 's') . ' changed.';
            }

            $elements[] = "</div><!-- class_layout_group_std -->";
        }
        else
        {
            $elements[] = '';
        }
    }

    function tools_process_queryid(&$activity)
    {
        $dependent_expr = $this->m_action->get_col_var('dependent_expr');

        $qid = !empty($dependent_expr) ? $dependent_expr : $this->m_action->get_col_var('dependent_items');
        $table_name = !empty($dependent_expr) ? $this->m_action->get_col_var('basis_items') : USE_DEFAULT ;

        if (!empty($qid))
        {
            $this->get_protected_value($this->m_custom->get_table($qid), $is_protected);

            if (!$is_protected)
            {
                $this->m_custom->set_table($qid, $table_name, $activity);
            }
        }
    }

    function tools_show_users($items_changed, &$elements)
    {
        $elements[] = "<iframe id=\"id_report_iframe\" src=\"../synapp2/tools.users.htm\" frameborder=\"0\" width=\"800px\" height=\"450px\"></iframe>";
    }

    ////

    function tools_validate_general()
    {
        $this->m_custom->set_validator($this->m_action->get_qid(), 'DUMMY', 'tools_validate_general');
        $this->m_ADF = validate_adhoc_col_vars($this->m_action, $this->m_dbx, $this->m_custom, $this->m_schema);

        return empty($this->m_ADF);
    }

    function tools_validate_queryid()
    {
        $this->m_custom->set_validator($this->m_action->get_qid(), 'dependent_expr', 'tools_validate_queryid');
        $this->m_ADF = validate_adhoc_col_vars($this->m_action, $this->m_dbx, $this->m_custom, $this->m_schema);

        return empty($this->m_ADF);
    }

    ////

    function options_validate_display()
    {
        $col_vars = $this->m_action->get_col_vars();

        if (!empty($col_vars))
        {
            foreach ($col_vars as $n => $col_var)
            {
                $this->m_custom->set_validator($this->m_action->get_qid(), $n, 'options_validate_display');
            }

            $this->m_ADF = validate_adhoc_col_vars($this->m_action, $this->m_dbx, $this->m_custom, $this->m_schema);
        }

        return empty($this->m_ADF);
    }

    function options_validate_general()
    {
        $this->m_custom->set_validator($this->m_action->get_qid(), 'col_expr', 'options_validate_col_expr');
        $this->m_ADF = validate_adhoc_col_vars($this->m_action, $this->m_dbx, $this->m_custom, $this->m_schema);

        return empty($this->m_ADF);
    }

    function options_validate_extra()
    {
        $this->m_custom->set_validator($this->m_action->get_qid(), 'col_expr', 'options_validate_extra');
        $this->m_ADF = validate_adhoc_col_vars($this->m_action, $this->m_dbx, $this->m_custom, $this->m_schema);

        return empty($this->m_ADF);
    }

    function options_validate_reporting_title()
    {
        $this->m_custom->set_validator($this->m_action->get_qid(), 'title_expr', 'options_validate_reporting_title');
        $this->m_ADF = validate_adhoc_col_vars($this->m_action, $this->m_dbx, $this->m_custom, $this->m_schema);

        return empty($this->m_ADF);
    }
}
//
// class markup

////

define('TOOLTIP_CSV_EXPR', 'Enter a comma separated list of column names (or aliases)');
define('TOOLTIP_SQL_EXPR', 'Enter an SQL sub-expression or term');
define('TOOLTIP_PHP_EXPR', 'Enter a PHP expression that evaluates to (or returns) a string value');
define('TOOLTIP_PHP_SQL_EXPR', 'Enter a PHP expression that evaluates to (or returns) an SQL sub-expression or term');

function options_validate_col_expr($col_name, $col_value, $display_name, &$col_vars)
{
    $msg = '';

    if (!empty($col_value) && $col_value != USE_DEFAULT && ($expr_msg = check_expr($col_value)))
    {
        $msg = "The Column expression triggers an error - {$expr_msg}";
        $msg .= " \nYou must correct the expression before it can be assigned as a customization value.";
    }

    return $msg;
}

function options_validate_col_expr_raw($col_name, $col_value, $display_name, &$col_vars)
{
    $msg = '';

    // TODO: TBD: checks are not exhaustive, but better than nothing
    //
    if (!empty($col_value) && $col_value != USE_DEFAULT)
    {
        if (!preg_match('/[\$\(\"\']+/', $col_value)) // no $, quotes or parens - looks like a literal
        {
            $msg = "The {$display_name} expression appears to be plain literals,";
            $msg .= " \nsurround it with matching quotes, e.g., \"{$col_value}\" or '{$col_value}'";
        }
        else if ($expr_msg = check_expr($col_value, true))
        {
            $msg = "The {$display_name} expression triggers an error - {$expr_msg}";
            $msg .= " \nYou must correct the expression before it can be assigned as a customization value.";
        }

        if ($msg)
        {
            $msg .= " \n" . TOOLTIP_PHP_EXPR;
        }
    }

    return $msg;
}

////

function options_validate_display($col_name, $col_value, $display_name, &$col_vars)
{
    $msg = '';

    if (strlen($col_value))
    {
        if (strpos($col_name, 'COL_SIZE') ||
            strpos($col_name, 'COL_EDITOR_ROWS') ||
            strpos($col_name, 'LIMIT_ROWS'))
        {
            if (!preg_match('/^[1-9][0-9]*$/', $col_value))
            {
                $msg = "{$col_name} must be empty or INT >= 1";
            }
        }
        else if (strpos($col_name, 'COL_FORMAT') > 0)
        {
            // TODO: TBD: does not insure that the function or format is valid, but better than nothing
            //
            if (preg_match('/[\&\<\>]+/', $col_value)) // don't risk markup [that might not be well-formed]
            {
                $msg = "{$col_name} expression may not contain certain characters: [ &amp; &lt; &gt; ]";
                $msg .= " \nIf you need more flexibilty, define a new function and provide its name here.";
            }
            else
            {
                preg_match('/^([a-zA-Z_][[a-zA-Z_]*)( *, *([^,]*))?$/', $col_value, $matches);

                if (!empty($matches[1]))
                {
                    $func_name = $matches[1];

                    if (!is_callable($func_name))
                    {
                        $msg = "{$col_name} function is not callable: {$func_name}";
                    }
                    else if (!empty($matches[3]) && ($expr_msg = check_expr($matches[3])))
                    {
                        $msg = "{$col_name}, {$func_name} format specification is malformed - {$expr_msg}";
                    }
                }
                else if ($expr_msg = check_expr($col_value))
                {
                    $msg = "The {$col_name} expression triggers an error - {$expr_msg}";
                }
            }

            if ($msg)
            {
                $msg .= " \nA COL_FORMAT expression must be empty or have the form: function_name[,format]";
            }
        }
    }

    return $msg;
}

function options_validate_extra($col_name, $col_value, $display_name, &$col_vars)
{
    return options_validate_col_expr_raw($col_name, $col_value, 'Extra', $col_vars);
}

function options_validate_reporting_title($col_name, $col_value, $display_name, &$col_vars)
{
    $msg = '';

    if (!empty($col_value) && $col_value != USE_DEFAULT)
    {
        $display_name = 'Title';

        if (preg_match('/[\&\<\>]+/', $col_value)) // don't risk markup [that might not be well-formed]
        {
            $msg = "The {$display_name} expression may not contain certain characters: [ &amp; &lt; &gt; ]";
        }
        else
        {
            $msg = options_validate_col_expr_raw($col_name, $col_value, $display_name, $col_vars);
        }
    }

    return $msg;
}

////

function tools_validate_general($col_name, $col_value, $display_name, &$col_vars)
{
    $msg = '';

    // do nothing

    return $msg;
}

function tools_validate_queryid($col_name, $col_value, $display_name, &$col_vars)
{
    $msg = '';

    if (!empty($col_value) && $col_value != USE_DEFAULT && preg_match('/[^a-zA-Z0-9_\(\)\-]+/', $col_value))
    {
        $msg = "The Secondary QueryID expression may only contain letters, digits, underscores, dashes or parentheses.";
        $msg .= " You must correct the expression before it can be assigned as a customization value.";
    }

    return $msg;
}

////

?>
