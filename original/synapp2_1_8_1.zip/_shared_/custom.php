<?php

/* custom.php - SynApp2 manager for application specific customization
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: custom.php,v 1.33 2011/02/01 21:28:30 richard Exp $
*/

class custom
{
    var $m_dbx = null;
    var $m_appid = null;
    var $m_qid = null;
    var $m_data = null;
    var $m_pk_map = null;

    function custom(&$dbx, $appid, $qid)
    {
        $this->m_dbx = &$dbx;
        $this->m_appid = $appid;
        $this->m_qid = $qid;
    }

    function build()
    {
        define('SYNAPP2', 'synapp2');
        define('APPID', '_appid_');
        define('QID', '_qid_');

        define('AUTH_APPID', '_auth_appid_');
        define('AUTH_QID', '_auth_qid_');
        define('AUTH_PID', '_auth_pid_');
        define('AUTH_RID', '_auth_rid_');
        define('AUTH_RECS', '_auth_recs_');
        define('AUTH_ADD', '_auth_add_');
        define('AUTH_EDIT', '_auth_edit_');
        define('AUTH_DELETE', '_auth_delete_');
        define('AUTH_PROCESS', '_auth_process_');

        define('DATABASE', '_database_');
        define('TABLE', '_table_');
        define('ORDER', '_order_');
        define('MACRO', '_macro_');
        define('LIST_MACRO', '_list_macro_');
        define('LIST_MACRO_ORDER', '_list_macro_order_');
        define('LIST_MACRO_FILTER', '_list_macro_filter_');
        define('EXTRA', '_extra_');
        define('OMIT', '_omit_');
        define('INCL', '_incl_');
        define('TAB_ORDER', '_tab_order_');
        define('QUERY', '_query_');
        define('SUBQUERY', '_subquery_');
        define('FETCH', '_fetch_');

        define('TITLE', '_title_');
        define('LEGEND', '_legend_');
        define('LIMIT_ROWS', '_limit_rows_');

        define('COL_OMIT', '_col_omit_');
        define('COL_SIZE', '_col_size_');
        define('COL_ALIGN', '_col_align_');
        define('COL_FORMAT', '_col_format_');
        define('COL_EDITOR', '_col_editor_');
        define('COL_EDITOR_ROWS', '_col_editor_rows_');
        define('COL_ATTRS', '_col_attrs_');
        define('COL_ORDER', '_col_order_');

        define('USE_DEFAULT', '-- default --');
        define('SWITCH_ON', 'on');
        define('SWITCH_OFF', 'off');

        define('ALIGN_L', 'L');
        define('ALIGN_J', 'J');
        define('ALIGN_C', 'C');
        define('ALIGN_R', 'R');

        define('PAGE_ORIENTATION_PORTRAIT', 'portrait');
        define('PAGE_ORIENTATION_LANDSCAPE', 'landscape');

        define('PAGE_SIZE_LETTER', 'letter');
        define('PAGE_SIZE_LEGAL', 'legal');
        define('PAGE_SIZE_A3', 'A3');
        define('PAGE_SIZE_A4', 'A4');
        define('PAGE_SIZE_A5', 'A5');

        define('FONT_FAMILY_ARIAL', 'arial');
        define('FONT_FAMILY_COURIER', 'courier');
        define('FONT_FAMILY_HELVETICA', 'helvetica');
        define('FONT_FAMILY_TIMES', 'times');

        define('EDITOR_INPUT', 'input');
        define('EDITOR_TEXTAREA', 'textarea');

        define('RPT_PAGE_SIZE', '_rpt_page_size_');
        define('RPT_PAGE_ORIENTATION', '_rpt_page_orientation_');
        define('RPT_FONT_SIZE', '_rpt_font_size_');
        define('RPT_FONT_FAMILY', '_rpt_font_family_');
        define('RPT_CELL_BORDER', '_rpt_cell_border_');
        define('RPT_ROW_SHADE', '_rpt_row_shade_');
        define('RPT_ROW_SIZE', '_rpt_row_size_');
        define('DETAIL_SUMMARY_COLS', '_detail_summary_cols_');

        define('EXPORT_TYPE', '_export_type_');
        define('EXPORT_TYPE_TXT_TAB', '_export_type_txt_tab_');
        define('EXPORT_TYPE_DESCR_TXT_TAB', 'Text (Tab-delimited)');
        define('EXPORT_TYPE_TXT_CSV', '_export_type_txt_csv_');
        define('EXPORT_TYPE_DESCR_TXT_CSV', 'Text (Comma-separated values)');
        define('EXPORT_TYPE_ODS', '_export_type_ods_');
        define('EXPORT_TYPE_DESCR_ODS', 'OpenDocument Spreadsheet');

        define('CUSTOM', '_custom_');
        define('KEYMAP', '_keymap_');
        define('HTMLDBPT', 'HTMLDB_PLAN_TABLE');

        define('TABLE_NAME', 'table_name');
        define('COL_NAME', 'col_name');
        define('JOIN_TABLE', 'join_table');
        define('JOIN_COL', 'join_col');

        define('CONSTRAINT', 'constraint');
        define('OFFSET', 'offset');

        define('PATH', 'path');
        define('BASIS_INDEX', 'basis_index');
        define('PATH_INDEX', 'path_index');
        define('TIER_TABLE', 'tier_table');

        define('DEFAULT_PK_NAME', 'id');
        define('DEFAULT_FK_PREFIX', 'id_');

        define('CONFIG', '_config_');
        define('SHARED', '_shared_');
        define('COMMENT', '_RESERVED_'); // reserved to support field comment dependencies a'la MySQL, for other DB engines

        define('IFORM', 'iform');
        define('DFORM', 'dform');
        define('SFORM', 'sform');
        define('TFORM', 'tform');
        define('AFORM', 'aform');
        define('FFORM', 'fform');
        define('RFORM', 'rform');

        define('NAV', '_nav_');
        define('RPT', '_rpt_');

        define('VALIDATOR', '_validator_');
        define('VALIDATOR_PRIMARY', '_validator_primary_');
        define('VALIDATOR_SECONDARY', '_validator_secondary_');

        define('PROCESS', '_process_');
        define('PROCESS_ON_INIT', '_process_on_init_');
        define('PROCESS_MAIN', '_process_main_');
        define('PROCESS_MAIN_ON_OPEN', '_process_main_on_open_');
        define('PROCESS_MAIN_ON_QUERY', '_process_main_on_query_');
        define('PROCESS_MAIN_ON_CLOSE', '_process_main_on_close_');
        define('PROCESS_ON_EXIT', '_process_on_exit_');

        define('A_ID', '_a_id_');
        define('A_HREF', '_a_href_');
        define('A_TEXT', '_a_text_');

        define('TEMP_LOC', '_temp_loc_');
        define('MEDIA_LOC', '_media_loc_');

        define('MEDIA_TYPE', '_media_type_');
        define('TYPE_ANY', '_type_any_');
        define('TYPE_TEXT', '_type_text_');
        define('TYPE_VIDEO', '_type_video_');
        define('TYPE_IMAGE', '_type_image_');

        ////

        define('UPW_STD_QID', 'users'); // default qid for username, password management
        define('UPW_STD_TABLE', 'users'); // default table_name for username, password management
        define('UPW_STD_COL_USERNAME', 'username'); // default col_name for username value
        define('UPW_STD_COL_PASSWORD', 'password'); // default col_name for password value
        define('UPW_STD_FUNC_ENCRYPT', 'password'); // default dbx password hash function
        define('UPW_STD_PROCESS_EXPR', 'encrypt');  // default regex pattern fragment to trigger password hashing
        define('UPW_STD_COL_ACTION', 'password_action'); // default pseudo-col name for password action value

        ////

        ini_set('display_errors', 1); // prevent PHP from registering HTTP 500 internal server error during includes

        $error_level = error_reporting(E_ALL);

        $custom_inc = 'custom.inc.php';

        include($custom_inc);

        $app_custom_inc = "../{$this->m_appid}/{$custom_inc}";

        if (file_exists($app_custom_inc))
        {
            include($app_custom_inc);
        }

        $synapp2_inc = "../{$this->m_appid}/synapp2.inc.php";

        if (file_exists($synapp2_inc))
        {
            include($synapp2_inc);
        }

        error_reporting($error_level);

        ini_restore('display_errors');

        ////

        $this->m_data[APPID]['login'][DATABASE] = '';
    }

    function push_pk_map(&$pkeys, &$table_col_names)
    {
        if (!empty($table_col_names))
        {
            foreach ($table_col_names as $table_name => $col_names)
            {
                $join_col = null;

                if (!empty($pkeys[$table_name])) // the PK coming from the schema trumps all
                {
                    $join_col = $pkeys[$table_name];
                    $this->m_pk_map[$table_name] = $join_col;
                    $this->set_keymap($table_name, $join_col, $table_name, $join_col);
                    continue; // done - pk mapped for $table_name mapped from schema
                }

                if ($keymaps = $this->get_keymaps($this->get_database()))
                {
                    foreach ($keymaps as $keymap)
                    {
                        if ($keymap[TABLE_NAME] == $table_name && $keymap[JOIN_TABLE] == $table_name)
                        {
                            if (in_array($keymap[JOIN_COL], $col_names))
                            {
                                $this->m_pk_map[$table_name] = $keymap[JOIN_COL];
                                continue 2; // done - pk mapped for $table_name mapped from inc.php
                            }
                        }
                    }
                }

                if ($join_col = $this->m_dbx->get_query_value($this->m_dbx->get_keymap_table_query(
                                                              "select " . COL_NAME . " as \"" . COL_NAME . "\" from " . get_database_physical() . '.' . KEYMAP .
                                                              " where " . TABLE_NAME . "='$table_name' and " . JOIN_TABLE . "='$table_name'")))
                {
                    if (in_array($join_col, $col_names))
                    {
                        $this->m_pk_map[$table_name] = $join_col;
                        $this->set_keymap($table_name, $join_col, $table_name, $join_col);
                        continue; // done - pk mapped for $table_name mapped from $table_name._keymap_
                    }
                }

                if (!$join_col)
                {
                    reset($col_names);
                    $join_col = current($col_names); // default to 1st column
                    $this->m_pk_map[$table_name] = $join_col;
                    $this->set_keymap($table_name, $join_col, $table_name, $join_col);
                    continue;  // done - pk mapped for $table_name mapped from first col_name
                }
            }
        }
    }

    function get_pk_name($table_name, $qualified = false, $alternate_appid = null)
    {
        assert('!$alternate_appid'); // TODO: TBD: $alternate_appid cannot be useful unless schema instance is in sync with $this??

        $result = null;

        if ($pk_name = isset($this->m_pk_map[$table_name]) ? $this->m_pk_map[$table_name] : null)
        {
            $result = $qualified ? "$table_name.$pk_name" : $pk_name ;
        }

        return $result;
    }

    function get_parent_name($table_name, $fk_name, $alternate_appid = null)
    {
        $result = null;

        $database = $this->get_database($alternate_appid);

        if ($keymaps = $this->get_keymaps($database))
        {
            foreach ($keymaps as $keymap)
            {
                if (2 == count(array_intersect_assoc(array(TABLE_NAME=>$table_name, COL_NAME=>$fk_name), $keymap)))
                {
                    if ($keymap[JOIN_TABLE] != $table_name)
                    {
                        $result = $keymap[JOIN_TABLE];
                        break;
                    }
                }
            }
        }

        if (empty($result))
        {
            $result = $this->m_dbx->get_query_value($this->m_dbx->get_keymap_table_query(
                                                    "select " . JOIN_TABLE . " as \"" . JOIN_TABLE . "\" from " . get_database_physical($alternate_appid) . '.' . KEYMAP .
                                                    " where " . TABLE_NAME . "='$table_name' and " . COL_NAME . "='$fk_name' and " . JOIN_TABLE . "!='$table_name'"));
        }

        if (empty($result) && strpos($fk_name, DEFAULT_FK_PREFIX) === 0)
        {
            $result = substr($fk_name, strlen(DEFAULT_FK_PREFIX));
        }

        return $result;
    }

    function get_parent_join_col($parent_name, $child_name, $child_col, $alternate_appid = null)
    {
        $result = null;

        $database = $this->get_database($alternate_appid);

        if ($keymaps = $this->get_keymaps($database))
        {
            foreach ($keymaps as $keymap)
            {
                if (3 == count(array_intersect_assoc(array(TABLE_NAME=>$child_name, COL_NAME=>$child_col, JOIN_TABLE=>$parent_name), $keymap)))
                {
                    $result = $keymap[JOIN_COL];
                    break;
                }
            }
        }

        if (empty($result))
        {
            $result = $this->m_dbx->get_query_value($this->m_dbx->get_keymap_table_query(
                                                    "select " . JOIN_COL . " as \"" . JOIN_COL . "\" from " . get_database_physical($alternate_appid) . '.' . KEYMAP .
                                                    " where " . TABLE_NAME . "='$child_name' and " . COL_NAME . "='$child_col' and " . JOIN_TABLE . "='$parent_name'"));
        }

        if (empty($result) && !empty($parent_name) && !empty($child_name) && !empty($child_col))
        {
            $result = $this->get_pk_name($parent_name);
        }

        return $result;
    }

    function get_child_join_cols($parent_name, $child_name, $alternate_appid = null)
    {
        $result = null;

        $database = $this->get_database($alternate_appid);

        if ($keymaps = $this->get_keymaps($database))
        {
            foreach ($keymaps as $keymap)
            {
                if (2 == count(array_intersect_assoc(array(TABLE_NAME=>$child_name, JOIN_TABLE=>$parent_name), $keymap)))
                {
                    $result[] = $keymap[COL_NAME];
                }
            }
        }

        if (empty($result))
        {
            $recs = $this->m_dbx->get_query_records($this->m_dbx->get_keymap_table_query(
                                                    "select " . COL_NAME . " as \"" . COL_NAME . "\" from " . get_database_physical($alternate_appid) . '.' . KEYMAP .
                                                    " where " . TABLE_NAME . "='$child_name' and " . JOIN_TABLE . "='$parent_name'"));
            if (!empty($recs))
            {
                foreach ($recs as $rec)
                {
                    $result[] = $rec[COL_NAME];
                }
            }
        }

        if (empty($result) && !empty($parent_name) && !empty($child_name))
        {
            $result[] = DEFAULT_FK_PREFIX . $parent_name;
        }

        return $result;
    }

    function get_key_cols($table_name, $alternate_appid = null)
    {
        $result = null;

        $database = $this->get_database($alternate_appid);

        if ($keymaps = $this->get_keymaps($database))
        {
            foreach ($keymaps as $keymap)
            {
                if (1 == count(array_intersect_assoc(array(JOIN_TABLE=>$table_name), $keymap)))
                {
                    $result[] = $keymap[JOIN_COL];
                }
            }
        }

        if (empty($result))
        {
            $recs = $this->m_dbx->get_query_records($this->m_dbx->get_keymap_table_query(
                                                    "select " . JOIN_COL . " as \"" . JOIN_COL . "\" from " . get_database_physical($alternate_appid) . '.' . KEYMAP .
                                                    " where " . JOIN_TABLE . "='$table_name'"));
            if (!empty($recs))
            {
                foreach ($recs as $rec)
                {
                    $result[] = $rec[JOIN_COL];
                }
            }
        }

        if (empty($result) && !empty($table_name))
        {
            $result[] = $this->get_pk_name($table_name);
        }

        return $result;
    }

    function get_sql_calc_found_rows()
    {
        return $this->m_dbx->get_sql_calc_found_rows();
    }

    function get_appid($alternate_appid = null)
    {
        return !empty($alternate_appid) ? $alternate_appid : $this->m_appid ;
    }

    function get_database($alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);
        return isset($this->m_data[APPID][$appid][DATABASE]) ? $this->m_data[APPID][$appid][DATABASE] : $appid ;
    }

    function get_keymaps($database)
    {
        return !empty($this->m_data[DATABASE][$database][KEYMAP]) ? $this->m_data[DATABASE][$database][KEYMAP] : null ;
    }

    function set_keymap($table_name, $col_name, $join_table, $join_col, $alternate_appid = null)
    {
        if ($database = $this->get_database($alternate_appid))
        {
            $entry = array(TABLE_NAME=>$table_name, COL_NAME=>$col_name, JOIN_TABLE=>$join_table, JOIN_COL=>$join_col);

            if ($keymaps = $this->get_keymaps($database))
            {
                foreach ($keymaps as $i => $keymap)
                {
                    if (2 == count(array_intersect_assoc(array(TABLE_NAME=>$table_name, COL_NAME=>$col_name), $keymap)))
                    {
                        $this->m_data[DATABASE][$database][KEYMAP][$i] = $entry;
                        $entry = null;
                        break;
                    }
                }
            }

            if ($entry)
            {
                $this->m_data[DATABASE][$database][KEYMAP][] = $entry;
            }
        }
    }

    function get_qid($alternate_qid = null)
    {
        return !empty($alternate_qid) ? $alternate_qid : $this->m_qid ;
    }

    function get_table($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][TABLE]");

        return !empty($this->m_data[APPID][$appid][QID][$qid][TABLE]) ? $this->m_data[APPID][$appid][QID][$qid][TABLE] : $qid ;
    }

    function set_table($qid, $table_name, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            !empty($table_name) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][TABLE]) ||
             $this->m_data[APPID][$appid][QID][$qid][TABLE] != $table_name))
        {
            $this->m_data[APPID][$appid][QID][$qid][TABLE] = $table_name;

            $key_str = "[QID]['{$qid}'][TABLE]";

            $activity[$key_str] = $table_name;
        }

        return $key_str;
    }

    function get_qid_table_names()
    {
        $appid = $this->get_appid();

        $result = null;

        if (!empty($this->m_data[APPID][$appid][QID]))
        {
            foreach ($this->m_data[APPID][$appid][QID] as $qid => $elements)
            {
                if (!empty($this->m_data[APPID][$appid][QID][$qid][TABLE]))
                {
                    $result[$qid] = $this->m_data[APPID][$appid][QID][$qid][TABLE];
                }
            }
        }

        return $result;
    }

    function set_validator($qid, $col, $func, $context_key = VALIDATOR_PRIMARY)
    {
        $appid = $this->get_appid();

        if (!empty($appid) &&
            !empty($qid) &&
            !empty($col) &&
            !empty($func) &&
            ($context_key == VALIDATOR_PRIMARY || $context_key == VALIDATOR_SECONDARY))
        {
            $this->m_data[APPID][$appid][QID][$qid][VALIDATOR][$context_key][$col] = $func;
        }
    }

    function get_validator($col, $context_key, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        return !empty($this->m_data[APPID][$appid][QID][$qid][VALIDATOR][$context_key][$col]) ? $this->m_data[APPID][$appid][QID][$qid][VALIDATOR][$context_key][$col] : null ;
    }

    function set_username_password_mgr($qid = UPW_STD_QID)
    {
        $this->set_validator($qid, UPW_STD_COL_USERNAME, 'validate_username_general');
        $this->set_validator($qid, UPW_STD_COL_PASSWORD, 'validate_password_general');
    }

    function bind_process($qid, $func, $context_key = PROCESS_MAIN)
    {
        $appid = $this->get_appid();

        if (!empty($appid) &&
            !empty($qid) &&
            !empty($func) &&
            !empty($context_key))
        {
            $this->m_data[APPID][$appid][QID][$qid][PROCESS][$context_key] = $func;
        }
    }

    function get_process($context_key, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        return !empty($this->m_data[APPID][$appid][QID][$qid][PROCESS][$context_key]) ? $this->m_data[APPID][$appid][QID][$qid][PROCESS][$context_key] : null ;
    }

    function get_query($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        return !empty($this->m_data[APPID][$appid][QID][$qid][QUERY]) ? $this->m_data[APPID][$appid][QID][$qid][QUERY] : null ;
    }

    function get_subquery($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        return !empty($this->m_data[APPID][$appid][QID][$qid][SUBQUERY]) ? $this->m_data[APPID][$appid][QID][$qid][SUBQUERY] : null ;
    }

    function get_fetch($col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        return !empty($this->m_data[APPID][$appid][QID][$qid][FETCH][$col]) ? $this->m_data[APPID][$appid][QID][$qid][FETCH][$col] : null ;
    }

    function get_fetch_cols($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        return !empty($this->m_data[APPID][$appid][QID][$qid][FETCH]) ? $this->m_data[APPID][$appid][QID][$qid][FETCH] : null ;
    }

    ////

    function match_line($line)
    {
        $result = null;

        if (preg_match('/^.*(\[\s*QID\s*])([^=]*)(=\s*){1}(.*)\s*;[^;]*$/', $line, $matches))
        {
        //
        // rigorous enough to handle the subset of interactively modifiable customization items supported by version 0.1.8

            $result = array('key'=>preg_replace('/\s/', '', $matches[1]) . preg_replace('/\s/', '', $matches[2]), 'expr'=>trim($matches[4]));
        }

        return $result;
    }

    function get_key_symbol($def_str)
    {
        static $symbols = null;

        if (!isset($symbols))
        {
            $all_defined_constants = get_defined_constants(true); // PHP4.1

            if (!empty($all_defined_constants['user']))
            {
                $symbols = array_flip($all_defined_constants['user']); // the ones we care about are estabished with $this class instance
            }
        }

        ////

        return !empty($symbols[$def_str]) ? $symbols[$def_str] : null ;
    }

    function get_last_key()
    {
        return isset($this->m_last_key) ? $this->m_last_key : null ; // pseudo data member
    }

    function set_last_key($k)
    {
        $this->m_last_key = $k;
    }

    ////

    function get_order($alternate_qid = null, $alternate_order = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);
        $table_name = $this->get_table($alternate_qid);

        ////

        if (!empty($alternate_order) && is_array($tokens = explode(',', $alternate_order))) // col1,col2,za,col3
        {
            $alternate_order_expr = '';
            $sep = '';
            $za = false;

            $other_cols = array();

            if (!empty($this->m_data[APPID][$appid][QID][$qid][EXTRA]))
            {
                $recs = $this->m_data[APPID][$appid][QID][$qid][EXTRA];

                if (!empty($recs))
                {
                    foreach ($recs as $basis_col => $basis_recs)
                    {
                        foreach ($basis_recs as $col_name => $col_expr)
                        {
                            $other_cols[$col_name] = $col_name;
                        }
                    }
                }
            }

            if (!empty($this->m_data[APPID][$appid][QID][$qid][SUBQUERY]))
            {
                $recs = $this->m_data[APPID][$appid][QID][$qid][SUBQUERY];

                if (!empty($recs))
                {
                    foreach ($recs as $col_name => $col_expr)
                    {
                        $other_cols[$col_name] = $col_name;
                    }
                }
            }

            foreach ($tokens as $col_name)
            {
                if ($col_name = trim($col_name))
                {
                    if ($col_name == 'za')
                    {
                        $za = true;
                        continue;
                    }

                    $full_name = $table_name . '.' . $col_name;
                    $is_macro_col = strpos($col_name, $table_name . '_') === 0; // TODO: HACK: KLUGE: encapuslate
                    $col_var_name = $is_macro_col || !empty($other_cols[$col_name]) ? $col_name : $full_name ;

                    if ($za)
                    {
                        $col_var_name .= ' desc';
                        $za = false;
                    }

                    $alternate_order_expr .= $sep . $col_var_name;
                    $sep = ', ';
                }
            }

            if (!empty($alternate_order_expr))
            {
                return $alternate_order_expr;
            }
        }

        ////

        $this->set_last_key("[QID]['{$qid}'][ORDER]");

        return !empty($this->m_data[APPID][$appid][QID][$qid][ORDER]) ? $this->m_data[APPID][$appid][QID][$qid][ORDER] : $table_name . '.' . $this->get_pk_name($table_name) ;
    }

    function set_order($qid, $col_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][ORDER]) ||
             $this->m_data[APPID][$appid][QID][$qid][ORDER] !== $col_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][ORDER] = $col_expr;

            $key_str = "[QID]['{$qid}'][ORDER]";

            $activity[$key_str] = $col_expr;
        }

        return $key_str;
    }

    function get_macro($col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][MACRO]['{$col}']");

        return isset($this->m_data[APPID][$appid][QID][$qid][MACRO][$col]) ? $this->m_data[APPID][$appid][QID][$qid][MACRO][$col] : null ;
    }

    function set_macro($qid, $col, $macro_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            !empty($col) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][MACRO][$col]) ||
             $this->m_data[APPID][$appid][QID][$qid][MACRO][$col] !== $macro_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][MACRO][$col] = $macro_expr;

            $key_str = "[QID]['{$qid}'][MACRO]['{$col}']";

            $activity[$key_str] = $macro_expr;
        }

        return $key_str;
    }

    function get_list_macro($col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][LIST_MACRO]['{$col}']");

        return isset($this->m_data[APPID][$appid][QID][$qid][LIST_MACRO][$col]) ? $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO][$col] : null;
    }

    function set_list_macro($qid, $col, $macro_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            !empty($col) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][LIST_MACRO][$col]) ||
             $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO][$col] !== $macro_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO][$col] = $macro_expr;

            $key_str = "[QID]['{$qid}'][LIST_MACRO]['{$col}']";

            $activity[$key_str] = $macro_expr;
        }

        return $key_str;
    }

    function get_list_macro_order($col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][LIST_MACRO_ORDER]['{$col}']");

        return isset($this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_ORDER][$col]) ? $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_ORDER][$col] : null ;
    }

    function set_list_macro_order($qid, $col, $col_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            !empty($col) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_ORDER][$col]) ||
             $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_ORDER][$col] !== $col_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_ORDER][$col] = $col_expr;

            $key_str = "[QID]['{$qid}'][LIST_MACRO_ORDER]['{$col}']";

            $activity[$key_str] = $col_expr;
        }

        return $key_str;
    }

    function get_list_macro_filter($col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][LIST_MACRO_FILTER]['{$col}']");

        return !empty($this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_FILTER][$col]) ? $this->m_data[APPID][$appid][QID][$qid][LIST_MACRO_FILTER][$col] : null ;
    }

    function set_list_macro_filter($qid, $col, $col_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        add_debug_msg('set_list_macro_filter() - function not implemented');

        return $key_str;
    }

    function get_extra($basis_col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return isset($this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col]) ? $this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col] : null ;
    }

    function set_extra($qid, $basis_col, $alias_col, $extra_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            !empty($basis_col) &&
            !empty($alias_col) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col][$alias_col]) ||
             $this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col][$alias_col] != $extra_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col][$alias_col] = $extra_expr;

            $key_str = "[QID]['{$qid}'][EXTRA]['{$basis_col}']['{$alias_col}']";

            $activity[$key_str] = $extra_expr;
        }

        return $key_str;
    }

    function get_extra_col_alias_names($basis_col, $alternate_qid = null)
    {
        $extra_cols = $this->get_extra($basis_col, $alternate_qid);

        return !empty($extra_cols) ? array_keys($extra_cols) : null ;
    }

    function get_extra_col_expr($basis_col, $alias_col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][EXTRA]['{$basis_col}']['{$alias_col}']");

        return isset($this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col][$alias_col]) ? $this->m_data[APPID][$appid][QID][$qid][EXTRA][$basis_col][$alias_col] : null ;
    }

    function get_detail_summary_cols($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $cols = null;

        if (!empty($this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS]))
        {
            foreach ($this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS] as $expr_index => $summary_col)
            {
                $tokens = explode(',', $summary_col);

                if (is_array($tokens) && !empty($tokens))
                {
                    $summary_tokens = array();

                    foreach ($tokens as $token)
                    {
                        $summary_tokens[] = trim($token);
                    }

                    $cols[$expr_index] = $summary_tokens;
                }
            }

            if (!empty($cols))
            {
                ksort($cols);
            }
        }

        return $cols;
    }

    function set_detail_summary_cols($qid, $expr_index, $col_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        $expr_index = max(0, (int)$expr_index);

        if (!empty($qid) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS][$expr_index]) ||
             $this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS][$expr_index] != $col_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS][$expr_index] = $col_expr;

            $key_str = "[QID]['{$qid}'][DETAIL_SUMMARY_COLS][{$expr_index}]";

            $activity[$key_str] = $col_expr;
        }

        return $key_str;
    }

    function get_detail_summary_col_expr($expr_index, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][DETAIL_SUMMARY_COLS][{$expr_index}]");

        return isset($this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS][$expr_index]) ? $this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS][$expr_index] : null ;
    }

    function get_state_var($qid, $pid, $var_name)
    {
        $appid = $this->get_appid();

        $result = null;

        if (isset($this->m_data[APPID][$appid][QID][$qid][SYNAPP2][$pid][$var_name]))
        {
            $var_value = $this->m_data[APPID][$appid][QID][$qid][SYNAPP2][$pid][$var_name];

            $result = is_string($var_value) ? trim($var_value) : $var_value ;
        }

        return $result;
    }

    function set_state_var($qid, $pid, $var_name, $var_value, &$activity)
    {
        $appid = $this->get_appid();

        if (!empty($appid) && !empty($qid) && !empty($pid) && !empty($var_name))
        {
            $this->m_data[APPID][$appid][QID][$qid][SYNAPP2][$pid][$var_name] = $var_value;

            $key_str = "[QID]['{$qid}'][SYNAPP2]['{$pid}']['{$var_name}']";

            $activity[$key_str] = $var_value;
        }
    }

    function get_option_value($qid, $option_key)
    {
        $appid = $this->get_appid();

        $result = null;

        $this->set_last_key("[QID]['{$qid}'][" . $this->get_key_symbol($option_key) . "]");

        if (isset($this->m_data[APPID][$appid][QID][$qid][$option_key]))
        {
            $option_value = $this->m_data[APPID][$appid][QID][$qid][$option_key];

            $result = is_string($option_value) ? trim($option_value) : $option_value ;
        }

        return $result;
    }

    function set_option_value($qid, $option_key, $option_value, &$activity)
    {
        $appid = $this->get_appid();

        if (empty($option_value) || $option_value == USE_DEFAULT)
        {
            $option_value = '';
        }

        $key_str = '';

        if ($this->get_option_value($qid, $option_key) != $option_value)
        {
            $this->m_data[APPID][$appid][QID][$qid][$option_key] = $option_value;

            $key_str = "[QID]['{$qid}'][" . $this->get_key_symbol($option_key) . "]";

            $activity[$key_str] = $option_value;
        }

        return $key_str;
    }

    function get_tier_table($qid, $basis_key)
    {
        $appid = $this->get_appid();

        $result = null;

        if (!empty($this->m_data[APPID][$appid][QID][$qid][TIER_TABLE][$basis_key]))
        {
            $elements = explode(',', $this->m_data[APPID][$appid][QID][$qid][TIER_TABLE][$basis_key]);

            if (is_array($elements) && count($elements) == 2)
            {
                $result[PATH_INDEX] = trim($elements[0]);
                $result[TIER_TABLE] = trim($elements[1]);
            }
        }

        return $result;
    }

    function set_tier_table($qid, $basis_key, $csv, &$activity)
    {
        $appid = $this->get_appid();

        $this->m_data[APPID][$appid][QID][$qid][TIER_TABLE][$basis_key] = $csv;

        $key_str = "[QID]['{$qid}'][TIER_TABLE]['{$basis_key}']";

        $activity[$key_str] = $csv;

        return $key_str;
    }

    function get_col_option($qid, $form_key, $col_name, $option_key)
    {
        $appid = $this->get_appid();

        $result = '';

        $this->set_last_key("[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "]['{$col_name}'][" .  $this->get_key_symbol($option_key) . "]");

        if (isset($this->m_data[APPID][$appid][QID][$qid][$form_key][$col_name][$option_key]))
        {
            $var_value = $this->m_data[APPID][$appid][QID][$qid][$form_key][$col_name][$option_key];

            $result = is_string($var_value) ? trim($var_value) : $var_value ;
        }

        return $result;
    }

    function set_col_option($qid, $form_key, $col_name, $option_key, $option_value, &$activity)
    {
        $appid = $this->get_appid();

        if (empty($option_value) || $option_value == USE_DEFAULT)
        {
            $option_value = '';
        }

        $key_str = '';

        if ($this->get_col_option($qid, $form_key, $col_name, $option_key) != $option_value)
        {
            $this->m_data[APPID][$appid][QID][$qid][$form_key][$col_name][$option_key] = $option_value;

            $key_str = "[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "]['{$col_name}'][" .  $this->get_key_symbol($option_key) . "]";

            $activity[$key_str] = $option_value;
        }

        return $key_str;
    }

    function get_form_title($form_key, $alternate_qid = null, $is_raw = false)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $result = '';

        $this->set_last_key("[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "][TITLE]");

        if (!empty($this->m_data[APPID][$appid][QID][$qid][$form_key][TITLE]))
        {
            $expr = $this->m_data[APPID][$appid][QID][$qid][$form_key][TITLE];

            if (!$is_raw && is_callable($expr))
            {
                $result = call_user_func($expr);
            }
            else
            {
                $result = $expr;
            }
        }
        else if (!empty($qid))
        {
            $result = fmt_display_name($qid);
        }

        return $result;
    }

    function get_form_limit_rows($qid, $form_key, $default_value = 5)
    {
        $appid = $this->get_appid();

        $result = $default_value;

        $this->set_last_key("[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "][LIMIT_ROWS]");

        if (!empty($this->m_data[APPID][$appid][QID][$qid][$form_key][LIMIT_ROWS]))
        {
            $result = $this->m_data[APPID][$appid][QID][$qid][$form_key][LIMIT_ROWS];
        }

        return max(1, abs((int)$result));
    }

    function set_form_limit_rows($qid, $form_key, $option_value, &$activity)
    {
        $appid = $this->get_appid();

        if (empty($option_value) || $option_value == USE_DEFAULT)
        {
            $option_value = '';
        }

        $key_str = '';

        if ($this->get_form_limit_rows($qid, $form_key) != $option_value)
        {
            $this->m_data[APPID][$appid][QID][$qid][$form_key][LIMIT_ROWS] = $option_value;

            $key_str = "[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "][LIMIT_ROWS]";

            $activity[$key_str] = $option_value;
        }

        return $key_str;
    }

    function is_form_omit_col($form_key, $col_name, $alternate_qid = null)
    {
        $option_value = $this->get_col_option($this->get_qid($alternate_qid), $form_key, $col_name, COL_OMIT);

        return !empty($option_value);
    }

    function get_form_col_editor($form_key, $col_name, $default_value = EDITOR_INPUT, $alternate_qid = null)
    {
        $option_value = $this->get_col_option($this->get_qid($alternate_qid), $form_key, $col_name, COL_EDITOR);

        $value = !empty($option_value) ? $option_value : $default_value;

        return $value;
    }

    function get_form_col_editor_rows($form_key, $col_name, $default_value = 0, $alternate_qid = null)
    {
        $option_value = $this->get_col_option($this->get_qid($alternate_qid), $form_key, $col_name, COL_EDITOR_ROWS);

        $value = !empty($option_value) ? $option_value : $default_value;

        return abs((int)$value);
    }

    function get_form_col_size($form_key, $col_name, $default_value = 0, $alternate_qid = null)
    {
        $option_value = $this->get_col_option($this->get_qid($alternate_qid), $form_key, $col_name, COL_SIZE);

        $value = !empty($option_value) ? $option_value : $default_value;

        return abs((int)$value);
    }

    function get_form_col_align($form_key, $col_name, $default_value = null, $alternate_qid = null)
    {
        $option_value = $this->get_col_option($this->get_qid($alternate_qid), $form_key, $col_name, COL_ALIGN);

        $value = !empty($option_value) ? $option_value : $default_value;

        return in_array($value, array(ALIGN_L, ALIGN_J, ALIGN_C, ALIGN_R)) ? $value : ALIGN_L ;
    }

    function form_format_col($form_key, $col_name, $col_value, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $result = $col_value;

        if ($col_value != '' && !empty($this->m_data[APPID][$appid][QID][$qid][$form_key][$col_name][COL_FORMAT]))
        {
            $elements = explode(',', $this->m_data[APPID][$appid][QID][$qid][$form_key][$col_name][COL_FORMAT]);

            if (is_array($elements) && !empty($elements))
            {
                $func = trim(!empty($elements[0]) ? $elements[0] : null);
                $fmt = trim(!empty($elements[1]) ? $elements[1] : null);
                $quotes = isset($elements[2]) ? true : false ;

                if (is_callable($func) === true)
                {
                    if ($fmt)
                    {
                        $result = call_user_func($func, $fmt, $col_value);
                    }
                    else
                    {
                        $result = call_user_func($func, $col_value);
                    }
                }
            }
        }

        return $result;
    }

    function get_col_order($form_key, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $this->set_last_key("[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "][COL_ORDER]");

        return !empty($this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER]) ? $this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER] : null ;
    }

    function set_col_order($qid, $form_key, $col_expr, &$activity)
    {
        $appid = $this->get_appid();

        $key_str = '';

        if (!empty($qid) &&
            (!isset($this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER]) ||
             $this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER] != $col_expr))
        {
            $this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER] = $col_expr;

            $key_str = "[QID]['{$qid}'][" . $this->get_key_symbol($form_key) . "][COL_ORDER]";

            $activity[$key_str] = $col_expr;
        }

        return $key_str;
    }

    function get_form_col_order_map($form_key, $col_names = null, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $map = null;
        $col_included = null;

        if (!empty($this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER]))
        {
            $elements = explode(',', $this->m_data[APPID][$appid][QID][$qid][$form_key][COL_ORDER]);

            if (is_array($elements) && !empty($elements))
            {
                foreach ($elements as $element)
                {
                    $col_name = trim($element);
                    $map[] = $col_name;
                    $col_included[$col_name] = true;
                }
            }
        }

        if (is_array($col_names) && !empty($col_names))
        {
            foreach ($col_names as $col_name)
            {
                if (empty($col_included[$col_name]))
                {
                    $map[] = $col_name;
                }
            }
        }

        return $map;
    }

    function bind_tab_nav($href, $text)
    {
        $appid = $this->get_appid();

        if (!empty($appid) &&
            !empty($href) &&
            !empty($text))
        {
            $this->m_data[APPID][$appid][INCL][NAV][] = array(A_HREF=>$href, A_TEXT=>$text);
        }
    }

    function is_nav_omit_tab($tab_name, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = false;

        if (!empty($this->m_data[APPID][$appid][OMIT][NAV]))
        {
            $omit_tabs = explode(',', $this->m_data[APPID][$appid][OMIT][NAV]);

            if (is_array($omit_tabs) && !empty($omit_tabs))
            {
                foreach ($omit_tabs as $omit_tab_name)
                {
                    if (trim($omit_tab_name) == $tab_name)
                    {
                        $result = true;
                        break;
                    }
                }
            }
        }

        return $result;
    }

    function get_nav_incl_tabs($alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = array();

        if (!empty($this->m_data[APPID][$appid][INCL][NAV]))
        {
            $incl_tabs = $this->m_data[APPID][$appid][INCL][NAV];

            if (is_array($incl_tabs))
            {
                foreach ($incl_tabs as $tab_info)
                {
                    $tab_href = trim(is_array($tab_info) ? $tab_info[A_HREF] : $tab_info);
                    $tab_text = trim(is_array($tab_info) ? $tab_info[A_TEXT] : $tab_href);

                    if (!empty($tab_href) && !empty($tab_text))
                    {
                        $result[$tab_href] = array(A_HREF=>$tab_href, A_TEXT=>$tab_text);
                    }
                }
            }
            else if (is_string($incl_tabs))
            {
                $incl_tabs = explode(',', $incl_tabs);

                if (!empty($incl_tabs))
                {
                    foreach ($incl_tabs as $tab_name)
                    {
                        $tab_href = trim($tab_name);
                        $tab_text = fmt_display_name($tab_href, false);

                        if (!empty($tab_href) && !empty($tab_text))
                        {
                            $result[$tab_href] = array(A_HREF=>$tab_href, A_TEXT=>$tab_text);
                        }
                    }
                }
            }
        }

        return $result;
    }

    function get_nav_tab_order_map($tab_names = null, $alternate_appid = null, $tab_type = NAV)
    {
        $appid = $this->get_appid($alternate_appid);

        $map = null;
        $tab_included = null;

        if (!empty($this->m_data[APPID][$appid][TAB_ORDER][$tab_type]))
        {
            $elements = explode(',', $this->m_data[APPID][$appid][TAB_ORDER][$tab_type]);

            if (is_array($elements) && !empty($elements))
            {
                foreach ($elements as $element)
                {
                    $tab_name = trim($element);
                    $map[] = $tab_name;
                    $tab_included[$tab_name] = true;
                }
            }
        }

        if (is_array($tab_names) && !empty($tab_names))
        {
            foreach ($tab_names as $tab_name)
            {
                if (empty($tab_included[$tab_name]))
                {
                    $map[] = $tab_name;
                }
            }
        }

        return $map;
    }

    function get_rpt_tab_order_map($tab_names = null, $alternate_appid = null)
    {
        return $this->get_nav_tab_order_map($tab_names, $alternate_appid, RPT);
    }

    function is_rpt_omit_tab($tab_name, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = false;

        if (!empty($this->m_data[APPID][$appid][OMIT][RPT]))
        {
            $omit_tabs = explode(',', $this->m_data[APPID][$appid][OMIT][RPT]);

            if (is_array($omit_tabs) && !empty($omit_tabs))
            {
                foreach ($omit_tabs as $omit_tab_name)
                {
                    if (trim($omit_tab_name) == $tab_name)
                    {
                        $result = true;
                        break;
                    }
                }
            }
        }

        return $result;
    }

    function bind_tab_rpt($href)
    {
        $appid = $this->get_appid();

        if (!empty($appid) &&
            !empty($href))
        {
            if (empty($this->m_data[APPID][$appid][INCL][RPT]))
            {
                $this->m_data[APPID][$appid][INCL][RPT] = $href;
            }
            else
            {
                $this->m_data[APPID][$appid][INCL][RPT] .= ",{$href}";
            }
        }
    }

    function get_rpt_incl_tabs($alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = array();

        $incl_tabs = !empty($this->m_data[APPID][$appid][INCL][RPT]) ? explode(',', $this->m_data[APPID][$appid][INCL][RPT]) : null ;

        if (!empty($incl_tabs))
        {
            foreach ($incl_tabs as $incl_tab_name)
            {
                $incl_tab_name = trim($incl_tab_name);

                if (!empty($incl_tab_name))
                {
                    $result[$incl_tab_name] = $incl_tab_name;
                }
            }
        }

        return $result;
    }

    function get_rpt_page_size($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return !empty($this->m_data[APPID][$appid][QID][$qid][RPT_PAGE_SIZE]) ? $this->m_data[APPID][$appid][QID][$qid][RPT_PAGE_SIZE] : PAGE_SIZE_LETTER ;
    }

    function get_rpt_page_orientation($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return !empty($this->m_data[APPID][$appid][QID][$qid][RPT_PAGE_ORIENTATION]) ? $this->m_data[APPID][$appid][QID][$qid][RPT_PAGE_ORIENTATION] : PAGE_ORIENTATION_LANDSCAPE ;
    }

    function get_rpt_font_size($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return !empty($this->m_data[APPID][$appid][QID][$qid][RPT_FONT_SIZE]) ? $this->m_data[APPID][$appid][QID][$qid][RPT_FONT_SIZE] : '8' ;
    }

    function get_rpt_font_family($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return !empty($this->m_data[APPID][$appid][QID][$qid][RPT_FONT_FAMILY]) ? $this->m_data[APPID][$appid][QID][$qid][RPT_FONT_FAMILY] : FONT_FAMILY_ARIAL ;
    }

    function is_rpt_cell_border($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return (empty($this->m_data[APPID][$appid][QID][$qid][RPT_CELL_BORDER]) ||
                $this->m_data[APPID][$appid][QID][$qid][RPT_CELL_BORDER] != SWITCH_ON) ? false : true ;
    }

    function is_rpt_row_shade($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return ((empty($this->m_data[APPID][$appid][QID][$qid][RPT_ROW_SHADE]) ||
                 $this->m_data[APPID][$appid][QID][$qid][RPT_ROW_SHADE] != SWITCH_OFF) &&
                empty($this->m_data[APPID][$appid][QID][$qid][DETAIL_SUMMARY_COLS])) ? true : false ;
    }

    function set_rpt_row_size($qid, $row_size)
    {
        $activity = null;
        $this->set_option_value($qid, RPT_ROW_SIZE, max(0, (int)$row_size), $activity);
    }

    function get_rpt_row_size($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return !empty($this->m_data[APPID][$appid][QID][$qid][RPT_ROW_SIZE]) ? max(0, (int)$this->m_data[APPID][$appid][QID][$qid][RPT_ROW_SIZE]) : 0 ;
    }

    ////

    function set_export_type($export_type, $qid = null)
    {
        $appid = $this->get_appid();

        if (!empty($appid))
        {
            if (!empty($qid))
            {
                $this->m_data[APPID][$appid][QID][$qid][EXPORT_TYPE] = $export_type; // qid-specific
            }
            else
            {
                $this->m_data[APPID][$appid][EXPORT_TYPE] = $export_type; // app-level
            }
        }
    }

    function get_export_type($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $result = EXPORT_TYPE_TXT_TAB; // establish default

        if (!empty($this->m_data[APPID][$appid][QID][$qid][EXPORT_TYPE]))
        {
            $result = $this->m_data[APPID][$appid][QID][$qid][EXPORT_TYPE]; // qid-specific
        }
        else if (!empty($this->m_data[APPID][$appid][EXPORT_TYPE]))
        {
            $result = $this->m_data[APPID][$appid][EXPORT_TYPE]; // app-level
        }

        return $result;
    }

    function get_export_type_descr($alternate_qid = null)
    {
        $result = null;

        switch ($this->get_export_type($alternate_qid))
        {
        case EXPORT_TYPE_TXT_TAB:
        default:
            $result = EXPORT_TYPE_DESCR_TXT_TAB;
            break;
        case EXPORT_TYPE_TXT_CSV:
            $result = EXPORT_TYPE_DESCR_TXT_CSV;
            break;
        case EXPORT_TYPE_ODS:
            $result = EXPORT_TYPE_DESCR_ODS;
            break;
        }

        return $result;
    }

    ////

    function set_col_media_type($qid, $col, $media_type)
    {
        $appid = $this->get_appid();

        if (!empty($appid) &&
            !empty($qid))
        {
            $this->m_data[APPID][$appid][QID][$qid][MEDIA_TYPE][$col] = $media_type;
        }
    }

    function get_col_media_type($col, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        return isset($this->m_data[APPID][$appid][QID][$qid][MEDIA_TYPE][$col]) ? $this->m_data[APPID][$appid][QID][$qid][MEDIA_TYPE][$col] : null ;
    }

    function get_media_subtype_from_filename($filename, $alternate_qid = null)
    {
        assert('!"custom::get_media_subtype_from_filename() - not implemented"');

        return null;
    }

    function set_media_loc($media_loc, $media_type = TYPE_ANY, $qid = null)
    {
        $appid = $this->get_appid();

        if (!empty($appid))
        {
            if (!empty($qid))
            {
                $this->m_data[APPID][$appid][QID][$qid][MEDIA_LOC][$media_type] = $media_loc; // qid-specific
            }
            else
            {
                $this->m_data[APPID][$appid][MEDIA_LOC][$media_type] = $media_loc; // app-level
            }
        }
    }

    function get_media_loc($media_type = TYPE_ANY, $alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $result = null;

        if (!empty($this->m_data[APPID][$appid][QID][$qid][MEDIA_LOC][$media_type]))
        {
            $result = get_apps_relative_dir($this->m_data[APPID][$appid][QID][$qid][MEDIA_LOC][$media_type]); // qid-specific
        }
        else if (!empty($this->m_data[APPID][$appid][MEDIA_LOC][$media_type]))
        {
            $result = get_apps_relative_dir($this->m_data[APPID][$appid][MEDIA_LOC][$media_type]); // app-level
        }

        return $result;
    }

    function set_temp_loc($temp_loc, $qid = null)
    {
        $appid = $this->get_appid();

        if (!empty($appid))
        {
            if (!empty($qid))
            {
                $this->m_data[APPID][$appid][QID][$qid][TEMP_LOC] = $temp_loc; // qid-specific
            }
            else
            {
                $this->m_data[APPID][$appid][TEMP_LOC] = $temp_loc; // app-level
            }
        }
    }

    function get_temp_loc($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $result = null;

        if (!empty($this->m_data[APPID][$appid][QID][$qid][TEMP_LOC]))
        {
            $result = get_apps_relative_dir($this->m_data[APPID][$appid][QID][$qid][TEMP_LOC]); // qid-specific
        }
        else if (!empty($this->m_data[APPID][$appid][TEMP_LOC]))
        {
            $result = get_apps_relative_dir($this->m_data[APPID][$appid][TEMP_LOC]); // app-level
        }
        else
        {
            $result = get_temp_dir(); // default
        }

        return $result;
    }

    ////

    function is_auth_appid_username($username, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = is_auth_appid($appid);

        if ($result)
        {
            $elements = isset_string($this->m_data[APPID][$appid][AUTH_APPID]) ? explode(',', $this->m_data[APPID][$appid][AUTH_APPID]) : null ;

            if (!empty($elements))
            {
                $result = is_auth_username($username, $elements);
            }
        }

        return $result;
    }

    function is_auth_qid_username($qid, $username, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = true;

        $elements = isset_string($this->m_data[APPID][$appid][AUTH_QID][$qid]) ? explode(',', $this->m_data[APPID][$appid][AUTH_QID][$qid]) : null ;

        if (!empty($elements))
        {
            $result = is_auth_username($username, $elements);
        }

        return $result;
    }

    function is_auth_pid_username($pid, $username, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = true;

        $elements = isset_string($this->m_data[APPID][$appid][AUTH_PID][$pid]) ? explode(',', $this->m_data[APPID][$appid][AUTH_PID][$pid]) : null ;

        if (!empty($elements))
        {
            $result = is_auth_username($username, $elements);
        }

        return $result;
    }

    function is_auth_rid_username($rid, $username, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = true;

        $elements = isset_string($this->m_data[APPID][$appid][AUTH_RID][$rid]) ? explode(',', $this->m_data[APPID][$appid][AUTH_RID][$rid]) : null ;

        if (!empty($elements))
        {
            $result = is_auth_username($username, $elements);
        }

        return $result;
    }

    function is_auth_process_username($func, $username, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $result = true;

        $elements = isset_string($this->m_data[APPID][$appid][AUTH_PROCESS][$func]) ? explode(',', $this->m_data[APPID][$appid][AUTH_PROCESS][$func]) : null ;

        if (!empty($elements))
        {
            $result = is_auth_username($username, $elements);
        }

        return $result;
    }

    function get_qids_auth_actions($username, $alternate_appid = null)
    {
        $appid = $this->get_appid($alternate_appid);

        $qids_auth_actions = null;

        if (!empty($this->m_data[APPID][$appid][QID]))
        {
            foreach($this->m_data[APPID][$appid][QID] as $qid => $auth_action)
            {
                if (isset_string($auth_action[AUTH_ADD]))
                {
                    $elements = explode(',', $auth_action[AUTH_ADD]);

                    if (is_auth_username($username, $elements))
                    {
                        $qids_auth_actions[$qid][] = AUTH_ADD;
                    }

                    if (!isset($qids_auth_actions[$qid]))
                    {
                        $qids_auth_actions[$qid] = array();
                    }
                }

                if (isset_string($auth_action[AUTH_EDIT]))
                {
                    $elements = explode(',', $auth_action[AUTH_EDIT]);

                    if (is_auth_username($username, $elements))
                    {
                        $qids_auth_actions[$qid][] = AUTH_EDIT;
                    }

                    if (!isset($qids_auth_actions[$qid]))
                    {
                        $qids_auth_actions[$qid] = array();
                    }
                }

                if (isset_string($auth_action[AUTH_DELETE]))
                {
                    $elements = explode(',', $auth_action[AUTH_DELETE]);

                    if (is_auth_username($username, $elements))
                    {
                        $qids_auth_actions[$qid][] = AUTH_DELETE;
                    }

                    if (!isset($qids_auth_actions[$qid]))
                    {
                        $qids_auth_actions[$qid] = array();
                    }
                }
            }
        }

        return $qids_auth_actions;
    }

    function get_auth_recs($alternate_qid = null)
    {
        $appid = $this->get_appid();
        $qid = $this->get_qid($alternate_qid);

        $auth_recs_expr = '';

        if (isset_string($this->m_data[APPID][$appid][QID][$qid][AUTH_RECS]) &&
            ($func = trim($this->m_data[APPID][$appid][QID][$qid][AUTH_RECS])) &&
            is_callable($func) === true)
        {
            $auth_recs_expr = call_user_func($func); // <col_name> = 'val1' // <col_name> in ('val1', 'val2') // etc.
        }

        return $auth_recs_expr;
    }
}

////

?>
