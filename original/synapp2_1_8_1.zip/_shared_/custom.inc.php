<?php

/* custom.inc.php - SynApp2 include file for application specific customization
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2009 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: custom.inc.php,v 1.9 2010/10/06 15:03:43 richard Exp $
*/

////

function login_username()
{
    return get_username();
}

function date_today($fmt = 'Y-m-d')
{
    return date($fmt); // TODO: support correct time zone
}

function weekday_today()
{
    return date('D'); // Mon - Sun // TODO: support correct time zone
}

function day_today()
{
    return date('d'); // 01 - last // TODO: support correct time zone
}

function month_today()
{
    return date('m'); // 01 - 12 // TODO: support correct time zone
}

function year_today()
{
    return date('Y'); // TODO: support correct time zone
}

function col_format_date($fmt, $value)
{
    return date_format(date_create($value), $fmt);
}

////

?>
