<?php

/* query.php - SynApp2 SQL expression generator
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2010 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: query.php,v 1.15 2011/06/18 18:10:40 richard Exp $
*/

class query_base
{
    var $m_action = null;
    var $m_custom = null;
    var $m_schema = null;

    var $m_build = true;

    var $m_query_expr = '';
    var $m_col_exprs = array();
    var $m_join_exprs = '';
    var $m_select_options = array();
    var $m_extra_col_exprs = array();

    function query_base(&$action, &$custom, &$schema)
    {
        $this->m_action = &$action;
        $this->m_custom = &$custom;
        $this->m_schema = &$schema;
    }

    function build_once()
    {
        if ($this->m_build)
        {
            $this->m_build = false;
            $this->build();
        }
    }

    function get_table()
    {
        return $this->m_custom->get_table();
    }

    function get_query_expr()
    {
        $this->build_once();

        return $this->m_query_expr;
    }

    function get_pk_constraint()
    {
        $pk_constraint = array('n' => '', 'v' => 0);

        $arg = $this->m_action->get_pk();

        if (!empty($arg))
        {
            $pk_constraint['n'] = $this->m_custom->get_pk_name($this->get_table(), true);
            $pk_constraint['v'] = trim($arg);
        }

        return $pk_constraint;
    }

    function get_fk_constraint()
    {
        return $this->m_action->get_fk_constraint();
    }

    function get_cols_expr()
    {
        $cols = '';
        $sep = '';

        if (!empty($this->m_col_exprs))
        {
            foreach ($this->m_col_exprs as $col_expr)
            {
                $cols .= $sep . $col_expr['expr'];
                $sep = ', ';
            }
        }

        return $cols;
    }

    function get_select_options_exprs()
    {
        $this->build_once();

        return $this->m_select_options;
    }

    function get_found_rows_expr()
    {
        return '';
    }
}

////

class query_writer extends query_base
{
    function query_writer(&$action, &$custom, &$schema)
    {
        $this->query_base($action, $custom, $schema);
    }

    function fetch_query_cols()
    {
        $this->m_col_exprs = array();

        $col_vars = $this->m_action->get_col_vars();

        if (!empty($col_vars))
        {
            foreach ($col_vars as $col_var)
            {
                if (escape_sql_term($col_var['n']) != $col_var['n'])
                {
                    $this->m_col_exprs = array();
                    break; // TODO: error msg - possible sql insertion attack
                }

                $col_var_value = escape_sql_term($col_var['v']);
                $special = $this->m_schema->translate_special_col_value($this->get_table(), $col_var['n'], $col_var_value);
                $col_value_expr = ($special ? $col_var_value : "'$col_var_value'");
                $this->m_col_exprs[] = array('expr'=>$col_var['n'] . "={$col_value_expr}", 'basis'=>null);
            }

            $cols_with_no_vars = array_diff(array_values($this->m_schema->get_col_names($this->get_table())), array_keys($col_vars));

            if (!empty($cols_with_no_vars))
            {
                foreach ($cols_with_no_vars as $col_name)
                {
                    $col_var_value = null;

                    if ($this->m_schema->translate_special_col_value($this->get_table(), $col_name, $col_var_value))
                    {
                        $col_value_expr = $col_var_value;
                        $this->m_col_exprs[] = array('expr'=>"{$col_name}={$col_value_expr}", 'basis'=>null);
                    }
                }
            }
        }
    }

    function get_where_expr()
    {
        $expr = '';

        $pk_constraint = $this->get_pk_constraint();

        if (!empty($pk_constraint['n']) && escape_sql_term($pk_constraint['n']) == $pk_constraint['n'] && !empty($pk_constraint['v']))
        {
            $expr = " where {$pk_constraint['n']}='" . escape_sql_term($pk_constraint['v']) . "'";
        }

        return $expr;
    }
}

////

class query_insert extends query_writer
{
    var $m_col_names = null;

    function query_insert(&$action, &$custom, &$schema)
    {
        $this->query_writer($action, $custom, $schema);
    }

    function fetch_query_cols()
    {
        $this->m_col_names = '';
        $this->m_col_exprs = array();

        $cols_info = $this->m_schema->get_table_cols_info($this->get_table());
        $col_vars = $this->m_action->get_col_vars();
//        $fk_fwd = $this->m_action->get_fk_fwd();

        if (!empty($col_vars))
        {
            $cols_with_no_vars = null;
            $multi_col = null;
            $col_values = array();
            $col_sep = '';

            ////

/*
            if (!empty($fk_fwd))
            {
                foreach ($fk_fwd as $col_name => $col_value)
                {
                    $this->m_col_names .= $col_sep . $col_name;
                    $col_sep = ',';
                    $col_values[$col_name] = escape_sql_term($col_value);
                }

                $cols_with_no_vars = array_diff(array_values($this->m_schema->get_col_names($this->get_table())), array_keys($col_vars), array_keys($fk_fwd));
            }
            else
*/
            {
                $cols_with_no_vars = array_diff(array_values($this->m_schema->get_col_names($this->get_table())), array_keys($col_vars));
            }

            if (!empty($cols_with_no_vars))
            {
                foreach ($cols_with_no_vars as $col_name)
                {
                    $col_var_value = null;

                    if ($this->m_schema->translate_special_col_value($this->get_table(), $col_name, $col_var_value, true))
                    {
                        $this->m_col_names .= $col_sep . $col_name;
                        $col_sep = ',';
                        $col_values[$col_name] = null; // value gets filled in when csv values (packet) is established
                    }
                }
            }

            ////

            foreach ($col_vars as $col_name => $col_var)
            {
                if (escape_sql_term($col_var['n']) != $col_name)
                {
                    unset($col_values);
                    break; // TODO: error msg - possible sql insertion attack
                }

                $this->m_col_names .= $col_sep . $col_name;
                $col_sep = ',';

                if (is_array($col_var['v'])) // detect multi-value col
                {
                    assert('empty($multi_col)'); // TODO: cannot have more than one multi-value col
                    $multi_col = $col_name; // indicate $col_name has multiple values
                    $col_values[$col_name] = ''; // make an empty slot for $col_name
                }
                else
                {
                    $col_values[$col_name] = escape_sql_term($col_var['v']);
                }
            }

            $this->m_col_names = '(' . $this->m_col_names . ')'; // the csv names (packet) now established for all rows

            ////

            if (!empty($col_values))
            {
                $row_limit = $multi_col ? count($col_vars[$multi_col]['v']) : 1 ;

                for ($i = 0; $i < $row_limit; $i++)
                {
                    $values = '';
                    $col_sep = '';

                    foreach ($col_values as $col_name => $col_value)
                    {
                        $value = $col_name == $multi_col ? $col_vars[$multi_col]['v'][$i] : $col_value ;
                        $special = $this->m_schema->translate_special_col_value($this->get_table(), $col_name, $value, true);
                        $values .= $col_sep . ($special ? $value : "'$value'");
                        $col_sep = ',';
                    }

                    $this->m_col_exprs[] = array('expr'=>"($values)", 'basis'=>null); // a csv values (packet) established for row[i]
                }
            }
        }
    }

    function build()
    {
        $this->fetch_query_cols();

        assert('!empty($this->m_col_names)');
        assert('!empty($this->m_col_exprs)');

        if (!empty($this->m_col_names) && !empty($this->m_col_exprs))
        {
            $this->m_query_expr = 'insert into ' . $this->get_table() . ' ' . $this->m_col_names . ' values ' . $this->get_cols_expr();
        }
    }
}

////

class query_select extends query_base
{
    var $m_map_col_name_expanded_col_expr = array();

    function query_select(&$action, &$custom, &$schema)
    {
        $this->query_base($action, $custom, $schema);
    }

    function fetch_query_cols()
    {
        $this->m_col_exprs = array();
        $this->m_select_options = array();
        $this->m_extra_col_exprs = array();

        $cols_info = $this->m_schema->get_table_cols_info($this->get_table());

        if (!empty($cols_info))
        {
            $list_col_alias = 'text';

            foreach ($cols_info as $col_info)
            {
                $col_name = $col_info['Field'];
                $full_name = $this->get_table() . ".$col_name";
                $col_expr = $full_name;

                if (!$this->m_schema->is_pk($this->get_table(), $col_name) &&
                    !$this->m_schema->is_fk($this->get_table(), $col_name))
                {
                    $col_expr = $this->get_col_expr($col_name);

                    if ($col_expr != $full_name)
                    {
                        $col_expr .= " as $col_name";
                    }
                }

                $this->m_col_exprs[] = array('expr'=>$col_expr, 'basis'=>$col_name);

                if ($parent_name = $this->m_custom->get_parent_name($this->get_table(), $col_name))
                {
                    $col_name_expanded = $this->get_table() . '_' . $col_name; // TODO: encapuslate dependency '_'
                    $col_expr = $this->get_col_expr($col_name);
                    $this->m_col_exprs[] = array('expr'=>"$col_expr as $col_name_expanded", 'basis'=>$col_name);

                    $this->m_map_col_name_expanded_col_expr[$col_name_expanded] = &$this->m_col_exprs[count($this->m_col_exprs) - 1];

                    if ($this->m_action->is_col_expand($col_name))
                    {
                        $ikey = $this->m_action->get_col_expand($col_name);

                        $pk_name = $this->m_custom->get_pk_name($parent_name, true);
                        $list_col_expr = $this->get_list_col_expr($col_name);
                        $list_col_exprs[0] = array('expr'=>$list_col_expr, 'basis'=>$col_name);
                        $join_exprs = $this->get_join_exprs($parent_name, $list_col_exprs);
                        $list_where = $ikey ? " where $pk_name = '$ikey'" : '' ;
                        $list_order = $this->get_list_order_expr($col_name, $list_col_alias);
                        $select_options_expr = "select $pk_name as value, $list_col_expr as $list_col_alias from $parent_name$join_exprs$list_where$list_order";

                        $select_name = $ikey ? $col_name_expanded : $col_name ;

                        $this->m_select_options[$select_name] = $select_options_expr;
                    }

                    $extra_col_exprs = $this->get_extra_col_exprs($col_name);

                    if (!empty($extra_col_exprs) && is_array($extra_col_exprs))
                    {
                        foreach ($extra_col_exprs as $col_alias => $extra_expr)
                        {
                            $this->m_extra_col_exprs[] = array('expr'=>"$extra_expr as $col_alias", 'basis'=>$col_name);
                            $this->m_map_col_name_expanded_col_expr[$col_alias] = &$this->m_extra_col_exprs[count($this->m_extra_col_exprs) - 1];
                        }
                    }
                }
                else if ($this->m_action->is_col_expand($col_name) &&
                         ($values = $this->m_schema->get_set_values($this->get_table(), $col_name)))
                {
                    foreach ($values as $text)
                    {
                        $this->m_select_options[$col_name][] = array('value' => $text, 'text' => $text);
                    }
                }
                else
                {
                    $extra_col_exprs = $this->get_extra_col_exprs($col_name);

                    if (!empty($extra_col_exprs) && is_array($extra_col_exprs))
                    {
                        foreach ($extra_col_exprs as $col_alias => $extra_expr)
                        {
                            $this->m_extra_col_exprs[] = array('expr'=>"$extra_expr as $col_alias", 'basis'=>null);
                            $this->m_map_col_name_expanded_col_expr[$col_alias] = &$this->m_extra_col_exprs[count($this->m_extra_col_exprs) - 1];
                        }
                    }
                }
            }

            if (!empty($this->m_extra_col_exprs))
            {
                foreach ($this->m_extra_col_exprs as &$item)
                {
                    $this->m_col_exprs[] = &$item;
                }
            }
        }
    }

    function fetch_join_exprs()
    {
        $this->m_join_exprs = $this->get_join_exprs($this->get_table(), $this->m_col_exprs);
    }

    function build()
    {
        if ($query_expr = $this->m_custom->get_query())
        {
            $this->m_query_expr = $query_expr; // TODO: TBD: could become get_query_select() to get action customization query??
        }
        else
        {
            $this->fetch_query_cols();
            $this->fetch_join_exprs();
            $this->m_query_expr = 'select ' . $this->get_cols_expr() .
                                  ' from ' . $this->get_table() .
                                  $this->m_join_exprs .
                                  $this->get_where_expr() .
                                  $this->get_order_expr();
        }
    }

    function get_cols_expr()
    {
        $cols = parent::get_cols_expr();
        $sep = $cols ? ', ' : '' ;

        $subquery = $this->m_custom->get_subquery();

        if (!empty($subquery))
        {
            foreach ($subquery as $col_alias => $col_expr)
            {
                $cols .= $sep . "$col_expr as $col_alias";
                $sep = ', ';
            }
        }

        return $cols;
    }

    function get_col_expr($col_name)
    {
        $table_name = $this->get_table();

        $col_expr = $this->m_custom->get_macro("$table_name.$col_name");

        if (empty($col_expr))
        {
            $col_expr = $this->m_schema->get_value_col($table_name, $col_name);
        }

        return empty($col_expr) ? "$table_name.$col_name" : $col_expr ;
    }

    function get_list_col_expr($col_name)
    {
        $col_expr = '';

        $table_name = $this->get_table();

        $macro = $this->m_custom->get_list_macro("$table_name.$col_name");

        if (empty($macro))
        {
            $macro = $this->m_custom->get_macro("$table_name.$col_name");
        }

        if (empty($macro))
        {
            $macro = $this->m_schema->get_value_col($table_name, $col_name);
        }

        if (!empty($macro))
        {
            $col_expr = "$macro";
        }
        else
        {
            $col_expr = "$table_name.$col_name";
        }

        return $col_expr;
    }

    function get_extra_col_exprs($col_name)
    {
        $table_name = $this->get_table();

        return $this->m_custom->get_extra("$table_name.$col_name");
    }

    function get_list_order_expr($col_name, $col_alias)
    {
        $expr = '';

        $table_name = $this->get_table();

        $list_order = $this->m_custom->get_list_macro_order("$table_name.$col_name");

        if (!empty($list_order))
        {
            $expr = $list_order;
        }
        else
        {
            $expr = $col_alias;
        }

        return " order by $expr ";
    }

    function get_join_exprs($table_name, &$col_exprs)
    {
        // initialize the result
        //
        $result = '';

        // find col(s) depending on ancestors of $this->get_table()
        //
        $deps = $this->m_schema->get_col_dependencies($this->get_table(), array($table_name), $col_exprs);

        if (!empty($deps))
        {
            // find all paths to $this->get_table() that involve the ancestor(s)
            //
            $paths = array();

            foreach ($deps as $ancestor => $col_dep)
            {
                foreach ($col_dep as $cjc_index => $dep)
                {
                    $expr_index = $dep['expr_index'];
                    $basis = $dep['basis'];
                    $basis_node = array(TABLE_NAME=>$this->get_table(), COL_NAME=>$basis, JOIN_TABLE=>null, JOIN_COL=>null);

                    $path_found = false;

                    $visits = array();
                    $child_nodes = $this->m_schema->get_children($ancestor);

                    foreach ($child_nodes as $child_node)
                    {
                        $path = array();

                        $this->m_schema->get_node_path($path, $visits, $basis_node, $child_node);

                        if (!empty($path))
                        {
                            $path_found = true;
                            $paths[] = array(PATH=>$path, 'expr_index'=>$expr_index);
                            break;
                        }
                    }

                    if (!$path_found)
                    {
                        add_debug_msg("No path to '$ancestor' found for '" . $this->get_table() . ".$basis' - check " . KEYMAP); // TODO: add runtime error handler
                    }
                }
            }

            // build the join expressions according to dependency order
            //
            if (!empty($paths))
            {
                $join_exprs = array();
                $basis_levels = array();

                foreach ($paths as $paths_info)
                {
                    $path = $paths_info[PATH];
                    $expr_index = $paths_info['expr_index'];

                    foreach ($path as $path_node)
                    {
                        if ($path_node[JOIN_TABLE] == $table_name)
                        {
                            continue; // NOTE: skip node when $table_name is parent of $this->get_table()
                        }

                        $join_table = $path_node[JOIN_TABLE];
                        $join_alias = '';
                        $join_col = $path_node[JOIN_COL];
                        $child_table = $path_node[TABLE_NAME];
                        $child_col = $path_node[COL_NAME];

                        $basis = $col_exprs[$expr_index]['basis'];

                        if (!isset($basis_levels[$join_table]))
                        {
                            $basis_levels[$join_table] = array();
                        }

                        if (!isset($basis_levels[$join_table][$basis]))
                        {
                            $basis_levels[$join_table][$basis] = count($basis_levels[$join_table]);
                        }

                        $basis_level = $basis_levels[$join_table][$basis];

                        if ($basis_level)
                        {
                            $join_alias =  sprintf('L%02d_', $basis_level) . $join_table;

                            // could be more elegant and complete, but it is simple and improved from 0.1.7
                            //
                            $patterns[] = "/^{$join_table}\./";     $replaces[] = "{$join_alias}.";
                            $patterns[] = "/ {$join_table}\./";     $replaces[] = " {$join_alias}.";
                            $patterns[] = "/,{$join_table}\./";     $replaces[] = ",{$join_alias}.";
                            $patterns[] = "/-{$join_table}\./";     $replaces[] = "-{$join_alias}.";
                            $patterns[] = "/\+{$join_table}\./";    $replaces[] = "+{$join_alias}.";
                            $patterns[] = "/\*{$join_table}\./";    $replaces[] = "*{$join_alias}.";
                            $patterns[] = "/\/{$join_table}\./";    $replaces[] = "/{$join_alias}.";
                            $patterns[] = "/\^{$join_table}\./";    $replaces[] = "^{$join_alias}.";
                            $patterns[] = "/\%{$join_table}\./";    $replaces[] = "%{$join_alias}.";
                            $patterns[] = "/\!{$join_table}\./";    $replaces[] = "!{$join_alias}.";
                            $patterns[] = "/\|{$join_table}\./";    $replaces[] = "|{$join_alias}.";
                            $patterns[] = "/\&{$join_table}\./";    $replaces[] = "&{$join_alias}.";
                            $patterns[] = "/\({$join_table}\./";    $replaces[] = "({$join_alias}.";
                            $patterns[] = "/<{$join_table}\./";     $replaces[] = "<{$join_alias}.";
                            $patterns[] = "/>{$join_table}\./";     $replaces[] = ">{$join_alias}.";
                            $patterns[] = "/={$join_table}\./";     $replaces[] = "={$join_alias}.";
                            $patterns[] = "/!{$join_table}\./";     $replaces[] = "!{$join_alias}.";
                            $patterns[] = "/`{$join_table}\./";     $replaces[] = "`{$join_alias}.";

                            // indirectly updates m_map_col_name_expanded_col_expr (by reference)
                            //
                            $col_exprs[$expr_index]['expr'] = preg_replace($patterns, $replaces, $col_exprs[$expr_index]['expr']);
                        }

                        if (!empty($basis_levels[$child_table][$basis]))
                        {
                            $child_table =  sprintf('L%02d_', $basis_levels[$child_table][$basis]) . $child_table;
                        }

                        if ($join_alias)
                        {
                            $join_expr = "left join $join_table $join_alias on $join_alias.$join_col = $child_table.$child_col";
                        }
                        else
                        {
                            $join_expr = "left join $join_table on $join_table.$join_col = $child_table.$child_col";
                        }

                        $join_exprs["$join_table$join_alias$join_col$child_table$child_col"] = $join_expr;
                    }
                }

                if (!empty($join_exprs))
                {
                    $result = ' ' . implode(' ', $join_exprs); // update the result
                }
            }
        }

        return $result;
    }

    function get_where_expr()
    {
        $expr = '';

        $pk_constraint = $this->get_pk_constraint();

        if (!empty($pk_constraint['n']) && escape_sql_term($pk_constraint['n']) == $pk_constraint['n'])
        {
            $expr = " where {$pk_constraint['n']}='" . escape_sql_term($pk_constraint['v']) . "'";
        }
        else
        {
            $fk_constraint = $this->get_fk_constraint();

            if (!empty($fk_constraint['n']) && escape_sql_term($pk_constraint['n']) == $pk_constraint['n'])
            {
                $expr = " where {$fk_constraint['n']}='" . escape_sql_term($fk_constraint['v']) . "'";
            }
        }

        ////

        $filter_expr = $this->get_filter_expr();

        if (!empty($filter_expr))
        {
            if (!empty($expr))
            {
                $expr .= (' and ' . $filter_expr);
            }
            else
            {
                $expr .= (' where ' . $filter_expr);
            }
        }

        ////

        $auth_recs_expr = $this->m_custom->get_auth_recs();

        if (!empty($auth_recs_expr))
        {
            if (!empty($expr))
            {
                $expr .= (' and ' . $auth_recs_expr);
            }
            else
            {
                $expr .= (' where ' . $auth_recs_expr);
            }
        }

        ////

        return $expr;
    }

    function get_filter_expr()
    {
        $expr = '';

        if ($this->m_action->is_filter())
        {
            $col_vars = $this->m_action->get_col_vars();

            if (!empty($col_vars))
            {
                $col_names = $this->m_schema->get_col_names($this->get_table());
                $sep = '';

                foreach ($col_vars as $col_var)
                {
                    if (escape_sql_term($col_var['n']) != $col_var['n'])
                    {
                        $expr = '';
                        break; // TODO: error msg - possible sql insertion attack
                    }

                    if (!empty($col_var['v']))
                    {
                        $col_var_name = $col_var['n'];

                        if (isset($this->m_map_col_name_expanded_col_expr[$col_var['n']]))
                        {
                            $col_var_name = preg_replace("/ as {$col_var['n']}$/", '', $this->m_map_col_name_expanded_col_expr[$col_var['n']]['expr']);
                        }
                        else if (in_array($col_var['n'], $col_names))
                        {
                            $col_var_name = $this->get_table() . ".{$col_var['n']}"; // TODO: TBD: is this step necessary??
                        }

                        if (!is_array($col_var['v'])) // detect ordinary col_var by signature: a non-array value
                        {
                            $col_var_value = escape_sql_term($col_var['v']);

                            // eval order of conditional tests is important for stand-alone tokens: { <, > }

                            if (($expr_term = preg_replace('/^<=/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} <= '{$expr_term}'"; // less than or equal to

                            }
                            else if (($expr_term = preg_replace('/^</', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} < '{$expr_term}'"; // less than

                            }
                            else if (($expr_term = preg_replace('/^!=/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} != '{$expr_term}'"; // not equal to

                            }
                            else if (($expr_term = preg_replace('/^=/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} = '{$expr_term}'"; // equal to

                            }
                            else if (($expr_term = preg_replace('/^>=/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} >= '{$expr_term}'"; // greater than or equal to

                            }
                            else if (($expr_term = preg_replace('/^>/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} > '{$expr_term}'"; // greater than

                            }
                            else if (preg_match('/^\//', $col_var_value) &&
                                     preg_match('/\/$/', $col_var_value) &&
                                    ($expr_term1 = preg_replace('/^\//', '', $col_var_value)) != $col_var_value &&
                                    ($expr_term = preg_replace('/\/$/', '', $expr_term1)) != $expr_term1)
                            {
                                // NOTE: bad regex expressions will cause SQL syntax errors and display the SynApp2 message window
                                $expr .= $sep . $this->m_schema->m_dbx->format_regex_term($col_var_name, $expr_term); // regular expression

                            }
                            else if (($expr_term = preg_replace('/%$/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} like '{$expr_term}%'"; // begins with

                            }
                            else if (($expr_term = preg_replace('/^%/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} like '%{$expr_term}'"; // ends with

                            }
                            else if (($expr_term = preg_replace('/^!/', '', $col_var_value)) != $col_var_value)
                            {
                                $expr .= $sep . "{$col_var_name} not like '%{$expr_term}%'"; // not like

                            }
                            else // default:
                            {
                                $expr .= $sep . "{$col_var_name} like '%{$col_var_value}%'"; // like
                            }

                            $sep = ' and '; // all filter expr terms are combined with 'and'
                        }
                        else if (count($col_var['v']) == 2) // detect date range col_var by signature: a 2 element array
                        {
                            $v0 = escape_sql_term($col_var['v'][0]);
                            $v1 = escape_sql_term($col_var['v'][1]);

                            list($col_var_tab, $col_var_col) = explode('.', $col_var_name);

                            // quietly strip invalid or malformed filter col_var value(s) to prevent error(s), especially for Oracle date type columns
                            //
                            if (!empty($col_var_tab) &&
                                !empty($col_var_col) &&
                                ($col_var_col_info = $this->m_schema->find_col_info($col_var_tab, $col_var_col)) &&
                                ($col_var_col_type_detail = $this->m_schema->get_col_type_detail($col_var_col_info)))
                            {
                                if (!empty($v0) && validate_type($this->m_schema->m_dbx, $col_var_col_info, $col_var_col_type_detail, $v0))
                                {
                                    $v0 = '';
                                }

                                if (!empty($v1) && validate_type($this->m_schema->m_dbx, $col_var_col_info, $col_var_col_type_detail, $v1))
                                {
                                    $v1 = '';
                                }
                            }

                            $expr_beg = !empty($v0) ? ("{$col_var_name} >= '{$v0}'") : '' ;
                            $expr_end = !empty($v1) ? ("{$col_var_name} <= '{$v1}'") : '' ;

                            if (!empty($expr_beg) || !empty($expr_end))
                            {
                                $expr_sep = empty($expr_beg) || empty($expr_end) ? '' : ' and ' ;
                                $expr .= $sep . "{$expr_beg}{$expr_sep}{$expr_end}";
                                $sep = ' and '; // all filter expr terms are combined with 'and'
                            }
                        }
                    }
                }
            }
        }

        return $expr;
    }

    function get_order_expr()
    {
        return ' order by ' . $this->m_custom->get_order(null, escape_sql_term($this->m_action->get_order()));
    }

    function get_found_rows_expr()
    {
        $expr = '';

        assert('!empty($this->m_query_expr)');

        $setup = null; //$this->m_custom->get_sql_calc_found_rows(); // KLUGE: detect MySQL ver > 4

        if (!empty($setup))
        {
            $expr = 'select found_rows()'; // MySQL ver > 4 specific
        }
        else
        {
            $expr = 'select count(*)' .
                    ' from ' . $this->get_table() .
                    $this->m_join_exprs .
                    $this->get_where_expr(); // NOTE: this started as HACK: for mysql 3.23.58, but it's general and works for any db engine
        }

        return $expr;
    }
}

////

class query_offset extends query_select
{
    var $m_pk = '';

    function query_offset(&$action, &$custom, &$schema, $pk)
    {
        $this->query_base($action, $custom, $schema);
        $this->m_pk = $pk;
    }

    function build()
    {
        $this->fetch_query_cols();
        $this->fetch_join_exprs();
        $this->m_query_expr = 'select ' . $this->get_cols_expr() .
                         ' from ' . $this->get_table() .
                         $this->m_join_exprs .
                         $this->get_where_expr() .
                         $this->get_order_expr();
    }

    function get_where_expr()
    {
        $expr = '';

        $fk_constraint = $this->get_fk_constraint();

        if (!empty($fk_constraint['n']) && escape_sql_term($fk_constraint['n']) == $fk_constraint['n'])
        {
            $expr = " where {$fk_constraint['n']}='" . escape_sql_term($fk_constraint['v']) . "'";
        }

        return $expr;
    }
}

////

class query_update extends query_writer
{
    function query_update(&$action, &$custom, &$schema)
    {
        $this->query_writer($action, $custom, $schema);
    }

    function build()
    {
        $this->fetch_query_cols();
        $where_expr = $this->get_where_expr();

        assert('!empty($this->m_col_exprs)');
        assert('!empty($where_expr)');

        if (!empty($this->m_col_exprs) && !empty($where_expr))
        {
            $this->m_query_expr = "update " . $this->get_table() . " set " . $this->get_cols_expr() . " $where_expr";
        }
    }
}

////

class query_delete extends query_writer
{
    function query_delete(&$action, &$custom, &$schema)
    {
        $this->query_writer($action, $custom, $schema);
    }

    function build()
    {
        $where_expr = $this->get_where_expr();

        assert('!empty($where_expr)');

        if (!empty($where_expr))
        {
            $this->m_query_expr = "delete from " . $this->get_table() . " $where_expr";
        }
    }

    function get_where_expr()
    {
        $expr = '';

        $pk_values = $this->m_action->get_pk_values($this->m_custom->get_qid());

        if (!empty($pk_values))
        {
            $pk_name = $this->m_custom->get_pk_name($this->get_table(), true);
            $pk_list = implode(',', $pk_values);

            if (!empty($pk_name) && !empty($pk_list) && escape_sql_term($pk_list) == $pk_list)
            {
                $expr = " where {$pk_name} in ({$pk_list})";
            }
        }

        return $expr;
    }
}

////

class query_adhoc extends query_base
{
    function query_adhoc(&$action, &$custom, &$schema)
    {
        $this->query_base($action, $custom, $schema);
    }

    function build()
    {
        $this->m_query_expr = $this->m_custom->get_query();
    }
}

////

class query_fetch extends query_select
{
    function query_fetch(&$action, &$custom, &$schema)
    {
        $this->query_base($action, $custom, $schema);
    }

    function fetch_query_cols()
    {
        $fetch_cols = $this->m_custom->get_fetch_cols();

        if (!empty($fetch_cols))
        {
            $this->m_col_exprs = array();

            $fk_constraint = $this->get_fk_constraint();

            list($table_name, $basis) = !empty($fk_constraint['n']) ? explode('.', $fk_constraint['n']) : '';

            $this->m_col_exprs = array();

            foreach ($fetch_cols as $col_alias => $col_expr)
            {
                $this->m_col_exprs[] = array('expr'=>"$col_expr as $col_alias", 'basis'=>$basis);
            }
        }
        else
        {
            parent::fetch_query_cols();
        }
    }

    function get_order_expr()
    {
        return '';
    }
}

////

function &new_query(&$action, &$custom, &$schema)
{
    $obj = null;

    if ($action->is_adhoc())
    {
        $obj = new query_adhoc($action, $custom, $schema);
    }
    else if ($action->is_fetch())
    {
        $obj = new query_fetch($action, $custom, $schema);
    }
    else if ($action->is_insert())
    {
        $obj = new query_insert($action, $custom, $schema);
    }
    else if ($action->is_select())
    {
        $obj = new query_select($action, $custom, $schema);
    }
    else if ($action->is_update())
    {
        $obj = new query_update($action, $custom, $schema);
    }
    else if ($action->is_delete())
    {
        $obj = new query_delete($action, $custom, $schema);
    }

    return $obj;
}

////

?>
