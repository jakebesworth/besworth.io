<?php

/* lock.php - SynApp2 record lock manager
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2009 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: lock.php,v 1.3 2009/01/05 02:39:54 richard Exp $
*/

class lock
{
    var $m_dbx = null;

    function lock_base(&$dbx)
    {
        $this->m_dbx = &$dbx;
    }

    function purge_locks()
    {
        // delete all obsolete records in lock table
    }

    function get_lock($table_name, $pk)
    {
        $lock_key = null;

        $now = $this->m_dbx->get_query_value("select md5(concat('$table_name','$pk',unix_timestamp()))"); // util.php
add_debug_msg($now);
        return $lock_key;
    }

    function get_group_lock($parent_name, $pk)
    {
        // lock parent record and all child records
    }

    function release_lock($lock_key)
    {
        $result = null;

        return $result;
    }
}

////

?>
