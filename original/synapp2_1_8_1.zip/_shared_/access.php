<?php

/* access.php - SynApp2 authentication and database access control
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: access.php,v 1.16 2011/02/04 21:47:03 richard Exp $
*/

class access_base
{
    //// begin private data members

    // private:

    var $m_action = null;
    var $m_dbx = null;
    var $m_custom = null;
    var $m_config = null;
    var $m_link = false;
    var $m_connect_as = null;
    var $m_auth_interface = null;
    var $m_setup = false;

    //// begin public interface

    // public:

    function logout()
    {
        $this->set_token();
    }

    function is_authorized()
    {
        return $this->m_action->is_login() ||
        ($this->m_custom->is_auth_appid_username($this->get_username()) &&
         $this->m_custom->is_auth_qid_username($this->m_action->get_qid(), $this->get_username()) &&
         $this->m_custom->is_auth_pid_username($this->m_action->get_pid(), $this->get_username()) &&
         $this->m_custom->is_auth_rid_username($this->m_action->get_rid(), $this->get_username()));
    }

    function is_authenticated()
    {
        $token = $this->get_token();

        return !empty($token);
    }

    function select_db($db_name)
    {
        $select_result = false;

        if ($this->db_connect())
        {
            $select_result = $this->m_dbx->select_db($db_name);
        }

        $this->select_db_diagnostic($db_name, $select_result);

        return $select_result;
    }

    //// begin protected interface

    // protected:

    function access_base(&$action, &$dbx, &$custom)
    {
        $this->m_action = &$action;
        $this->m_dbx = &$dbx;
        $this->m_custom = &$custom;

        $this->config();
    }

    function get_login_method()
    {
        $login_method = LOGIN_METHOD_SYNAPP2;

        if (isset($this->m_config[MAP_AUTH_INTERFACE_DEF][$this->get_database_logical()]))
        {
            $login_method = LOGIN_METHOD_APP;
        }
        else if  (@dbx_base::get_engine() == ENGINE_OCI)
        {
            $login_method = LOGIN_METHOD_DIRECT;
        }
        else if ($this->m_action->get_login_method())
        {
            $login_method = $this->m_action->get_login_method();
        }

        return $login_method;
    }

    //// begin private interface

    // private:

    function config()
    {
        $this->m_config[DIAGNOSTIC_MSG_ENABLE_FLAG] = 'true';

        $this->m_config[ONE_FOR_ALL_HOSTNAME] = 'localhost';
        $this->m_config[ONE_FOR_ALL_PASSWORD] = 'password';
        $this->m_config[ONE_FOR_ALL_HASH] = '1a2b3c';

        ////

        $access_inc = get_config_dir() . 'access.inc.php';

        if (file_exists($access_inc))
        {
            include($access_inc);
        }
    }

    function is_setup()
    {
        return $this->m_setup == true;
    }

    function is_diagnostic_msg_enabled()
    {
        return $this->m_config[DIAGNOSTIC_MSG_ENABLE_FLAG] && ($this->m_action->is_show_response() || $this->is_setup());
    }

    function add_diagnostic_msg($msg)
    {
        if ($this->is_diagnostic_msg_enabled())
        {
            if ($this->is_setup())
            {
                $this->m_ADH[] = $msg;
            }
            else
            {
                add_debug_msg($msg);
            }
        }
    }

    function select_db_diagnostic($db_name, $select_result)
    {
        if ($this->is_diagnostic_msg_enabled())
        {
            $this->add_diagnostic_msg("select_db('$db_name') - attempt " . ($select_result === false ? 'FAILED' : 'SUCCEEDED'));
        }
    }

    function is_site_prefix($alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        return isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_SITE_PREFIX]) ||
               isset($this->m_config[MAP_SITE_PREFIX][$http_host]); // TODO: DEPRECATED:
    }

    function get_site_prefix($alternate_http_host = null)
    {
        $prefix = '';

        $http_host = get_http_host($alternate_http_host);

        if ($this->is_site_prefix($http_host))
        {
            $prefix = isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_SITE_PREFIX]) ?
                      $this->m_config[MAP_HTTP_HOST][$http_host][MAP_SITE_PREFIX] :
                      $this->m_config[MAP_SITE_PREFIX][$http_host] ; // TODO: DEPRECATED:
        }

        return $prefix;
    }

    function get_site_connection_string($alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        return isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_SITE_CONNECTION_STRING]) ?
                     $this->m_config[MAP_HTTP_HOST][$http_host][MAP_SITE_CONNECTION_STRING] :
                     get_dbx()->get_connection_string() ;
    }

    function get_database_host($database_logical, $alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        return isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_HOST]) ?
                     $this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_HOST] :
                     $this->m_config[ONE_FOR_ALL_HOSTNAME] ;
    }

    function get_database_host_username($database_logical, $alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        return isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_HOST_USERNAME]) ?
                     $this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_HOST_USERNAME] :
                     ($this->is_site_prefix($http_host) ? $this->get_username_physical($database_logical) : SYNAPP2) ;
    }

    function get_database_host_password($database_logical, $alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        return isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_HOST_PASSWORD]) ?
                     $this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_HOST_PASSWORD] :
                     $this->m_config[ONE_FOR_ALL_PASSWORD] ;
    }

    function get_database_connection_string($database_logical, $alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        return isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_CONNECTION_STRING]) ?
                     $this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_CONNECTION_STRING] :
                     $this->get_site_connection_string($http_host) ;
    }

    function get_database_logical($alternate_appid = null)
    {
        return $this->m_custom->get_database($alternate_appid);
    }

    function get_database_physical($alternate_appid = null, $alternate_http_host = null)
    {
        $http_host = get_http_host($alternate_http_host);

        $database_logical = $this->get_database_logical($alternate_appid);
        $database_physical = $database_logical;

        if (!empty($database_logical))
        {
            $database_physical = isset($this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_PHYSICAL]) ?
                                       $this->m_config[MAP_HTTP_HOST][$http_host][MAP_DATABASE_LOGICAL][$database_logical][MAP_DATABASE_PHYSICAL] :
                                       (isset($this->m_config[MAP_DATABASE_PHYSICAL][$http_host][$database_logical]) ? // TODO: DEPRECATED:
                                              $this->m_config[MAP_DATABASE_PHYSICAL][$http_host][$database_logical] :
                                              ($this->get_site_prefix($http_host) . $database_logical)) ;
        }

        return $database_physical;
    }

    function get_username_physical($logical)
    {
        return $this->get_site_prefix() . $logical;
    }

    function connect_diagnostic(&$link, $hostname, $username, $auth_connect = false)
    {
        if ($this->is_diagnostic_msg_enabled())
        {
            $this->add_diagnostic_msg(($auth_connect ? 'auth_connect' : 'db_connect') . "(-h '$hostname', -u '$username') - attempt " . ($link === false ? 'FAILED' : 'SUCCEEDED'));
        }
    }

    function fetch_auth_interface_def()
    {
        assert('!isset($this->m_auth_interface_def)');
    }

    function auth_connect()
    {
        $http_host = get_http_host();

        $h = $this->get_database_host($this->m_connect_as);
        $u = $this->get_database_host_username($this->m_connect_as);
        $p = $this->get_database_host_password($this->m_connect_as);

        $this->m_dbx->set_connection_string($this->get_database_connection_string($this->m_connect_as));

        $link = $this->m_dbx->connect($u, $p, $h);

        $this->connect_diagnostic($link, $h, $u, true);

        return $link;
    }

    function validation_diagnostic($username, $user_validated)
    {
        if ($this->is_diagnostic_msg_enabled())
        {
            $msg = "user validation " . ($user_validated ? 'SUCCEEDED' : 'FAILED') .
                   " against " . $this->get_database_physical($this->m_auth_interface_def->database()) . '.' . $this->m_auth_interface_def->table() .
                   " for " . $this->m_auth_interface_def->field_username() . " = '$username'" .
                   " and " . $this->m_auth_interface_def->field_password() . " = '*******'";

            $this->add_diagnostic_msg($msg);
        }
    }

    function authenticate()
    {
        $u = $this->m_action->get_login_username();
        $p = $this->m_action->get_login_password();

        if (!empty($u) || !empty($p)) // detect if session login is occuring
        {
            $this->set_token(); // cancel any previous session login

            $link = $this->auth_connect();

            if ($link)
            {
                if ($this->m_auth_interface_def)
                {
                    $u = $this->m_dbx->escape_sql_term($u);
                    $p = $this->m_dbx->escape_sql_term($p);

                    $this->m_dbx->select_db($this->get_database_physical($this->m_auth_interface_def->database()));

                    $q = "select count(*) from " . $this->m_auth_interface_def->table() .
                         " where " . $this->m_auth_interface_def->field_username() . " = '$u'" .
                         " and " . $this->m_auth_interface_def->field_password() . " = " . $this->m_auth_interface_def->function_encrypt($p);

                    $v = $this->m_dbx->get_query_value($q);

                    $user_validated = 1 == $this->m_dbx->get_query_value($q);

                    $this->validation_diagnostic($u, $user_validated);

                    if ($user_validated)
                    {
                        $default_hash = $this->m_config[ONE_FOR_ALL_HASH];
                        $hash = $this->resolve($u, $default_hash);
                        $this->set_token($hash); // session login successful
                        $this->set_username($u);
                        $this->set_login_appid($this->m_action->get_appid());
                    }
                }

                $this->m_dbx->close();
            }
        }

        return $this->is_authenticated();
    }

    function set_token($token = null)
    {
        if (empty($token))
        {
            unset_session_var('token');
            $this->set_username();
            $this->set_login_appid();
        }
        else
        {
            set_session_var('token', $token);
        }
    }

    function get_token()
    {
        return get_session_var('token');
    }

    function set_username($username = null)
    {
        if (empty($username))
        {
            unset_session_var('username');
        }
        else
        {
            set_session_var('username', $username);
        }
    }

    function get_username()
    {
        return get_session_var('username');
    }

    function set_login_appid($login_appid = null)
    {
        if (empty($login_appid))
        {
            unset_session_var('login_appid');
        }
        else
        {
            set_session_var('login_appid', $login_appid);
        }
    }

    function get_login_appid()
    {
        return get_session_var('login_appid');
    }

    function resolve($map_key, $default_hash = null)
    {
        if (empty($this->m_config[MAP_HASH_CREDENTIALS][$this->m_config[ONE_FOR_ALL_HASH]]))
        {
            $this->m_config[MAP_HASH_CREDENTIALS][$this->m_config[ONE_FOR_ALL_HASH]] = array(null,
                                                                                             $this->get_database_host($this->get_database_logical()),
                                                                                             $this->get_database_host_username($this->get_database_logical()),
                                                                                             $this->get_database_host_password($this->get_database_logical()));
        }

        ////

        $result = null;

        if (!empty($map_key))
        {
            if (!$default_hash)
            {
                // map hash to connection credential
                //
                if (isset($this->m_config[MAP_HASH_CREDENTIALS][$map_key]))
                {
                    $result = $this->m_config[MAP_HASH_CREDENTIALS][$map_key];
                }
            }
            else
            {
                // map username to hash (of appropriate connection credential)
                //
                foreach ($this->m_config[MAP_HASH_CREDENTIALS] as $hash => $credentials)
                {
                    if ($credentials[0] === $map_key)
                    {
                        $result = $hash;
                        break;
                    }
                }

                if (!$result && isset($this->m_config[MAP_HASH_CREDENTIALS][$default_hash]))
                {
                    $result = $default_hash;
                }
            }
        }

        return $result;
    }

    function db_connect($force = false)
    {
        if ($force)
        {
            $this->m_link = false;
        }

        if ($this->m_link === false)
        {
            $credentials = $this->resolve($this->get_token());

            if (!empty($credentials))
            {
                $this->m_dbx->set_connection_string($this->get_database_connection_string($this->get_database_logical()));
                $this->m_link = $this->m_dbx->connect($credentials[2], $credentials[3], $credentials[1]); // -u, -p, -h
                $this->connect_diagnostic($this->m_link, $credentials[1], $credentials[2]);
            }
        }

        return $this->m_link !== false;
    }
};

class access_app extends access_base
{
    function fetch_auth_interface_def()
    {
        $this->m_auth_interface_def = isset($this->m_config[MAP_AUTH_INTERFACE_DEF][$this->get_database_logical()]) ?
                                      $this->m_config[MAP_AUTH_INTERFACE_DEF][$this->get_database_logical()] :
                                      new auth_interface_def($this->get_database_logical()) ;
    }

    function auth_connect()
    {
        $this->fetch_auth_interface_def();

        $this->m_connect_as = $this->is_site_prefix() ? $this->get_database_logical() : SYNAPP2 ;

        ////

        return parent::auth_connect();
    }
};

class access_synapp2 extends access_base
{
    function fetch_auth_interface_def()
    {
        $this->m_auth_interface_def = new auth_interface_def(SYNAPP2);
    }

    function auth_connect()
    {
        $this->fetch_auth_interface_def();

        $this->m_connect_as = SYNAPP2;

        ////

        return parent::auth_connect();
    }
};

class access_enterprise extends access_base
{
    function authenticate()
    {
        $u = $this->m_action->get_login_username();
        $p = $this->m_action->get_login_password();

        if (!empty($u) || !empty($p))
        {
            $this->set_token();

            $authenticated = false; // enterprise_authentication($u, $p);

            if ($authenticated)
            {
                $default_hash = $this->m_config[ONE_FOR_ALL_HASH];
                $hash = $this->resolve($u, $default_hash);
                $this->set_token($hash);
                $this->set_username($u);
                $this->set_login_appid(SYNAPP2);
            }
        }

        return $this->is_authenticated();
    }
};

class access_direct extends access_base
{
    function authenticate()
    {
        $u = $this->m_action->get_login_username();
        $p = $this->m_action->get_login_password();

        if (!empty($u) || !empty($p))
        {
            $this->set_token();

            $authenticated = true; // bypass authentication layer

            if ($authenticated)
            {
                $hash = array(null, $this->get_database_host($u), $u, $this->obfuscator($p)); // NOTE: $u is always the same as the database name
                $this->set_token($hash);
                $this->set_username($u);
                $this->set_login_appid(SYNAPP2);
            }
        }

        return $this->is_authenticated();
    }

    function db_connect($force = false)
    {
        if ($force)
        {
            $this->m_link = false;
        }

        if ($this->m_link === false)
        {
            $credentials = $this->get_token();

            if (!empty($credentials))
            {
                $this->m_dbx->set_connection_string($this->get_database_connection_string($this->get_database_logical()));
                $this->m_link = $this->m_dbx->connect($credentials[2], $this->obfuscator($credentials[3], true), $credentials[1]);

                $this->connect_diagnostic($this->m_link,  $credentials[1], $credentials[2]);

                if (!$this->m_link)
                {
                    $this->set_token();
                }
            }
        }

        return $this->m_link !== false;
    }

    function obfuscator($subject, $decode = false)
    {
        return $subject; // TODO: SECURITY: implement encode/decode
    }
};

////

class auth_interface_def
{
    // customize via instances of this class, not by changing the member initialization
    //
    var $m_database = '';
    var $m_table = UPW_STD_TABLE;
    var $m_field_username = UPW_STD_COL_USERNAME;
    var $m_field_password = UPW_STD_COL_PASSWORD;
    var $m_function_encrypt = UPW_STD_FUNC_ENCRYPT; // 'oldpassword'; '';

    function auth_interface_def($database,
                                $table = null,
                                $field_username = null,
                                $field_password = null,
                                $function_encrypt = null)
    {
        $this->database($database);
        $this->table($table);
        $this->field_username($field_username);
        $this->field_password($field_password);
        $this->function_encrypt('', $function_encrypt);
    }

    function database($database = null)
    {
        if (!empty($database))
        {
            $this->m_database = $database;
        }

        return $this->m_database;
    }

    function table($table = null)
    {
        if (!empty($table))
        {
            $this->m_table = $table;
        }

        return $this->m_table;
    }

    function field_username($field_username = null)
    {
        if (!empty($field_username))
        {
            $this->m_field_username = $field_username;
        }

        return $this->m_field_username;
    }

    function field_password($field_password = null)
    {
        if (!empty($field_password))
        {
            $this->m_field_password = $field_password;
        }

        return $this->m_field_password;
    }

    function function_encrypt($value, $function_encrypt = null)
    {
        if (!empty($function_encrypt))
        {
            $this->m_function_encrypt = $function_encrypt;
        }

        return $this->m_function_encrypt . "('$value')";
    }
};

////

define('LOGIN_METHOD_APP', 'app');
define('LOGIN_METHOD_SYNAPP2', SYNAPP2);
define('LOGIN_METHOD_DIRECT', 'direct');
define('LOGIN_METHOD_ENTERPRISE', 'enterprise');

define('DIAGNOSTIC_MSG_ENABLE_FLAG', '_diagnostic_msg_enable_flag_');

define('MAP_HASH_CREDENTIALS', '_map_hash_credentials_');
define('MAP_AUTH_INTERFACE_DEF', '_map_auth_interface_def_');
define('MAP_HTTP_HOST', '_map_http_host_');
define('MAP_DATABASE_HOST', '_map_database_host_');
define('MAP_DATABASE_HOST_USERNAME', '_map_database_host_username_');
define('MAP_DATABASE_HOST_PASSWORD', '_map_database_host_password_');
define('MAP_DATABASE_CONNECTION_STRING', '_map_database_connection_string_');
define('MAP_DATABASE_LOGICAL', '_map_database_logical_');
define('MAP_DATABASE_PHYSICAL', '_map_database_physical_');

define('MAP_SITE_PREFIX', '_map_site_prefix_');
define('MAP_SITE_CONNECTION_STRING', '_map_site_connection_string_');

define('ONE_FOR_ALL', '_one_for_all_');

define('ONE_FOR_ALL_HOSTNAME', '_one_for_all_hostname_');
define('ONE_FOR_ALL_PASSWORD', '_one_for_all_password_');
define('ONE_FOR_ALL_HASH', '_one_for_all_hash_');

////

function &new_access(&$action, &$dbx, &$custom)
{
    $obj = null;

    $base = new access_base($action, $dbx, $custom);

    switch ($base->get_login_method())
    {
    case LOGIN_METHOD_APP:
        $obj = new access_app($action, $dbx, $custom);
        break;
    case LOGIN_METHOD_SYNAPP2:
    default:
        $obj = new access_synapp2($action, $dbx, $custom);
        break;
    case LOGIN_METHOD_DIRECT:
        $obj = new access_direct($action, $dbx, $custom);
        break;
    case LOGIN_METHOD_ENTERPRISE:
        $obj = new access_enterprise($action, $dbx, $custom);
        break;
    }

    setup_begin($obj);

    $obj->authenticate();

    setup_end($obj);

    ////

    if ($action->get_appid() == SYNAPP2)
    {
        // TODO: TBD: parameterize qid/table and col_names according to access config??
        $activity = array();
        $custom->set_order(UPW_STD_QID, UPW_STD_COL_USERNAME, $activity);
        $custom->set_username_password_mgr();
    }

    ////

    return $obj;
}

////

function is_auth_appid($appid)
{
    global $g_access;

    ////

    $login_appid = $g_access->get_login_appid();

    return $login_appid == SYNAPP2 || $login_appid == $appid;
}

function is_auth_username($username, &$elements)
{
    $result = false;

    if (!empty($username) && is_string($username) && !empty($elements) && is_array($elements))
    {
        foreach ($elements as $element)
        {
            $name = trim($element);

            if ($name == $username || (is_callable($name) && call_user_func($name, $username) === true))
            {
                $result = true;
                break;
            }
        }
    }

    return $result;
}

////

define('SETUP_PID', 'synapp2_setup');
define('SETUP_QID_TEST', 'setup_test');

function setup_begin(&$ao)
{
    if ($ao->m_config[DIAGNOSTIC_MSG_ENABLE_FLAG] &&
        $ao->m_action->get_pid() == SETUP_PID &&
        $ao->m_action->get_qid() == SETUP_QID_TEST)
    {
        $ao->m_setup = true;

        $ao->m_ADH[] = '<pre>';
        $ao->m_ADH[] = date('Y-m-d H:i:s');
        $ao->m_ADH[] = '';
        $ao->m_ADH[] = 'SynApp2 version ' . get_version(true);
        $ao->m_ADH[] = '';
        $ao->m_ADH[] = 'PHP version ' . phpversion();
        $ao->m_ADH[] = '';
    }
}

function setup_end(&$ao)
{
    if ($ao->is_setup())
    {
        if ($ao->db_connect(true))
        {
            $ao->select_db($ao->get_database_physical());
        }

        if ($dbx_errors = get_dbx()->get_errors())
        {
            $ao->m_ADH[] = '';
            $ao->m_ADH[] = '$dbx_errors';
            $ao->m_ADH[] = print_r($dbx_errors, true);
        }
        else
        {
            $ao->m_ADH[] = '';
        }

        $ao->m_config['ACCESS_MODEL'] = $ao->m_custom->get_key_symbol($ao->get_login_method());
        $ao->m_config['DATABASE_ENGINE'] = $ao->m_custom->get_key_symbol(get_dbx()->get_engine());
        $ao->m_config['DATABASE_CONNECTION_STRING'] = get_dbx()->get_connection_string();
        $ao->m_config['DATABASE_LOGICAL'] = $ao->get_database_logical();
        $ao->m_config['DATABASE_PHYSICAL'] = $ao->get_database_physical();

        $ao->m_config['DOCUMENT_ROOT'] = $_SERVER['DOCUMENT_ROOT'];
        $ao->m_config['CONFIG_DIR'] = realpath(get_config_dir());
        $ao->m_config['SHARED_DIR'] = realpath('.'); // TODO: HACK:

        clearstatcache();

        $apps_dir = realpath(get_apps_dir());

        $permissions = '';
        $permissions .= is_dir($apps_dir) ? 'd' : '-' ;
        $permissions .= is_readable($apps_dir) ? 'r' : '-' ;
        $permissions .= is_writable($apps_dir) ? 'w' : '-' ;
        $permissions .= is_executable($apps_dir) ? 'x' : '-' ;

        $ao->m_config['INSTALL_DIR'] = "{$apps_dir} (" . substr(sprintf('%o', fileperms($apps_dir)), -4) . ") {$permissions}";

        $app_dir = realpath(get_app_dir($ao->m_action->get_appid()));

        $permissions = '';
        $permissions .= is_dir($app_dir) ? 'd' : '-' ;
        $permissions .= is_readable($app_dir) ? 'r' : '-' ;
        $permissions .= is_writable($app_dir) ? 'w' : '-' ;
        $permissions .= is_executable($app_dir) ? 'x' : '-' ;

        $ao->m_config['APP_DIR'] = "{$app_dir} (" . substr(sprintf('%o', fileperms($app_dir)), -4) . ") {$permissions}";

        $ao->m_config['HTTP_HOST'] = get_http_host();
        $ao->m_config['HTTP_REFERER'] = $_SERVER['HTTP_REFERER'];
        $ao->m_config['REQUEST_URI'] = $_SERVER['REQUEST_URI'];

        $ao->m_ADH[] = '$ao->m_config';
        $ao->m_ADH[] = print_r($ao->m_config, true);

        $ao->m_ADH[] = '$_POST';
        $ao->m_ADH[] = print_r($_POST, true);

        $ao->m_ADH[] = '</pre>';

        $ao->logout();
    }
}

////

?>
