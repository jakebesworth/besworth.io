<?php

/* util.php - SynApp2 utility functions
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: util.php,v 1.76 2011/06/19 21:04:40 richard Exp $
*/

function get_version($display = false, $force = false)
{
    global $g_test_mode;

    $version = '1.8.1';
    $release = ''; // PHP version_compare() eval order: 'string not in list' < dev < alpha = a < beta = b < RC = rc < # < pl = p

    return $g_test_mode && !$force ? '0.0.0' : ($display && !empty($release) ? $version . ' (' . str_replace('_', ' ', $release) . ')' : $version . $release) ;
}

////

function session_begin()
{
    if (!session_id())
    {
        @session_start();
    }
}

session_begin();

function set_session_var($var_name, $var_value = null)
{
    if (!empty($var_name))
    {
        $_SESSION[$var_name] = $var_value;
    }
}

function get_session_var($var_name)
{
    return isset($_SESSION[$var_name]) ? $_SESSION[$var_name] : null ;
}

function unset_session_var($var_name)
{
    if (isset($_SESSION[$var_name]))
    {
        unset($_SESSION[$var_name]);
    }
}

////

$g_test_mode = false;

function set_test_mode($enable = true)
{
    global $g_test_mode;

    $g_test_mode = $enable ? true : false ;
}

////

$g_debug_msg = '';
$g_debug_msg_add_post_vars = true;

function add_debug_msg($mixed = null, $tag = null)
{
    global $g_debug_msg;
    global $g_debug_msg_add_post_vars;

    if ($g_debug_msg_add_post_vars)
    {
        $g_debug_msg_add_post_vars = false;
        fmt_debug($g_debug_msg, $_POST, '$_POST');
    }

    fmt_debug($g_debug_msg, $mixed, $tag);
}

function fmt_debug(&$markup, &$mixed, $tag)
{
    ob_start();

    if (!empty($tag))
    {
        print_r("\n");
        print_r($tag);
        print_r("\n");
    }

    if (!empty($mixed))
    {
        print_r($mixed);
    }

    $buf = encode_entities(ob_get_contents());

    ob_end_clean();

    if (!empty($buf))
    {
        $markup .= "<debug_msg>$buf</debug_msg>\n";
    }
}

function fmt_line(&$markup, $line)
{
    $markup .= $line . "\n";
}

////

function fmt_display_name($subject, $clip_id = true)
{
    $result = $subject;

    if (is_string($result))
    {
        $result = trim($result);

        if ($result == strtoupper($result))
        {
            $result = strtolower($result);
        }

        if ($clip_id)
        {
            $result = preg_replace('/(^id_|_id$)/i', '', $result);
        }

        $result = ucwords(str_replace('_', ' ', $result));
    }

    return $result;
}

////

function assert_handler($filename, $line, $expr)
{
    add_debug_msg("Expr: $expr\nFile: $filename\nLine: $line\n", '* Assertion Failed *');
}

assert_options(ASSERT_CALLBACK, 'assert_handler');
assert_options(ASSERT_ACTIVE, 1);
assert_options(ASSERT_WARNING, 0);
assert_options(ASSERT_QUIET_EVAL, 1);

////

require_once('dbx.php');

function &get_dbx()
{
    global $g_dbx;

    return $g_dbx;
}

function &get_action()
{
    global $g_action;

    return $g_action;
}

function &get_custom()
{
    global $g_custom;

    return $g_custom;
}

function &get_markup()
{
    global $g_markup;

    return $g_markup;
}

function &get_schema()
{
    global $g_schema;

    return $g_schema;
}

function escape_sql_term($term)
{
    $dbx = get_dbx();

    return !empty($dbx) ? $dbx->escape_sql_term($term) : $term ;
}

////

function get_username()
{
    global $g_access;

    assert($g_access);

    return !empty($g_access) ? $g_access->get_username() : null ;
}

function get_database_physical($alternate_appid = null, $host = null)
{
    global $g_access;

    assert($g_access);

    return !empty($g_access) ? $g_access->get_database_physical($alternate_appid, $host) : '' ;
}

function get_http_host($alternate_http_host = null)
{
    return strtolower(isset($alternate_http_host) ? $alternate_http_host : $_SERVER['HTTP_HOST']) ;
}

////

function get_array_element(&$array_var, $key_value)
{
    return isset($array_var[$key_value]) ? $array_var[$key_value] : null ;
}

function explode_csv($csv)
{
    return preg_split('/[\s]*[,][\s]*/', $csv);
}

////

function isset_string(&$s)
{
    return isset($s) && is_string($s);
}

////

$g_php_shutdown_action = null;

function set_php_shutdown_action($php_shutdown_action=null)
{
    global $g_php_shutdown_action;

    $g_php_shutdown_action = is_string($php_shutdown_action) && !empty($php_shutdown_action) ? $php_shutdown_action : null ;
}

function on_php_shutdown()
{
    global $g_php_shutdown_action;

    if (!empty($g_php_shutdown_action))
    {
        eval($g_php_shutdown_action);
    }
}

register_shutdown_function('on_php_shutdown');

////

$g_check_expr_msg = null;

function on_check_expr_fault($errno, $errstr)
{
    global $g_check_expr_msg;

    $g_check_expr_msg = $errstr;

    return true;
}

function on_check_expr_fatal()
{
    $feedback = 'No details are available';

    if (is_callable('error_get_last'))
    {
        $last_error = error_get_last(); // >= PHP5.2

        if (!empty($last_error['message']))
        {
            $feedback = $last_error['message'];
        }
    }

    $feedback = "<status name=\"message\">The expression triggers a fatal error: {$feedback}</status>";

    ////

    $response = '';

    fmt_line($response, '<' . '?xml version="1.0" encoding="' . get_charset_map()->get_charset_out() . '" standalone="yes" ?' . '>');
    fmt_line($response, "<response>");
    fmt_line($response, "<version>" . get_version() . "</version>");
    fmt_line($response, "<authentication>succeeded</authentication>");
    fmt_line($response, "<authorization>succeeded</authorization>");
    fmt_line($response, "<adhoc>");
    fmt_line($response, '<feedback>');
    fmt_line($response, $feedback);
    fmt_line($response, '</feedback>');
    fmt_line($response, "</adhoc>");
    fmt_line($response, "</response>");

    ////

    header("Content-Type: text/xml");
    echo $response;
}

function check_expr($code_fragment, $is_raw = false)
{
    global $g_check_expr_msg;

    $g_check_expr_msg = null;

    ini_set('display_errors', '1'); // prevent PHP from registering HTTP 500 internal server error during eval()
    ini_set('html_errors', false);  // suppress markup

    $delim = $is_raw ? '' : '"' ;

    if (!@eval("return true || {$delim}" . $code_fragment . "{$delim};"))
    {
        $g_check_expr_msg = 'Unparsable';
    }
    else
    {
        set_error_handler('on_check_expr_fault');
        set_php_shutdown_action("on_check_expr_fatal();");

        @eval('$lvalue=' . $delim . $code_fragment . "{$delim};"); // fatal errors, such as undefined functions, cannot be trapped

        set_php_shutdown_action();
        restore_error_handler();
    }

    ini_restore('html_errors');
    ini_restore('display_errors');

    return $g_check_expr_msg; // null == ok
}

////

function encode_entities($subject = '')
{
    return is_array($subject) ?
           array_map('encode_entities', $subject) :
           iconv(get_charset_map()->get_charset_php(), get_charset_map()->get_charset_out() . '//IGNORE//TRANSLIT', htmlspecialchars($subject, ENT_NOQUOTES)) ;
}

function decode_entities($subject = '')
{
    return iconv(get_charset_map()->get_charset_in(), get_charset_map()->get_charset_php() . '//IGNORE//TRANSLIT', $subject);
}

$g_entity_reference_map = null;

function get_entity_references()
{
    global $g_entity_reference_map;

    $result = '';

    if (!empty($g_entity_reference_map))
    {
        fmt_line($result, '<!DOCTYPE response [');

        foreach ($g_entity_reference_map as $entity_name => $entity_value)
        {
            fmt_line($result, "<!ENTITY {$entity_name} \"{$entity_value}\">");
        }

        fmt_line($result, ']>');
    }

    return $result;
}

////

function downloadFile($filename)
{
    if (!empty($filename) && file_exists($filename))
    {
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment; filename=" . basename($filename) . ";");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: " . filesize($filename));

        readfile("$filename");
    }
}

function writeFileContents($output, $lines_out)
{
    // return file_put_contents($output, $lines_out); // php 5

    $result = false;

    $h = fopen($output, 'wb+');

    if ($h)
    {
        $wresult = true;

        if (!empty($lines_out))
        {
            foreach ($lines_out as $line)
            {
                if (fwrite($h, $line) === false)
                {
                    $wresult = false;
                    break; // error
                }
            }
        }

        $result = $wresult && fclose($h);
    }

    return $result;
}

////

function get_work_dir()
{
    return './';
}

function get_apps_dir()
{
    return get_work_dir() . '../';
}

function get_apps_relative_dir($relative_dir)
{
    return get_apps_dir() . "{$relative_dir}/";
}

function get_app_dir($appid)
{
    return $appid ? (get_apps_dir() . "{$appid}/") : get_work_dir() ;
}

function get_config_dir()
{
    return get_apps_dir() . '_config_/';
}

function get_shared_dir()
{
    return get_apps_dir() . '_shared_/';
}

function get_temp_dir()
{
    return function_exists('sys_get_temp_dir') && is_dir(sys_get_temp_dir()) ? sys_get_temp_dir() : get_apps_dir() ;
}

function get_charset_dir()
{
    return get_config_dir() . 'charset/';
}

function get_font_dir($flag_core_fonts = true)
{
    return $flag_core_fonts ? (get_shared_dir() . '3rdparty/font/') : get_charset_dir() ;
}

////

function mkdir_app_dir($appid)
{
    $result = null;

    if (!empty($appid))
    {
        $apps_dir = get_apps_dir();

        if (is_dir($apps_dir))
        {
            $app_dir = get_app_dir($appid);

            if (!is_dir($app_dir))
            {
                mkdir($app_dir);
                chmod($app_dir, 0777);
            }

            if (is_dir($app_dir))
            {
                $result = $app_dir;
            }
        }
    }

    return $result;
}

////

/*
** charset conversion mappping - see: '_config_/charset/template.charset.inc.php'
*/

class charset_map
{
    var $m_eng = null;
    var $m_rpt = null;
    var $m_php = null;
    var $m_in = null;
    var $m_out = null;

    function charset_map($charset_eng, $charset_rpt, $charset_php, $charset_in, $charset_out)
    {
        $this->m_eng = isset($charset_eng) ? $charset_eng : null ; // default value managed in dbx
        $this->m_rpt = isset($charset_rpt) ? $charset_rpt : 'iso-8859-1' ;
        $this->m_php = isset($charset_php) ? $charset_php : 'ISO-8859-1' ;
        $this->m_in = isset($charset_in) ? $charset_in : 'UTF-8' ;
        $this->m_out = isset($charset_out) ? $charset_out : 'UTF-8' ;
    }

    function get_charset_eng()
    {
        return $this->m_eng;
    }

    function get_charset_rpt()
    {
        return $this->m_rpt;
    }

    function get_charset_php()
    {
        return $this->m_php;
    }

    function get_charset_in()
    {
        return $this->m_in;
    }

    function get_charset_out()
    {
        return $this->m_out;
    }
};

$g_charset_map = null;

function map_charset($charset_eng, $charset_rpt, $charset_php, $charset_in = null, $charset_out = null)
{
    global $g_charset_map;

    if (isset($GLOBALS['g_charset_map']))
    {
        unset($GLOBALS['g_charset_map']); // unset global variable inside a function per http://php.net/manual/en/function.unset.php
    }

    $g_charset_map = new charset_map($charset_eng, $charset_rpt, $charset_php, $charset_in, $charset_out);
}

function &get_charset_map()
{
    global $g_charset_map;

    if (!isset($g_charset_map))
    {
        map_charset(null, null, null);
    }

    return $g_charset_map;
}

////

?>
