<?php

/* report.php - SynApp2 PDF report generator
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: report.php,v 1.16 2011/06/18 18:06:43 richard Exp $
*/

require('./3rdparty/fpdf.php');
require('./3rdparty/mc_table.php');

class report_pdf extends PDF_MC_Table // extends FPDF
{
    var $m_action = null;
    var $m_custom = null;
    var $m_schema = null;
    var $m_query = null;

    var $m_omit = array();
    var $m_col_order_map = null;
    var $m_hdgs = array();
    var $m_hdgs_align = array();
    var $m_align = array();
    var $m_width = array();
    var $m_detail_summary = null;
    var $m_cell_border = false;
    var $m_row_shade = false;
    var $m_row_shaded = false;
    var $m_row_size = 0;
    var $m_image_loc = null;
    var $m_image = null;
    var $m_font_dir = null;

    ////

    function report_pdf(&$action, &$custom, &$schema, &$query)
    {
        $this->m_action = &$action;
        $this->m_custom = &$custom;
        $this->m_schema = &$schema;
        $this->m_query = &$query;

        $this->FPDF($this->m_custom->get_rpt_page_orientation(), 'pt', $this->m_custom->get_rpt_page_size());
        $this->SetFont($this->get_rpt_font_family(), '', $this->m_custom->get_rpt_font_size());

        $this->SetDisplayMode('default', 'default');
        $this->SetCreator('SynApp2 - version ' . get_version(true));
        $this->SetTitle($this->m_custom->get_form_title(RFORM));

        $this->m_cell_border = $this->m_custom->is_rpt_cell_border();
        $this->m_row_shade = $this->m_custom->is_rpt_row_shade();
        $this->m_row_size = $this->m_custom->get_rpt_row_size();
        $this->m_image_loc = $this->m_custom->get_media_loc(TYPE_IMAGE);
    }

    function _getfontpath()
    {
        return isset($this->m_font_dir) ? $this->m_font_dir : parent::_getfontpath() ;
    }

    function get_rpt_font_family()
    {
        $fontname = $this->m_custom->get_rpt_font_family(); // read the *selected* reporting option

        $fonts_map = get_charset_fonts_map(); // get all available fonts for the current charset

        if (!isset($fonts_map[$fontname]) && // test the *selected* font availability
            !empty($fonts_map)) // test if *any* fonts are available
        {
            $map_rec = reset($fonts_map); // get the first available font
            $fontname = $map_rec['fontname']; // re-select [ TBD: message?? ]
        }

        if (isset($fonts_map[$fontname])) // test the *selected* font availability
        {
            if ($fonts_map[$fontname]['font_dir'] == get_font_dir(false)) // detect embedded font
            {
                $this->m_font_dir = $fonts_map[$fontname]['font_dir']; // prime _getfontpath()
                $this->AddFont($fontname,'', "{$fontname}.php"); // prepare to embed the font
            }
        }
        else
        {
            $fontname = FONT_FAMILY_ARIAL; // select core font as the last-ditch fallback
        }

        return $fontname;
    }

    function do_report(&$recs)
    {
        $this->Body($recs);
        $this->Output();
    }

    function is_omit_col($col_name)
    {
        return !empty($this->m_omit[$col_name]);
    }

    function is_image_col($col_index)
    {
        return isset($this->m_image[$col_index]);
    }

    function is_cell_bordered()
    {
        return $this->m_cell_border;
    }

    function is_row_shaded()
    {
        return $this->m_row_shade && $this->m_row_shaded;
    }

    function toggle_is_row_shaded()
    {
        $this->m_row_shaded = !$this->m_row_shaded;
    }

    function reset_is_row_shaded()
    {
        $this->m_row_shaded = false;
    }

    function get_row_height()
    {
        static $row_height = null;

        if (!isset($row_height))
        {
            $row_height =  $this->m_row_size ? $this->em($this->m_row_size) : 0 ;
        }

        return $row_height;
    }

    function get_image_loc()
    {
        return $this->m_image_loc;
    }

    function em($mult = 1)
    {
        if (!is_numeric($mult) || $mult <= 0)
        {
            $mult = 1;
        }

        return $this->GetStringWidth('M') * ((float)$mult);
    }

    function get_col_name_iter(&$rec)
    {
        return $this->m_col_order_map ? array_values($this->m_col_order_map) : array_keys($rec) ;
    }

    function auto_widths(&$data, $expand_to_fit = true)
    {
        $this->m_width = array();

        if (!empty($data))
        {
            $available = round(($this->w - $this->lMargin - $this->rMargin) / $this->em()); // line width
            $minsize = 0;
            $maxsize = 0;
            $colsize = array(); // starting size estimates
            $required = 0; // total of size estimates
            $deficit = 0;

            foreach ($data as $row)
            {
                $col_count = count($row) - count($this->m_omit);

                if (!$col_count)
                {
                    break; // TODO: TBD?? message??
                }

                $minsize = max(1, min(5, (int)($available / $col_count)));
                $maxsize = min(40, $minsize * 8);

                foreach ($row as $n => $v)
                {
                    if (!$this->is_omit_col($n))
                    {
                        $size = max($minsize, min($maxsize, strlen($v)));

                        if (!isset($colsize[$n]))
                        {
                            $colsize[$n] = $size;
                        }
                        else
                        {
                            $colsize[$n] = max($size, $colsize[$n]);
                        }
                    }
                }
            }

            $required = array_sum($colsize);
            $flexible = $required;

            foreach ($colsize as $n => $size)
            {
                $s = $this->m_custom->get_form_col_size(RFORM, $n);

                if ($s)
                {
                    $size = $colsize[$n];
                    $colsize[$n] = $s;
                    $flexible -= $size;
                    $delta = $s - $size;
                    $required += $delta;
                }
            }

            $deficit = $required - $available;

            $col_name_iter = $this->get_col_name_iter($data[0]);

            foreach ($col_name_iter as $n)
            {
                if (!$this->is_omit_col($n))
                {
                    $s = $this->m_custom->get_form_col_size(RFORM, $n);

                    if ($s)
                    {
                        $this->m_width[$n] = $this->em($s);
                    }
                    else
                    {
                        $size = $colsize[$n];
                        $delta = $flexible ? (($size / $flexible) * $deficit) : 0 ;
                        $this->m_width[$n] = $this->em($size - ($expand_to_fit ? $delta : max(0, $delta)));
                    }
                }
            }
        }
    }

    function prepare_cols(&$data)
    {
        $this->m_omit = array();
        $this->m_col_order_map = null;
        $this->m_hdgs = array();
        $this->m_hdgs_align = array();
        $this->m_align = array();
        $this->m_width = array();
        $this->m_image = null;

        if (!empty($data))
        {
            $rec = $data[0];

            $this->m_col_order_map = $this->m_custom->get_form_col_order_map(RFORM, array_keys($rec));

            $map = $this->m_schema->get_col_display_name_map($this->m_query->get_table());

            $col_name_iter = $this->get_col_name_iter($rec);

            $col_index = 0;

            foreach ($col_name_iter as $col_name)
            {
                $col_value = $rec[$col_name];
                $table_name = $this->m_query->get_table();

                if ($this->m_schema->is_pk($table_name, $col_name) ||
                    $this->m_schema->is_fk($table_name, $col_name) ||
                    $this->m_custom->is_form_omit_col(RFORM, $col_name, $this->m_action->get_qid()))
                {
                    $this->m_omit[$col_name] = true;
                }
                else
                {
                    $display_name = fmt_display_name($col_name);

                    if (isset($map[$col_name]))
                    {
                        $display_name = $map[$col_name];
                    }
                    else if (strpos($col_name, "{$table_name}_") === 0) // TODO: encapsulate
                    {
                        $fk_name = str_replace("{$table_name}_", '', $col_name); // TODO: encapsulate

                        if (isset($map[$fk_name]))
                        {
                            $display_name = $map[$fk_name];
                        }
                    }

                    $this->m_hdgs[$col_name] = $display_name;
                    $this->m_hdgs_align[$col_name] = ALIGN_C;
                    $this->m_align[$col_name] = $this->m_custom->get_form_col_align(RFORM, $col_name, (is_numeric($col_value) ? ALIGN_R : ALIGN_L));

                    if ($this->m_custom->get_col_media_type($col_name) == TYPE_IMAGE)
                    {
                        $this->m_image[$col_index] = true;
                    }

                    $col_index++;
                }
            }

            $this->auto_widths($data);

            $this->m_detail_summary = new detail_summary($this->m_custom, $data);
        }
    }

    function get_col_values($rec)
    {
        static $col_name_iter = null;

        if (!$col_name_iter)
        {
            $col_name_iter = $this->get_col_name_iter($rec);
        }

        $col_values = array();

        foreach ($col_name_iter as $n)
        {
            if (!$this->is_omit_col($n))
            {
                $col_values[] = isset($rec[$n]) ? $this->m_custom->form_format_col(RFORM, $n, $rec[$n]) : '' ;
            }
        }

        return $col_values;
    }

    function Header()
    {
        $this->reset_is_row_shaded(); // first row always not shaded

        $this->SetY($this->bMargin / 2); // down from the top
        $font_size = $this->FontSizePt;
        $this->SetFontSize($font_size * 1.25);
        $this->Cell(0, 0, $this->title, 0, 0, ALIGN_C);
        $this->Ln(2 * $this->em());
        $this->SetFontSize($font_size);

        if (!empty($this->m_hdgs))
        {
            $this->SetAligns(array_values($this->m_hdgs_align));
            $this->Row(array_values($this->m_hdgs), true, true);
            $this->Ln(0.25 * $this->em());
            $this->SetAligns(array_values($this->m_align));
        }
    }

    function Body(&$data)
    {
        if (!empty($data))
        {
            $this->prepare_cols($data);

            $this->SetAligns(array_values($this->m_align));
            $this->SetWidths(array_values($this->m_width));

            $this->AddPage();

            foreach ($data as $rec)
            {
                if ($summary_row = $this->m_detail_summary->get_summary_row($rec))
                {
                    $this->Ln(0.25 * $this->em());
                    $this->Row($this->get_col_values($summary_row), false, !$this->m_row_shade || $this->is_row_shaded());
                    $this->Ln(0.25 * $this->em());
                    $this->toggle_is_row_shaded();
                    $this->m_detail_summary->suppress_col_shift_left();
                }

                $this->Row($this->get_col_values($rec), $this->is_cell_bordered(), $this->is_row_shaded(), $this->m_detail_summary->get_suppress_col(), true);
                $this->toggle_is_row_shaded();
                $this->m_detail_summary->suppress_col_shift_right();

                if ($summary_row = $this->m_detail_summary->get_final_row($rec))
                {
                    $this->Ln(0.25 * $this->em());
                    $this->Row($this->get_col_values($summary_row), false, !$this->m_row_shade || $this->is_row_shaded());
                    $this->Ln(0.25 * $this->em());
                    $this->toggle_is_row_shaded();
                }

                if ($summary_row = $this->m_detail_summary->get_grand_row($rec))
                {
                    $this->Ln(0.25 * $this->em());
                    $this->Row($this->get_col_values($summary_row), false, !$this->m_row_shade || $this->is_row_shaded());
                    $this->Ln(0.25 * $this->em());
                    $this->toggle_is_row_shaded();
                }
            }
        }
    }

    function Footer()
    {
        if (empty($this->AliasNbPages))
        {
            $this->AliasNbPages();
        }

        $this->SetY($this->bMargin / -2); // up from the bottom
        $this->Cell(0, 0, 'Page ' . $this->PageNo() . ' of ' . $this->AliasNbPages, 0, 0, 'C');
    }

    // the $n and $d params appear for strict compatability with FPDF::Output(), but are not used
    //
    function Output($n = '', $d = '')
    {
        $name = 'report.pdf'; // TODO: TBD: does this matter very much?? configurable??
        $buffering_threshold = 5 * 1024 * 1024; // TODO: TBD: configurable??

        ////

        if ($this->state < 3)
        {
            $this->Close();
        }

        ////

        $buffer_size = strlen($this->buffer);

        if ($buffer_size < $buffering_threshold)
        {
            header("Content-Type: application/pdf");
            header("Content-disposition: inline; filename=\"{$name}\"");
            header("Content-Transfer-Encoding: binary");
            header('Content-Length: ' . $buffer_size);

            ob_clean();
            echo $this->buffer; // transfer the data from memory
            ob_flush();

            unset($this->buffer); // free the local buffer memory
        }
        else // limit in-memory double buffering of large data sets (which can crash PHP)
        {
            $filename = $this->m_custom->get_temp_loc() . uniqid() . "uid_{$name}";

            if ($fp = fopen($filename, 'wb'))
            {
                fwrite($fp, $this->buffer, $buffer_size);
                fflush($fp);
                fclose($fp);

                unset($this->buffer); // free the local buffer memory

                header("Content-Type: application/pdf");
                header("Content-disposition: inline; filename=\"{$name}\"");
                header("Content-Transfer-Encoding: binary");
                header("Content-Length: " . filesize($filename));

                ob_clean();
                readfile($filename); // transfer the data from file
                ob_flush();

                unlink($filename);
            }
            else
            {
                echo 'report_pdf::Output() - cannot open file: ' . $filename;
            }
        }

        return '';
    }
};

////////

function get_charset_fonts_map()
{
    $charset_fonts_map = array();

    if (get_charset_map()->get_charset_rpt() == 'iso-8859-1')
    {
        $font_dir = get_font_dir();

        $charset_fonts_map[FONT_FAMILY_ARIAL] = array(FONT_FAMILY_ARIAL, $font_dir);
        $charset_fonts_map[FONT_FAMILY_COURIER] = array(FONT_FAMILY_COURIER, $font_dir);
        $charset_fonts_map[FONT_FAMILY_HELVETICA] = array(FONT_FAMILY_HELVETICA, $font_dir);
        $charset_fonts_map[FONT_FAMILY_TIMES] = array(FONT_FAMILY_TIMES, $font_dir);
    }

    $font_dir = get_font_dir(false); // embedded fonts

    if (is_dir($font_dir))
    {
        if ($dh = opendir($font_dir))
        {
            while (($basename = readdir($dh)) !== false)
            {
                if (preg_match('/(.*)\.php$/i', $basename, $matches))
                {
                    $fontname = $matches[1];

                    $font = implode('', file($font_dir . $basename)); // PHP4 eqv. file_get_contents()

                    if (preg_match('/\$enc=\'(.*)\';/', $font, $matches)  &&
                        get_charset_map()->get_charset_rpt() == $matches[1]) // good enough to parse output from MakeFont()
                    {
                        $charset_fonts_map[$fontname] = array('font_dir'=>$font_dir, 'fontname'=>$fontname);
                    }
                }
            }

            closedir($dh);
        }
    }

    ksort($charset_fonts_map);

    return $charset_fonts_map;
}

function get_charset_fonts()
{
    $charset_fonts = array();

    $font_names = array_keys(get_charset_fonts_map());

    if (!empty($font_names))
    {
        if (is_callable('array_combine'))
        {
            $charset_fonts = array_combine($font_names, $font_names); // PHP >= 5
        }
        else
        {
            foreach ($font_names as $fontname)
            {
                $charset_fonts[$fontname] = $fontname;
            }
        }
    }

    return $charset_fonts;
}

////////

class detail_summary
{
    var $m_custom = null;

    var $m_rows_remaining = 0;
    var $m_col_names = array();
    var $m_detail_summary_cols = array();
    var $m_isuppress_cols = 0;
    var $m_suppress_cols = array();

    var $m_group_stat = array();
    var $m_grand_stat = array();

    function detail_summary(&$custom, &$data)
    {
        $this->m_custom = &$custom;
        $this->build($data);
    }

    function build(&$data)
    {
        if (!empty($data))
        {
            $this->m_rows_remaining = count($data);
            $this->m_col_names = array_keys($data[0]);
        }

        $this->m_detail_summary_cols = $this->m_custom->get_detail_summary_cols();

        $this->m_stage_suppress_col_shift_right = 0;
        $this->m_isuppress_cols = 0;
        $this->m_suppress_cols = array(0);

        if (!empty($this->m_detail_summary_cols))
        {
            foreach ($this->m_detail_summary_cols as $summary_col)
            {
                $this->m_suppress_cols[] = isset($summary_col[2]) ? (int)$summary_col[2] : 0 ;
            }

            sort($this->m_suppress_cols);
        }
    }

    function get_suppress_col()
    {
        return isset($this->m_suppress_cols[$this->m_isuppress_cols]) ? $this->m_suppress_cols[$this->m_isuppress_cols] : 0 ;
    }

    function stage_suppress_col_shift_right()
    {
        $this->m_stage_suppress_col_shift_right += 1;
    }

    function suppress_col_shift_right()
    {
        while ($this->m_stage_suppress_col_shift_right--)
        {
            if (isset($this->m_suppress_cols[1 + $this->m_isuppress_cols]))
            {
                $this->m_isuppress_cols += 1;
            }
            else
            {
                break; // for safety
            }
        }

        $this->m_stage_suppress_col_shift_right = 0;
    }

    function suppress_col_shift_left()
    {
        if ($this->m_isuppress_cols > 0)
        {
            $this->m_isuppress_cols -= 1;
        }
    }

    function reset_summary_row(&$summary_row)
    {
        if (!empty($this->m_col_names))
        {
            foreach ($this->m_col_names as $col_name)
            {
                $summary_row[$col_name] = '';
            }
        }
    }

    function update_col_stat(&$col_stat, &$rec, $col_name, $group_col_name = null)
    {
        $col_stat['count'] += 1;

        if (is_numeric($rec[$col_name]))
        {
            $col_value = 0 + $rec[$col_name];

            $col_stat['sum'] += $col_value;
            $col_stat['ave'] = $col_stat['sum'] / $col_stat['count'];

            if ($col_value < $col_stat['min'] || $col_stat['min'] === null)
            {
                $col_stat['min'] = $col_value;
            }

            if ($col_value > $col_stat['max'] || $col_stat['max'] === null)
            {
                $col_stat['max'] = $col_value;
            }
        }
        else
        {
            $col_stat['sum'] = '';
        }

        if ($col_stat['last'] === null && isset($rec[$group_col_name]))
        {
            $col_stat['last'] = $rec[$group_col_name];
            $this->stage_suppress_col_shift_right();
        }
    }

    function make_col_stat()
    {
        return array('count'=>0, 'sum'=>0, 'ave'=>0, 'min'=>null, 'max'=>null, 'last'=>null);
    }

    function tally_col_stat(&$rec, $col_name, $group_col_name = null)
    {
        $stat_rec = null;

        if ($col_name && isset($rec[$col_name]) /* && is_numeric($rec[$col_name]) */) // TBD: is_numeric() test not-needed or wrong place??
        {
            if (!isset($this->m_grand_stat[$col_name]))
            {
                $this->m_grand_stat[$col_name] = $this->make_col_stat();
            }

            $this->update_col_stat($this->m_grand_stat[$col_name], $rec, $col_name);

            ////////

            if ($group_col_name && isset($rec[$group_col_name]))
            {
                if (!isset($this->m_group_stat[$col_name][$group_col_name]))
                {
                    $this->m_group_stat[$col_name][$group_col_name] = $this->make_col_stat();
                }

                $col_stat = &$this->m_group_stat[$col_name][$group_col_name];

                if ($col_stat['last'] && $col_stat['last'] != $rec[$group_col_name])
                {
                    $stat_rec = $this->m_group_stat[$col_name][$group_col_name]; // copy by value

                    $this->m_group_stat[$col_name][$group_col_name] = $this->make_col_stat();

                    $col_stat = &$this->m_group_stat[$col_name][$group_col_name];
                }

                $this->update_col_stat($col_stat, $rec, $col_name, $group_col_name);
            }
        }

        return $stat_rec;
    }

    function get_group_stat($col_name, $group_col_name)
    {
        return isset($this->m_group_stat[$col_name][$group_col_name]) ? ($this->m_group_stat[$col_name][$group_col_name]) : null ;
    }

    function get_grand_stat($col_name)
    {
        return isset($this->m_grand_stat[$col_name]) ? ($this->m_grand_stat[$col_name]) : null ;
    }

    function get_summary_row(&$rec, $selector = null)
    {
        $summary_row = null;

        if (!empty($rec) && !empty($this->m_detail_summary_cols))
        {
            foreach ($this->m_detail_summary_cols as $summary_col)
            {
                if (empty($summary_col[0]) || empty($summary_col[1]))
                {
                    continue;
                }

                $col_name = $summary_col[0];
                $group_col_name = $summary_col[1];

                $col_stat = null;

                if (!$selector)
                {
                    $col_stat = $this->tally_col_stat($rec, $col_name, $group_col_name);
                }
                else if (!$this->m_rows_remaining)
                {
                    if ($selector == 'final')
                    {
                        $col_stat = $this->get_group_stat($col_name, $group_col_name);
                    }
                    else if ($selector == 'grand')
                    {
                        $col_stat = $this->get_grand_stat($col_name);
                    }
                }

                if ($col_stat)
                {
                    if (!$summary_row)
                    {
                        $this->reset_summary_row($summary_row);
                    }

                    $summary_row[$col_name] = $col_stat['sum'];
                }
            }

            if ($this->m_rows_remaining)
            {
                $this->m_rows_remaining--;
            }
        }

        return $summary_row;
    }

    function get_final_row(&$rec)
    {
        return !$this->m_rows_remaining ? $this->get_summary_row($rec, 'final') : null ;
    }

    function get_grand_row(&$rec)
    {
        return !$this->m_rows_remaining ? $this->get_summary_row($rec, 'grand') : null ;
    }
};

////////

class report_export
{
    var $m_action = null;
    var $m_custom = null;
    var $m_schema = null;
    var $m_query = null;

    function report_export(&$action, &$custom, &$schema, &$query)
    {
        $this->m_action = &$action;
        $this->m_custom = &$custom;
        $this->m_schema = &$schema;
        $this->m_query = &$query;
    }
};

////

class report_txt_tab extends report_export
{
    function do_report(&$recs)
    {
        $export_headings = true; // false; // TODO: configure/customizable
//        $export_keys = true; // false; // TODO: configure/customizable
        $export_col_sep = "\t"; // TODO: enumerate $this->m_export format values

        $filename = $this->m_action->get_qid() . '.export.txt';
        $export_stream = '';

        if (!empty($recs))
        {
            $col_name_iter = null;

            foreach ($recs as $rec)
            {
                if (!$col_name_iter)
                {
                    $col_name_iter = $this->m_custom->get_form_col_order_map(RFORM, array_keys($recs[0]), $this->m_action->get_qid());
                }

                if ($export_headings)
                {
                    $export_headings = false;

                    $sep = '';

                    foreach ($col_name_iter as $col_name)
                    {
                        $col_value = $rec[$col_name];

                        if (!$this->m_custom->is_form_omit_col(RFORM, $col_name, $this->m_action->get_qid()))
                        {
                            $export_stream .= $sep . str_replace($export_col_sep, '', $col_name);
                            $sep = $export_col_sep;
                        }
                    }

                    $export_stream .= "\n";
                }

                ////

                $sep = '';

                foreach ($col_name_iter as $col_name)
                {
                    $col_value = $rec[$col_name];

                    if (!$this->m_custom->is_form_omit_col(RFORM, $col_name, $this->m_action->get_qid()))
                    {
                        $col_value = str_replace("\n", '', $col_value);
                        $col_value = str_replace("\r", '', $col_value);
                        $col_value = str_replace($export_col_sep, '', $col_value);
                        $export_stream .= $sep . $col_value;
                        $sep = $export_col_sep;
                    }
                }

                $export_stream .= "\n";
            }
        }

        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment; filename={$filename};");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: " . strlen($export_stream));

        echo $export_stream;
    }
};

////

class report_ods extends report_export
{
    function do_report(&$recs)
    {
        $export_headings = true; // false; // TODO: configure/customizable
        $export_keys = false; // true; // TODO: configure/customizable

        ////

        $col_count = 0;
        $col_width = 8; // pt
        $row_height = $this->m_custom->get_rpt_row_size() ? $this->m_custom->get_rpt_row_size() * 6 : 15 ; // pt
        $media_id = 0;
        $media = null;
        $manifest_image = '';
        $headings = $export_headings ? '' : null ;
        $content_body = '';

        $table_name = $this->m_query->get_table();

        if (!empty($recs))
        {
            $map = $this->m_schema->get_col_display_name_map($table_name);
            $col_name_iter = null;

            foreach ($recs as $rec)
            {
                if (!$col_name_iter)
                {
                    $col_name_iter = $this->m_custom->get_form_col_order_map(RFORM, array_keys($recs[0]), $this->m_action->get_qid());
                }

                $content_body .= '<table:table-row table:style-name="ro1">';

                foreach ($col_name_iter as $col_name)
                {
                    $col_value = $rec[$col_name];

                    if (!$export_keys && ($this->m_schema->is_pk($table_name, $col_name) || $this->m_schema->is_fk($table_name, $col_name)))
                    {
                        continue;
                    }

                    if (!$this->m_custom->is_form_omit_col(RFORM, $col_name, $this->m_action->get_qid()))
                    {
                        if (isset($headings))
                        {
                            $headings .= '<table:table-cell office:value-type="string" table:style-name="ce1">';

                            $display_name = fmt_display_name($col_name);

                            if (isset($map[$col_name]))
                            {
                                $display_name = $map[$col_name];
                            }
                            else if (strpos($col_name, "{$table_name}_") === 0) // TODO: encapsulate
                            {
                                $macro_name = str_replace("{$table_name}_", '', $col_name); // TODO: encapsulate

                                if (isset($map[$macro_name]))
                                {
                                    $display_name = $map[$macro_name];
                                }
                            }

                            $headings .= '<text:p>' . encode_entities($display_name) . '</text:p>';

                            $headings .= '</table:table-cell>';
                        }

                        if (trim($col_value) != '')
                        {
                            if ($this->m_custom->get_col_media_type($col_name) == TYPE_IMAGE &&
                                preg_match('/.(jpg|png)$/i', $col_value, $ext_matches) &&
                                $ext_matches[1] == 'jpg' && // TODO: TMP: until png supported
                                ($img_file = $this->m_custom->get_media_loc(TYPE_IMAGE) . $col_value) &&
                                file_exists($img_file))
                            {
                                $col_size = $this->m_custom->get_form_col_size(RFORM, $col_name);

                                if ($col_size > $col_width)
                                {
                                    $col_width = $col_size; // TODO: KLUGE: one size fits all
                                }

                                if (empty($media[$col_value]))
                                {
                                    $media[$col_value] = $img_file;
                                    fmt_line($manifest_image, '<manifest:file-entry manifest:full-path="media/' . $col_value . '" manifest:media-type="image/jpeg"/>');
                                }

                                $media_id++;

                                $content_body .= '<table:table-cell table:style-name="ce1">';
                                $content_body .= get_frame($media_id, $col_value);
                                $content_body .= '</table:table-cell>';
                            }
                            else
                            {
                                $content_body .= '<table:table-cell office:value-type="string" table:style-name="ce1">';
                                $content_body .= '<text:p>' . encode_entities($col_value) . '</text:p>';
                                $content_body .= '</table:table-cell>';
                            }
                        }
                        else
                        {
                            $content_body .= '<table:table-cell table:style-name="ce1"/>';
                        }

                        $col_count++;
                    }
                }

                $content_body .= '</table:table-row>';

                if (!empty($headings))
                {
                    $content_body = '<table:table-row table:style-name="ro1">' . $headings . '</table:table-row>' . $content_body;
                    unset($headings);
                }
            }
        }

        $col_width = ($col_width * 6 / 72) . 'in';
        $row_height .= 'pt';

        ////

        $zip = new ZipArchive();

        $zipdir = $this->m_custom->get_temp_loc();

        if (!is_dir($zipdir))
        {
            exit ("report_ods::do_report() - no directory: $zipdir");
        }

        $filename = $zipdir . uniqid() . "uid_{$table_name}.ods";

        if ($zip->open($filename, ZIPARCHIVE::CREATE) !== true)
        {
            exit ("report_ods::do_report() - cannot open ZipArchive: $filename");
        }

        $zip->addFromString("content.xml", get_content_preamble(get_entity_references(), $col_width, $row_height, $col_count) .
                                           $content_body .
                                           get_content_postamble());

        $zip->addFromString("META-INF/manifest.xml", get_manifest_xml($manifest_image));

        if (!empty($media))
        {
            foreach ($media as $image_name => $image_file)
            {
                $zip->addFile($image_file, 'media/' . $image_name);
            }
        }

        $zip->addFromString('meta.xml', get_meta_xml());
        $zip->addFromString('mimetype', 'application/vnd.oasis.opendocument.spreadsheet');
        $zip->addFromString('styles.xml', get_styles_xml());

        $zip->close();

        flush();

        ////

        if (!$zip->status)
        {
            header("Pragma: public");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Content-Type: application/force-download");
            header("Content-Type: application/octet-stream");
            header("Content-Type: application/download");
            header("Content-Disposition: attachment; filename={$table_name}.ods");
            header("Content-Transfer-Encoding: binary");
            header("Content-Length: " . filesize($filename));

            ob_clean();

            readfile($filename);

            unlink($filename);
        }
    }
};

////

function &new_report(&$action, &$custom, &$schema, &$query)
{
    $obj = null;

    if ($action->is_export())
    {
        $export_type = $custom->get_export_type();

        if ($export_type == EXPORT_TYPE_TXT_TAB)
        {
            $obj = new report_txt_tab($action, $custom, $schema, $query);
        }
        else if ($export_type == EXPORT_TYPE_ODS && method_exists('ZipArchive', 'open'))
        {
            $obj = new report_ods($action, $custom, $schema, $query);
        }
        else
        {
            exit ('EXPORT_TYPE: ' . $custom->get_export_type_descr() . ' - not supported on this server');
        }
    }
    else
    {
        $obj = new report_pdf($action, $custom, $schema, $query);
    }

    return $obj;
}

/*
** xml templates for EXPORT_TYPE_ODS
*/

function get_content_preamble($entity_references, $col_width, $row_height, $col_count, $font = FONT_FAMILY_HELVETICA)
{
return <<<PREAMBLE
<?xml version="1.0" encoding="utf-8" standalone="no"?>
$entity_references<office:document-content xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0"
xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"
xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0"
xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:msoxl="http://schemas.microsoft.com/office/excel/formula">
<office:font-face-decls>
<style:font-face style:name="$font" svg:font-family="$font"/>
</office:font-face-decls>
<office:automatic-styles>
<style:style style:name="ce1" style:family="table-cell" style:parent-style-name="Default" style:data-style-name="N0"/>
<style:style style:name="co1" style:family="table-column">
<style:table-column-properties fo:break-before="auto" style:column-width="$col_width"/>
</style:style>
<style:style style:name="ro1" style:family="table-row">
<style:table-row-properties style:row-height="$row_height" style:use-optimal-row-height="false" fo:break-before="auto"/>
</style:style>
<style:style style:name="ta1" style:family="table" style:master-page-name="mp1">
<style:table-properties table:display="true" style:writing-mode="lr-tb"/>
</style:style>
<style:style style:family="graphic" style:name="a0" style:parent-style-name="Graphics">
<style:graphic-properties draw:fill="none" draw:stroke="none"/>
</style:style>
</office:automatic-styles>
<office:body>
<office:spreadsheet>
<table:calculation-settings table:case-sensitive="false" table:search-criteria-must-apply-to-whole-cell="false"/>
<table:table table:name="Sheet1" table:style-name="ta1">
<table:table-column table:style-name="co1" table:number-columns-repeated="$col_count" table:default-cell-style-name="ce1"/>
PREAMBLE;
}

function get_frame($media_id, $col_value)
{
return <<<FRAME
<draw:frame draw:z-index="$media_id" draw:id="id$media_id" draw:style-name="a0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0"
draw:name="$col_value" svg:x="0in" svg:y="0in" svg:width="1in" svg:height="1in" style:rel-width="scale" style:rel-height="scale">
<draw:image xlink:href="media/$col_value" xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/>
<svg:desc>$col_value</svg:desc>
</draw:frame>
FRAME;
}

function get_content_postamble()
{
return <<<POSTAMBLE
</table:table>
</office:spreadsheet>
</office:body>
</office:document-content>
POSTAMBLE;
}

function get_manifest_xml($manifest_image)
{
return <<<MANIFEST
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0">
<manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>
<manifest:file-entry manifest:full-path="META-INF/manifest.xml" manifest:media-type="text/xml"/>
<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>
<manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/>
<manifest:file-entry manifest:full-path="mimetype" manifest:media-type="text/plain"/>
<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>
$manifest_image
</manifest:manifest>
MANIFEST;
}

function get_meta_xml()
{
return <<<META
<?xml version="1.0" encoding="utf-8" standalone="yes" ?>
<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:xlink="http://www.w3.org/1999/xlink" office:version="1.1">
<office:meta>
<meta:generator>SynApp2</meta:generator>
<meta:initial-creator>user_login</meta:initial-creator>
<dc:creator>user_login</dc:creator>
<meta:creation-date>2010-08-19T17:07:44Z</meta:creation-date>
<dc:date>2010-08-19T17:09:36Z</dc:date>
</office:meta>
</office:document-meta>
META;
}

function get_styles_xml($font = FONT_FAMILY_HELVETICA, $font_size = '11pt')
{
return <<<STYLES
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<office:document-styles xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" xmlns:msoxl="http://schemas.microsoft.com/office/excel/formula">
<office:font-face-decls>
<style:font-face style:name="$font" svg:font-family="$font"/>
</office:font-face-decls>
<office:styles>
<number:number-style style:name="N0">
<number:number number:min-integer-digits="1"/>
</number:number-style>
<style:style style:name="Graphics" style:family="table-cell" style:data-style-name="N0"/>
<style:style style:name="Default" style:family="table-cell" style:data-style-name="N0">
<style:table-cell-properties style:vertical-align="automatic" fo:background-color="transparent"/>
<style:text-properties fo:color="#000000" style:font-name="$font" style:font-name-asian="$font" style:font-name-complex="$font" fo:font-size="$font_size" style:font-size-asian="$font_size" style:font-size-complex="$font_size"/>
</style:style>
<style:style style:family="graphic" style:name="Graphics"/>
<style:default-style style:family="graphic">
<style:graphic-properties draw:fill="solid" draw:fill-color="#4f81bd" draw:opacity="100%" draw:stroke="solid" svg:stroke-width="0.02778in" svg:stroke-color="#385d8a" svg:stroke-opacity="100%"/>
</style:default-style>
</office:styles>
<office:automatic-styles>
<style:page-layout style:name="pm1">
<style:page-layout-properties fo:margin-top="0.3in" fo:margin-bottom="0.3in" fo:margin-left="0.7in" fo:margin-right="0.7in" style:table-centering="none" style:print="objects charts drawings"/>
<style:header-style>
<style:header-footer-properties fo:min-height="0.45in" fo:margin-left="0.7in" fo:margin-right="0.7in" fo:margin-bottom="0in"/>
</style:header-style>
<style:footer-style>
<style:header-footer-properties fo:min-height="0.45in" fo:margin-left="0.7in" fo:margin-right="0.7in" fo:margin-top="0in"/>
</style:footer-style>
</style:page-layout>
</office:automatic-styles>
<office:master-styles>
<style:master-page style:name="mp1" style:page-layout-name="pm1">
<style:header/>
<style:header-left style:display="false"/>
<style:footer/>
<style:footer-left style:display="false"/>
</style:master-page>
</office:master-styles>
</office:document-styles>
STYLES;
}

////

?>
