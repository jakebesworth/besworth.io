<?php
if (!class_exists('FPDF'))
{
    require('fpdf.php'); // rhowell - 2011-04-13
}

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;

function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

// rhowell - 2009-07-21 - Add simple row border/shading support
//
function SetRowColors($cell_border, $row_shade)
{
    static $black = 0;
    static $gray = 230;
    static $white = 255;

    if ($row_shade)
    {
        $this->SetFillColor($gray);
    }
    else
    {
        $this->SetFillColor($white);
    }

    if (!$cell_border)
    {
        if ($row_shade)
        {
            $this->SetDrawColor($gray);
        }
        else
        {
            $this->SetDrawColor($white);
        }
    }
    else
    {
        $this->SetDrawColor($black);
    }
}

// rhowell - 2009-07-21 - Add simple row border/shading support
//
function ResetRowColors()
{
    static $black = 0;
    static $gray = 230;
    static $white = 255;

    // hard reset border and fill // KLUGE: HACK:
    $this->SetDrawColor($black);
    $this->SetFillColor($white);
}

// rhowell - 2010-08-19 - image support
//
function get_row_height() // virtual
{
    return 0;
}

// rhowell - 2010-08-19 - image support
//
function is_image_col($i) // virtual
{
    return false;
}

// rhowell - 2010-08-19 - image support
//
function get_image_loc() // virtual
{
    return '';
}

function Row($data, $cell_border, $row_shade, $suppress = 0, $is_body_row = false)
{
    $ch = $this->FontSize * 1.15; // HACK: FIX: rhowell - 2008-04-14 - Add $ch - character height
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
//    $h=5*$nb; // TODO: TBD: rhowell - 2008-04-14 - constant 5 - bug??
    $h=$ch*$nb; // SEE: rhowell - 2008-04-14 - $ch fix above
    if ($is_body_row && $h < $this->get_row_height()) // rhowell - 2010-08-19 - image support
    {
        $h = $this->get_row_height();
    }
    $page = $this->page;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Reset row shading and column suppression on page break // rhowell - 2009-07-21
    if ($page != $this->page)
    {
        $row_shade = false;
        $suppress = 0;
    }
    $this->SetRowColors($cell_border, $row_shade); // rhowell - 2009-07-21
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
//        $this->Rect($x,$y,$w,$h);
        $this->Rect($x,$y,$w,$h,($row_shade ? 'FD' : null)); // rhowell - 2009-07-21 - add shading support
        //Output the cell data
        if ($is_body_row &&
            $this->is_image_col($i) &&
            preg_match('/.(jpg|png)$/i', $data[$i], $matches)) // rhowell - 2010-08-19 - image support
        {
            $img_file = $this->get_image_loc() . $data[$i];

            if (file_exists($img_file) && ($info = $matches[1] == 'jpg' ? $info = $this->_parsejpg($img_file) : $this->_parsepng($img_file)))
            {
                if (!isset($this->images[$img_file]))
                {
                    $info['i'] = count($this->images) + 1;
                    $this->images[$img_file] = $info;
                }

                $img_height = $h;

                if ($info['w'] > $info['h'])
                {
                    $img_height = floor($h * ($info['h'] / $info['w']));
                }

                $this->Image($img_file, $x + 1, $y + 1, 0, $img_height - 2);
            }
        }
        else
        {
            //Print the text
//            $this->MultiCell($w,5,$data[$i],0,$a); // TODO: TBD: rhowell - 2008-04-14 - constant 5 - bug??
//            $this->MultiCell($w,$ch,$data[$i],0,$a); // SEE: rhowell - 2008-04-14 - $ch FIX: above
            $this->MultiCell($w,$ch,($i < $suppress ? '' : $data[$i]),0,$a); // rhowell - 2009-07-22 - add column suppression
        }
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    $this->ResetRowColors(); // rhowell - 2009-07-21
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}
}
?>
