<?php

/* schema.php - SynApp2 database schema analyzer/driver
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2010 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: schema.php,v 1.14 2011/01/08 18:07:34 richard Exp $
*/

class schema
{
    var $m_dbx = null;
    var $m_custom = null;

    var $m_table_names = null; // TODO: consolidate into table object
    var $m_col_info = null; // TODO: consolidate into table object
    var $m_col_names = null; // TODO: consolidate into table object
    var $m_col_indexes = null;// TODO: consolidate into table object
    var $m_table_paths = null;
    var $m_graph = null;

    function schema(&$dbx, &$custom, $active)
    {
        $this->m_dbx = &$dbx;
        $this->m_custom = &$custom;

        if ($active)
        {
            $this->build();
        }
    }

    function build()
    {
        $this->fetch_table_names();
        $this->fetch_col_info_all();
        $this->fetch_col_names_indexes();
        $this->push_pk_map();
        $this->fetch_table_paths_all();
        $this->fetch_graph();
    }

    function is_sys_table($table_name)
    {
        return $table_name == KEYMAP || $table_name == CUSTOM || $table_name == HTMLDBPT;
    }

    function is_pk($table_name, $col_name)
    {
        return !empty($table_name) && !empty($col_name) && $this->m_custom->get_pk_name($table_name) == $col_name;
    }

    function is_fk($table_name, $col_name)
    {
        return !$this->is_pk($table_name, $col_name) && $this->m_custom->get_parent_name($table_name, $col_name) != null;
    }

    function is_set($table_name, $col_name)
    {
        return $this->get_set_values($table_name, $col_name) != null;
    }

    function get_on_update_current_timestamp($table_name)
    {
        static $_cache = null;

        $result = '';

        if (!empty($_cache[$table_name]))
        {
            $result = $_cache[$table_name];
        }
        else
        {
            $rows = $this->m_dbx->get_query_records("show create table $table_name"); // NOTE: MySQL specific

            if (!empty($rows[0]['Create Table']))
            {
                $csv = explode(',', $rows[0]['Create Table']);

                foreach ($csv as $search)
                {
                    if (preg_match("/`(.+)` .+(on update CURRENT_TIMESTAMP) .+/i", $search, $matches)) // NOTE: MySQL specific // TODO: configurable
                    {
                        $result = $matches[1]; // field name of 'on update' column
                        $_cache[$table_name] = $result;
                        break;
                    }
                }
            }
        }

        return $result;
    }

    function is_on_update_current_timestamp($table_name, $col_name)
    {
        return !empty($col_name) && $col_name == $this->get_on_update_current_timestamp($table_name);
    }

    function is_on_insert_current_timestamp($table_name, $col_name)
    {
        $col_type = $this->find_col_info($table_name, $col_name, 'Type');

        if (is_string($col_type))
        {
            $col_type = strtoupper($col_type);
        }

        return !empty($col_name) && $col_type == 'TIMESTAMP' && $col_name != $this->get_on_update_current_timestamp($table_name);
    }

    function is_auto($table_name, $col_name)
    {
        $result = false;

        $col_info = $this->find_col_info($table_name, $col_name);

        if (!empty($col_info) &&
            preg_match('/AUTO *= *([_a-z0-9]+)\(\)/i', $col_info['Comment']))
        {
            $result = true;
        }

        return $result;
    }

    function is_blind($table_name, $col_name)
    {
        $result = false;

        $col_info = $this->find_col_info($table_name, $col_name);

        if (!empty($col_info) &&
            (preg_match('/TIMESTAMP/i', $col_info['Type']) ||
             preg_match('/ON_INSERT_/i', $col_info['Comment']) ||
             preg_match('/ON_UPDATE_/i', $col_info['Comment'])))
        {
            $result = true;
        }

        return $result;
    }

    function is_num($table_name, $col_name, $col_info = null)
    {
        if (!$col_info)
        {
            $col_info = $this->find_col_info($table_name, $col_name);
        }

        return $col_info ? (preg_match('/(INT|BIT|FLOAT|DOUBLE|DECIMAL|NUMERIC|REAL)/i', $col_info['Type']) ? true : false) : null ;
    }

    function is_date_time($table_name, $col_name, $col_info = null)
    {
        if (!$col_info)
        {
            $col_info = $this->find_col_info($table_name, $col_name);
        }

        return $col_info ? (preg_match('/(DATE|TIME|YEAR)/i', $col_info['Type']) ? true : false) : null ;
    }

    function get_set_values($table_name, $col_name)
    {
         // TODO: HACK: KLUGE: clean this up - no loop needed
         // TODO: in fact, fields could be instances of a class;
         //       that would allow extraction of values via something like field->get_col_values()
         $values = null;

         $cols_info = $this->get_table_cols_info($table_name);

         if (!empty($cols_info))
         {
             foreach ($cols_info as $col_info)
             {
                 if ($col_name == $col_info['Field'] && strpos($col_info['Type'], 'enum') === 0)
                 {
                    $col_type_detail = $this->get_col_type_detail($col_info);

                    if (!empty($col_type_detail['values']))
                    {
                        $values = $col_type_detail['values'];
                    }

                    break;
                 }
             }
         }

         return $values;
    }

    function translate_special_col_value($table_name, $col_name, &$col_value, $is_insert = false)
    {
        $result = false;

        $col_var_is_present = isset($col_value); // i.e., do action only when an empty form col_var is presented

        if (empty($col_value) && !is_numeric($col_value)) // prevent overwriting of any existing value
        {
            $col_info = $this->find_col_info($table_name, $col_name);

            if (!empty($col_info))
            {
                if ($is_insert && $this->is_on_insert_current_timestamp($table_name, $col_name))
                {
                    $col_value = 'now()';
                    $result = true;
                }
                else if ($is_insert && preg_match('/ON_INSERT_FUNCTION/i', $col_info['Comment']))
                {
                    assert('!"ON_INSERT_FUNCTION - case not implemented"');
                }
                else if (!$is_insert && preg_match('/ON_UPDATE_FUNCTION/i', $col_info['Comment']))
                {
                    assert('!"ON_UPDATE_FUNCTION - case not implemented"');
                }
                else if (preg_match('/ON_EMPTY_VALUE_SET_DEFAULT/i', $col_info['Comment']))
                {
                    if ($col_var_is_present)
                    {
                        if (isset($col_info['Default']))
                        {
                            $col_value = "'" . $col_info['Default'] . "'";
                            $result = true;
                        }
                        else if (preg_match('/^Y/i', $col_info['Null']))
                        {
                            $col_value = 'null';
                            $result = true;
                        }
                    }
                }
                else if (preg_match('/^Y/i', $col_info['Null']) &&
                         ($this->is_num($table_name, $col_name, $col_info) ||
                          $this->is_date_time($table_name, $col_name, $col_info)))
                {
                    if ($col_var_is_present)
                    {
                        $col_value = 'null';
                        $result = true;
                    }
                }
            }
        }

        return $result;
    }

    function gather_col_defaults()
    {
        $result = null;

        $cols_info = $this->get_table_cols_info($this->m_custom->get_table());

        if (!empty($cols_info))
        {
            foreach ($cols_info as $col_info)
            {
                if (preg_match('/auto_increment/i', $col_info['Extra']))
                {
                    continue;
                }
                else if (preg_match('/INIT *= *([_a-z0-9]+)\(\)/i', $col_info['Comment'], $matches) ||
                         preg_match('/AUTO *= *([_a-z0-9]+)\(\)/i', $col_info['Comment'], $matches))
                {
                    $func_name = $matches[1];

                    if (function_exists($func_name))
                    {
                        $result[$col_info['Field']] = call_user_func($func_name);
                    }
                }
                else if (preg_match('/TIMESTAMP/i', $col_info['Type']))
                {
                    continue; // don't mess with TIMESTAMP // TODO: TBD: test is_blind() instead??
                }
                else if (strlen($col_info['Default']))
                {
                    $result[$col_info['Field']] = $col_info['Default'];
                }
            }
        }

        return $result;
    }

    function fetch_table_names()
    {
        $this->m_table_names = $this->m_dbx->get_table_names();
    }

    function fetch_col_info($table_name)
    {
        $this->m_col_info[$table_name] = $this->m_dbx->get_col_info($table_name);
    }

    function fetch_col_info_all()
    {
        if (!empty($this->m_table_names))
        {
            //array_map(array($this, 'fetch_col_info'), $this->m_table_names);
            foreach ($this->m_table_names as $table_name)
            {
                $this->fetch_col_info($table_name);
            }
        }
    }

    function fetch_col_names_indexes()
    {
        $this->m_col_names = null;
        $this->m_col_indexes = null;

        if (!empty($this->m_table_names))
        {
            foreach ($this->m_table_names as $table_name)
            {
                $cols_info = $this->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    foreach ($cols_info as $i => $col_info)
                    {
                        $this->m_col_names[$table_name][] = $col_info['Field'];
                        $this->m_col_indexes[$table_name][$col_info['Field']] = $i;
                    }
                }
            }
        }
    }

    function fetch_table_paths($table_name, $is_root=true)
    {
        static $depth = 0; // TODO: HACK: KLUGE:
        static $root_table_name = '';
        static $path = 0;

        if ($is_root)
        {
            $depth = 0; // TODO: HACK: KLUGE:
            $root_table_name = $table_name;
            $path = 0;
            $this->m_table_paths[$root_table_name] = array();
        }
        else
        {
            if ($depth++ >= 100)
            {
                // TODO: HACK: KLUGE: deal with this heuristically, but make sure we do not break legal relationships
                add_debug_msg($table_name, 'fetch_table_paths() - circular reference, check ' . KEYMAP);
                return;
            }

            $this->m_table_paths[$root_table_name][$path][] = $table_name;
        }

        $cols_info = $this->get_table_cols_info($table_name);

        if (!empty($cols_info))
        {
            foreach ($cols_info as $col_info)
            {
                if ($parent_name = $this->m_custom->get_parent_name($table_name, $col_info['Field']))
                {
                    $this->fetch_table_paths($parent_name, false);

                    if ($is_root)
                    {
                        $path++;
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
    }

    function fetch_table_paths_all()
    {
        if (!empty($this->m_table_names))
        {
//            array_map(array($this, 'fetch_table_paths'), $this->m_table_names);
            foreach ($this->m_table_names as $table_name)
            {
                $this->fetch_table_paths($table_name);
            }
        }
    }

    function get_table_names()
    {
        return is_array($this->m_table_names) ? $this->m_table_names : array() ;
    }

    function get_col_names($table_name)
    {
        return isset($this->m_col_names[$table_name]) && is_array($this->m_col_names[$table_name]) ? $this->m_col_names[$table_name] : array() ;
    }

    function get_table_paths($table_name)
    {
        return !empty($this->m_table_paths[$table_name]) ? $this->m_table_paths[$table_name] : null ;
    }

    function fetch_graph()
    {
        $this->m_graph = null;

        if (!empty($this->m_table_names))
        {
            foreach ($this->m_table_names as $table_name)
            {
                $cols_info = $this->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    foreach ($cols_info as $col_info)
                    {
                        if (($parent_name = $this->m_custom->get_parent_name($table_name, $col_info['Field'])) &&
                            ($join_col = $this->m_custom->get_parent_join_col($parent_name, $table_name, $col_info['Field'])))
                        {
                            $this->m_graph[$table_name]['parents'][] = array(TABLE_NAME=>$table_name, COL_NAME=>$col_info['Field'], JOIN_TABLE=>$parent_name, JOIN_COL=>$join_col);
                            $this->m_graph[$parent_name]['children'][] = array(TABLE_NAME=>$table_name, COL_NAME=>$col_info['Field'], JOIN_TABLE=>$parent_name, JOIN_COL=>$join_col);
                        }
                    }
                }
            }
        }
    }

    function push_pk_map()
    {
        if (!empty($this->m_table_names))
        {
            $pkeys = array();
            $table_col_names = array();

            foreach ($this->m_table_names as $table_name)
            {
                if ($this->is_sys_table($table_name))
                {
                    continue;
                }

                $cols_info = $this->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    foreach ($cols_info as $col_info)
                    {
                        $col_name = $col_info['Field'];

                        if (strpos($col_info['Key'], 'PRI') !== false)
                        {
                            $pkeys[$table_name] = $col_name;
                        }

                        $table_col_names[$table_name][] = $col_name;
                    }
                }
            }

            $this->m_custom->push_pk_map($pkeys, $table_col_names);
        }
    }

    function get_parents($table_name)
    {
        return !empty($this->m_graph[$table_name]['parents']) ? $this->m_graph[$table_name]['parents'] : null;
    }

    function get_children($table_name)
    {
        return !empty($this->m_graph[$table_name]['children']) ? $this->m_graph[$table_name]['children'] : null;
    }

    function get_count_paths($table_name)
    {
        return isset($this->m_graph[$table_name]['parents']) ?
               count($this->m_graph[$table_name]['parents']) :
               0 ;
    }

    function is_table_present($table_name)
    {
        return !empty($this->m_table_names) ? in_array($table_name, $this->m_table_names) : null;
    }

    function get_col_display_name(&$col_info)
    {
        $col_display_name = '';

        assert(isset($col_info['Field']) && isset($col_info['Comment']));

        if (isset($col_info['Field']) && isset($col_info['Comment']))
        {
            $col_display_name = fmt_display_name($col_info['Field']);

            if (!empty($col_info['Comment']))
            {
                list($display_name) = explode(',', $col_info['Comment']);

                if ($display_name = trim($display_name))
                {
                    $col_display_name = $display_name;
                }
            }
        }

        return $col_display_name;
    }

    function get_col_display_name_map($table_name)
    {
        $map = null;

        $cols_info = $this->get_table_cols_info($table_name);

        if (!empty($cols_info))
        {
            foreach ($cols_info as $col_info)
            {
                $map[$col_info['Field']] = $this->get_col_display_name($col_info);
            }
        }

        return $map;
    }

    function get_col_type_detail(&$col_info)
    {
        $col_type_detail = null;

        if (isset($col_info['Type']))
        {
            # adapted from comments about mysql_fetch_field() found on php.net - many thanks
            #
            # split type into an array where
            # row is mysql type, in format "int(11) unsigned zerofill"
            # or "enum('cheese','salmon')" etc.

            preg_match('/^([^ (]+)(\((.+)\))?([ ](.+))?$/', $col_info['Type'], $matches);

            $col_type_detail['type'] = strtoupper(!empty($matches[1]) ? $matches[1] : '');  # eg 'int' for integer.
            $col_type_detail['flags'] = !empty($matches[5]) ? $matches[5] : '' ;            # eg 'binary' or 'unsigned zerofill'.
            $col_type_detail['maxlength'] = !empty($matches[3]) ? $matches[3] : '' ;        # eg 11, or 'cheese','salmon' for enum.
            $col_type_detail['values'] = '';

            switch ($col_type_detail['type'])
            {
            case 'ENUM':
            case 'SET':
                # build an array of possible values.
                $col_type_detail['values'] = preg_split("/','/", substr($col_type_detail['maxlength'], 1, -1));

                if (!empty($col_type_detail['values']))
                {
                    $col_type_detail['maxlength'] = 0;

                    foreach ($col_type_detail['values'] as $value)
                    {
                        if (($length = strlen($value)) > $col_type_detail['maxlength'])
                        {
                            $col_type_detail['maxlength'] = $length;
                        }
                    }
                }
                break;
            case 'DATE':
                $col_type_detail['maxlength'] = strlen('yyyy-mm-dd');
                break;
            case 'TIME':
                $col_type_detail['maxlength'] = strlen('hh:mm:ss');
                break;
            case 'TIMESTAMP':
            case 'DATETIME':
                $col_type_detail['maxlength'] = strlen('yyyy-mm-dd hh:mm:ss');
                break;
            case 'DECIMAL':
                if (preg_match('/([0-9]+) *, *([0-9]+)/', $col_type_detail['maxlength'], $matches))
                {
                    $col_type_detail['maxlength'] = $matches[1] + $matches[2];
                }
                $col_type_detail['maxlength'] = strlen('-.') + $col_type_detail['maxlength'];
                break;
            default:
                $col_type_detail['maxlength'] = (int)$col_type_detail['maxlength'];
                break;
            }
        }

        return $col_type_detail;
    }

    function get_table_cols_info($table_name)
    {
        // NOTE: is case different between TABLE_NAME and a qid being used as table_name??
        //assert('!empty($this->m_col_info[$table_name]); // schema::get_table_cols_info()'); // TODO: better diagnostic
        return !empty($this->m_col_info[$table_name]) ? $this->m_col_info[$table_name] : null;
    }

    function find_col_info($table_name, $col_name, $info_name = null)
    {
        $result = null;

        $cols_info = $this->get_table_cols_info($table_name);

        if (!empty($cols_info))
        {
            foreach ($cols_info as $col_info)
            {
                if ($col_name == $col_info['Field'])
                {
                    if (isset($col_info[$info_name]))
                    {
                        $result = $col_info[$info_name];
                    }
                    else
                    {
                        $result = $col_info;
                    }

                    break;
                }
            }
        }

        return $result;
    }

    function get_table_col_count($table_name)
    {
        return !empty($this->m_col_info[$table_name]) ? count($this->m_col_info[$table_name]) : 0;
    }

    function get_keys_info($for_table_name = null)
    {
        $result = null;

        if (!empty($this->m_table_names))
        {
            foreach ($this->m_table_names as $table_name)
            {
                if ($this->is_sys_table($table_name))
                {
                    continue;
                }

                $cols_info = $this->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    foreach ($cols_info as $col_info)
                    {
                        $col_name = $col_info['Field'];

                        $is_pk = $this->is_pk($table_name, $col_name);
                        $is_PRI = strpos($col_info['Key'], 'PRI') !== false;

//                        assert('$is_pk == $is_PRI'); // TODO: will the real primary key please stand up...

                        $join_table = $is_pk ? $table_name : $this->m_custom->get_parent_name($table_name, $col_name) ;
                        $join_col = $is_pk ? $col_name : $this->m_custom->get_parent_join_col($join_table, $table_name, $col_name) ;

                        $result[$table_name][] = array(TABLE_NAME=>$table_name,
                                                       COL_NAME=>$col_name,
                                                       JOIN_TABLE=>$join_table,
                                                       JOIN_COL=>$join_col,
                                                       'is_pk'=>$is_pk,
                                                       'is_PRI'=>$is_PRI,
                                                       'is_auto_increment'=>strpos($col_info['Extra'], 'auto_increment') !== false);
                    }
                }

                if ($for_table_name && $table_name == $for_table_name)
                {
                    break;
                }
            }
        }

        return $result;
    }

    function get_primary_keys_info()
    {
        $result = null;

        if (!empty($this->m_table_names))
        {
            foreach ($this->m_table_names as $table_name)
            {
                if ($this->is_sys_table($table_name))
                {
                    continue;
                }

                $cols_info = $this->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    foreach ($cols_info as $col_info)
                    {
                        $col_name = $col_info['Field'];

                        if (strpos($col_info['Key'], 'PRI') !== false)
                        {
                            $result[$table_name] = array(TABLE_NAME=>$table_name,
                                                         COL_NAME=>$col_name,
                                                         JOIN_TABLE=>$table_name,
                                                         JOIN_COL=>$col_name,
                                                         'is_auto_increment'=>strpos($col_info['Extra'], 'auto_increment') !== false,
                                                         'is_mapped'=>$this->is_pk($table_name, $col_name));
                            break;
                        }
                    }
                }
            }
        }

        return $result;
    }

    function get_foreign_keys_info()
    {
        $result = null;

        if (!empty($this->m_table_names))
        {
            foreach ($this->m_table_names as $table_name)
            {
                if ($this->is_sys_table($table_name))
                {
                    continue;
                }

                $cols_info = $this->get_table_cols_info($table_name);

                if (!empty($cols_info))
                {
                    foreach ($cols_info as $col_info)
                    {
                        $col_name = $col_info['Field'];

                        if (strpos($col_info['Key'], 'PRI') === false)
                        {
                            $join_table = $this->m_custom->get_parent_name($table_name, $col_name);

                            if (!empty($join_table))
                            {
                                $join_col = $this->m_custom->get_parent_join_col($join_table, $table_name, $col_name);

                                if (!empty($join_col))
                                {
                                    $result[$table_name][] = array(TABLE_NAME=>$table_name,
                                                                   COL_NAME=>$col_name,
                                                                   JOIN_TABLE=>$join_table,
                                                                   JOIN_COL=>$join_col);
                                }
                            }
                        }
                    }
                }
            }
        }

        return $result;
    }

    function get_value_col($table_name, $col_name)
    {
        $value_col = "";

        $parent_name = $this->m_custom->get_parent_name($table_name, $col_name);

        $cols_info = $this->get_table_cols_info($parent_name);

        if (!empty($cols_info))
        {
            foreach ($cols_info as $col_info)
            {
                $col_name = $col_info['Field'];

                if (!$this->is_pk($parent_name, $col_name) && !$this->is_fk($parent_name, $col_name))
                {
                    $value_col = "$parent_name.$col_name";
                    break;
                }
            }
        }

        return $value_col;
    }

    function is_dependent_expr($table_name, $expr)
    {
        return strpos($expr, $table_name . '.') !== false &&
               !preg_match("/[a-zA-Z0-9_]$table_name\./", $expr); // TODO: TBD: more work here??
    }

    function get_col_dependencies($basis_table, $ignore_tables, $col_exprs)
    {
        $deps = null;

        foreach ($col_exprs as $col_index => $col_expr)
        {
            if ($this->is_fk($basis_table, $col_expr['basis']))
            {
                foreach ($this->m_table_names as $ancestor)
                {
                    if ($ancestor != $basis_table &&
                        !in_array($ancestor, $ignore_tables) &&
                        $this->is_dependent_expr($ancestor, $col_expr['expr']))
                    {
                        $deps[$ancestor][] = array('expr_index'=>$col_index, 'basis'=>$col_expr['basis']);
                    }
                }
            }
        }

        return $deps;
    }

    function get_node_path(&$path, &$visits, &$basis_node, $path_node, $is_top=true)
    {
        static $done = false;

        if ($is_top)
        {
            $done = false;
        }
        else if (($node_key = implode('', $path_node)) && !isset($visits[$node_key]))
        {
            $visits[$node_key] = true;
        }

        if ($path_node[TABLE_NAME] == $basis_node[TABLE_NAME] &&
            $path_node[COL_NAME] == $basis_node[COL_NAME])
        {
            $done = true;
        }
        else if (!empty($this->m_graph[$path_node[TABLE_NAME]]['children']))
        {
            foreach ($this->m_graph[$path_node[TABLE_NAME]]['children'] as $child_node)
            {
                if (!isset($visits[implode('', $child_node)]) &&
                    $this->get_node_path($path, $visits, $basis_node, $child_node, false))
                {
                    break;
                }
            }
        }

        if ($done == true)
        {
            $path[] = $path_node;
        }

        return $done;
    }

    function get_col_index($table_name, $col_name)
    {
        return isset($this->m_col_indexes[$table_name][$col_name]) ? $this->m_col_indexes[$table_name][$col_name] : null ;
    }

    function get_paths($basis_table = null)
    {
        $paths = array();

        if (!empty($this->m_table_names)/* && !empty($this->m_graph)*/)
        {
            $stand_alone_tables = null;
            $parent_only_tables = null;
            $intermediate_tables = null;
            $child_only_tables = null;
            $basis_tables = null;

            foreach ($this->m_table_names as $table_name)
            {
                $has_children = isset($this->m_graph[$table_name]['children']);
                $has_parents = isset($this->m_graph[$table_name]['parents']);

                if ($has_children && !$has_parents)
                {
                    $parent_only_tables[] = $table_name;
                }
                else if (!$has_children && !$has_parents)
                {
                    $stand_alone_tables[] = $table_name;
                }
                else if (!$has_children && $has_parents)
                {
                    $child_only_tables[] = $table_name;
                }
                else if ($has_children && $has_parents)
                {
                    $intermediate_tables[] = $table_name;
                }
            }

            ////

            if ($basis_table)
            {
                if ((is_array($child_only_tables) && in_array($basis_table, $child_only_tables)) ||
                    (is_array($intermediate_tables) && in_array($basis_table, $intermediate_tables)))
                {
                    $basis_tables[] = $basis_table;
                }
            }
            else
            {
                $basis_tables = $child_only_tables;
            }

            ////

            if (!empty($basis_tables) && !empty($parent_only_tables))
            {
                foreach ($basis_tables as $table_name)
                {
                    $cols_info = $this->get_table_cols_info($table_name);

                    if (!empty($cols_info))
                    {
                        $basis_index = 0;

                        foreach ($cols_info as $col_info)
                        {
                            $col_name = $col_info['Field'];

                            if ($this->is_fk($table_name, $col_name))
                            {
                                $basis_node = array(TABLE_NAME=>$table_name, COL_NAME=>$col_name, JOIN_TABLE=>null, JOIN_COL=>null);

                                foreach ($parent_only_tables as $parent_only_table)
                                {
                                   $key_cols = $this->m_custom->get_key_cols($parent_only_table);

                                   foreach ($key_cols as $key_col)
                                   {
                                        $visits = array();
                                        $path = array();

                                        $path_node = array(TABLE_NAME=>$parent_only_table, COL_NAME=>$key_col, JOIN_TABLE=>null, JOIN_COL=>null);

                                        $this->get_node_path($path, $visits, $basis_node, $path_node);

                                        if (!empty($path))
                                        {
                                            $paths[] = array(PATH=>$path, BASIS_INDEX=>$basis_index);
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                        $basis_index++;
                    }
                }
            }

            ////

            if ($basis_table && !empty($parent_only_tables))
            {
                foreach ($parent_only_tables as $table_name)
                {
                    if ($table_name == $basis_table)
                    {
                        $path_node = array(TABLE_NAME=>$table_name, COL_NAME=>$this->m_custom->get_pk_name($table_name), JOIN_TABLE=>null, JOIN_COL=>null);
                        $paths[] = array(PATH=>array($path_node), BASIS_INDEX=>0);
                        break;
                    }
                }
            }

            ////

            if (!empty($stand_alone_tables))
            {
                foreach ($stand_alone_tables as $table_name)
                {
                    if (!$basis_table || $table_name == $basis_table)
                    {
                        $path_node = array(TABLE_NAME=>$table_name, COL_NAME=>$this->m_custom->get_pk_name($table_name), JOIN_TABLE=>null, JOIN_COL=>null);
                        $paths[] = array(PATH=>array($path_node), BASIS_INDEX=>0);
                    }
                }
            }
        }

        return $paths;
    }
}

////

?>
