<?php

/* action.php - SynApp2 main interface
**
   +----------------------------------------------------------------------+
   | SynApp2 Version 1                                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 2007 - 2011 Richard Howell. All rights reserved.       |
   +----------------------------------------------------------------------+
   | This source file is subject to version 1.01 of the SynApp2 license,  |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.synapp2.org/license/1_01.txt                              |
   | If you did not receive a copy of the SynApp2 license and are unable  |
   | to obtain it through the world-wide-web, please send a note to       |
   | license@synapp2.org so we can mail you a copy immediately.           |
   +----------------------------------------------------------------------+
   | Authors: Richard Howell                                              |
   |                                                                      |
   +----------------------------------------------------------------------+
**
** http://www.synapp2.org
**
** $Id: action.php,v 1.28 2011/06/18 18:01:51 richard Exp $
*/

require_once('util.php');

////////

class action
{
    var $m_login_method = '';
    var $m_login_username = '';
    var $m_login_password = '';

    var $m_appid = '';
    var $m_action = 'select';
    var $m_mode = 'get_norm';
    var $m_pid = '';
    var $m_qid = '';
    var $m_rid = '';
    var $m_export = '';

    var $m_order = '';
    var $m_limit_offset = 0;
    var $m_limit_rows = 0;
    var $m_show_response = false;

    var $m_pk = 0;
    var $m_flow_basis = '';
    var $m_flow_constraint = 0;
    var $m_flow = array();
    var $m_context = array();

    var $m_process_args = array();
    var $m_col_vars = array();
    var $m_col_expands = array();

    function action()
    {
        $this->fetch_vars();
    }

    function wick_request_member($n, $v)
    {
        $m = 'm_' . $n;

        if (isset($this->$m))
        {
            if (is_scalar($this->$m) && gettype($this->$m) != gettype($v))
            {
                $result = settype($v, gettype($this->$m));
                assert($result);
            }

            $this->$m = $v;
        }
    }

    function map_flow(&$custom)
    {
        if (!empty($this->m_flow))
        {
            foreach ($this->m_flow as $flow_info)
            {
                $_qid_ = $_pk_ = $_basis_ = $_table_ = $_key_ = null;

                @list($_qid_, $_pk_, $_basis_, $_table_, $_key_) = explode(',', $flow_info);

                if (!empty($_qid_) && !empty($_pk_))
                {
                    if ($_table_ == $custom->get_table($this->get_qid())) // test is_basis_table
                    {
                        assert('$_key_');

                        if ($this->m_flow_basis && $_basis_ == $this->m_flow_basis)
                        {
                            $this->m_flow_constraint =  array('n' => "{$_table_}.{$_key_}", 'v' => $_pk_);
                        }

                        if ($this->is_get_init())
                        {
                            $this->m_col_expands[$_key_] = $_pk_;
                        }
                        else if ($this->is_insert())
                        {
                            $this->m_col_vars[$_key_] = array('n' => $_key_, 'v' => $_pk_);
                        }
                    }
                }
            }
        }
    }

    function get_appid()
    {
        return $this->m_appid;
    }

    function get_login_method()
    {
        return $this->m_login_method;
    }

    function get_login_username()
    {
        return $this->m_login_username;
    }

    function get_login_password()
    {
        return $this->m_login_password;
    }

    function is_login()
    {
        $u = $this->get_login_username();
        $p = $this->get_login_password();

        return (!empty($u) || !empty($p));
    }

    function is_logout()
    {
        return $this->get_qid() == '_logout_';
    }

    function get_request_action()
    {
        return $this->m_action;
    }

    function get_request_mode()
    {
        return $this->m_mode;
    }

    function is_insert()
    {
        return $this->m_action == 'insert';
    }

    function is_select()
    {
        return $this->m_action == 'select';
    }

    function is_update()
    {
        return $this->m_action == 'update';
    }

    function is_delete()
    {
        return $this->m_action == 'delete';
    }

    function is_init()
    {
        return $this->m_action == 'init';
    }

    function is_get_init()
    {
        return $this->m_mode == 'get_init';
    }

    function is_report()
    {
        return $this->m_mode == 'report';
    }

    function is_export()
    {
        return !empty($this->m_export);
    }

    function is_adhoc()
    {
        return $this->m_mode == 'adhoc';
    }

    function is_fetch()
    {
        return $this->m_mode == 'fetch';
    }

    function is_close()
    {
        return $this->m_mode == 'close';
    }

    function is_cancel()
    {
        return $this->m_mode == 'cancel';
    }

    function is_change()
    {
        return $this->is_insert() || $this->is_update() || $this->is_delete();
    }

    function is_cancel_or_is_close()
    {
        return $this->is_cancel() || $this->is_close();
    }

    function is_show_response()
    {
        return $this->m_show_response;
    }

    function is_verbose_response()
    {
        global $response_dbx_error, $g_debug_msg;

        return $this->is_show_response() || !empty($response_dbx_error) || !empty($g_debug_msg);
    }

    function is_filter()
    {
        return $this->is_select() && !$this->get_pk();
    }

    function fetch_vars()
    {
        if (!empty($_POST))
        {
            foreach ($_POST as $n => $v)
            {
                if (strpos($n, '_request_col_expand_') === 0)
                {
                    assert('is_array($v)');

                    if (is_array($v))
                    {
                        foreach ($v as $col_name)
                        {
                            $this->m_col_expands[$col_name] = '';
                        }
                    }
                }
                else if (strpos($n, '_request_') === 0)
                {
                    $i = 9; // strlen('_request_');
                    $this->wick_request_member(substr($n, $i, strlen($n) - $i - 1), $v);
                }
                else if (strpos($n, '_login_') === 0)
                {
                    $this->wick_request_member(substr($n, 1, strlen($n) - 2), $v);
                }
                else if (strpos($n, '_process_') === 0)
                {
                    $i = 9; // strlen('_process_');
                    $this->m_process_args[substr($n, $i, strlen($n) - $i)] = $v;
                }
                else
                {
                    if (($this->is_filter() || $this->is_insert() || $this->is_update()) && !is_array($_POST[$n]))
                    {
                        $_POST[$n] = decode_entities($_POST[$n]);
                    }

                    $this->m_col_vars[$n] = array('n' => $n, 'v' => &$_POST[$n]);
//                    $this->m_col_vars[$n] = &$_POST[$n]; // TODO:
                }
            }

            if (isset($_POST['_login_password_']))
            {
                $_POST['_login_password_'] = '*******';
            }
        }
    }

    function do_process($func)
    {
        global $g_access, $g_custom, $g_markup;

        $result = true; // default - continue action

        if (!empty($func) && is_callable($func) === true)
        {
            if (!$g_custom->is_auth_process_username($func, $g_access->get_username()))
            {
                $result = false;
            }
            else
            {
                $adhoc_markup = array();

                $result = call_user_func_array($func, array(&$this->m_process_args, &$this, &$adhoc_markup));

                if (!empty($adhoc_markup))
                {
                    $g_markup->m_ADH = array_merge($g_markup->m_ADH, $adhoc_markup);
                }
            }
        }

        return !empty($result);
    }

    function get_affected_rows()
    {
        global $response_dbx_affected_rows;

        return $response_dbx_affected_rows;
    }

    function get_pid()
    {
        return $this->m_pid;
    }

    function get_qid()
    {
        return $this->m_qid;
    }

    function get_rid()
    {
        return $this->m_rid;
    }

    function get_export()
    {
        return $this->m_export;
    }

    function get_pk()
    {
        return $this->m_pk;
    }

    function get_pk_values($qid)
    {
        $result = null;

        if (!empty($qid))
        {
            foreach ($this->m_context as $context_csv)
            {
                if (strpos($context_csv, "{$qid},") === 0)
                {
                    $result = explode(',', substr($context_csv, strlen("{$qid},")));
                    break;
                }
            }
        }

        return $result;
    }

    function get_fk_constraint()
    {
        return $this->m_flow_constraint;
    }

    function get_order()
    {
        return $this->m_order;
    }

    function get_limit_offset()
    {
        return $this->m_limit_offset;
    }

    function get_limit_rows()
    {
        return $this->m_limit_rows;
    }

    function &get_col_vars()
    {
        return $this->m_col_vars;
    }

    function get_col_var($col_name)
    {
        return isset($this->m_col_vars[$col_name]['v']) ? $this->m_col_vars[$col_name]['v'] : null ;
    }

    function is_col_expand($col_name)
    {
        return isset($this->m_col_expands[$col_name]);
    }

    function get_col_expand($col_name)
    {
        return isset($this->m_col_expands[$col_name]) ? $this->m_col_expands[$col_name] : '' ;
    }
};

////////

$insert_offset = 0;
$db_name = '';
$db_active = false;

$recs = null;
$select_options = null;
$feedback = null;

$response_rows = 0;
$response_cols = 0;
$response_firstpage = 1;
$response_lastpage = 1;

$response_query = '';

$response_dbx_errno = 0;
$response_dbx_error = '';
$response_dbx_found_rows = 0;
$response_dbx_affected_rows = 0;

////////

if (file_exists(get_charset_dir() . 'charset.inc.php'))
{
    include(get_charset_dir() . 'charset.inc.php'); // establish charset_map [for decode_entities()] before call to action::fetch_vars()
}

$g_action = new action();

$g_dbx = new_dbx(@dbx_base::get_engine());

require_once('custom.php');

$g_custom = new custom($g_dbx, $g_action->get_appid(), $g_action->get_qid());
$g_custom->build();

//if (file_exists(get_app_dir($g_action->get_appid()) . 'global.inc.php'))
//{
//    include(get_app_dir($g_action->get_appid()) . 'global.inc.php');
//}

$g_action->map_flow($g_custom);

require_once('access.php');

$g_access = new_access($g_action, $g_dbx, $g_custom);

if ($g_action->do_process($g_custom->get_process(PROCESS_ON_INIT)) &&
    (!$g_action->is_logout() && !$g_access->is_setup()) &&
    $g_access->is_authenticated() &&
    $g_access->db_connect())
{
    $db_name = $g_access->get_database_physical();

    if (!empty($db_name))
    {
        $db_active = $g_access->select_db($db_name);
    }

    require_once('schema.php');

    $g_schema = new schema($g_dbx, $g_custom, $db_active);

    require_once('validate.php');

    require_once('markup.php');

    $g_markup = new markup($g_action, $g_dbx, $g_custom, $g_schema, true);

    require_once('query.php');

    $g_query = new_query($g_action, $g_custom, $g_schema);

    require_once('lock.php');

    $g_lock = new lock($g_dbx);

//    $g_lock->get_lock('foo', 1); // DEBUG:
}

////////

if ($g_action->is_show_response())
{
    add_debug_msg(); // add $_POST vars
}

////////

if ($g_access->is_authenticated() &&
    $g_access->is_authorized() &&
    $g_action->get_qid() &&
    $g_action->do_process($g_custom->get_process(PROCESS_MAIN)) &&
    $db_active)
{
    if ($feedback = validate_columns($g_action, $g_dbx, $g_custom, $g_schema))
    {
        // validation failed, nothing more to do
    }
    else
    {
        $g_action->do_process($g_custom->get_process(PROCESS_MAIN_ON_OPEN));

        if ((!$g_action->is_get_init() &&
             !$g_action->is_cancel_or_is_close()) &&
            ($response_query = $g_query->get_query_expr()))
        {
            if ($g_action->is_select() && !($g_action->get_pk() || $g_action->is_report()))
            {
                $limit_rows = $g_action->get_limit_rows() > 0 ? $g_action->get_limit_rows() + 1 : 0 ; // NOTE: 1 extra row used to detect lastpage
                $response_query = $g_dbx->get_limited_query($response_query, $limit_rows, $g_action->get_limit_offset());
            }
            else if ($g_action->is_insert())
            {
                $response_query = $g_dbx->get_insert_id_query($g_custom->get_pk_name($g_query->get_table()), $response_query);
            }

            $g_dbx->clear_errors();

            if ($g_action->do_process($g_custom->get_process(PROCESS_MAIN_ON_QUERY)))
            {
                $recs = $g_dbx->get_query_records($response_query);

                $response_dbx_affected_rows = $g_dbx->affected_rows();
            }

            $feedback = validate_unique($g_action, $g_dbx, $g_custom, $g_schema);

            $response_dbx_error = $g_dbx->get_errors();
            $response_dbx_found_rows = get_found_rows($g_query);
        }

        if ($g_action->is_select())
        {
            if ($g_action->is_get_init())
            {
                assert('empty($recs) == true');

                if (empty($recs) && ($col_defaults = $g_schema->gather_col_defaults()))
                {
                    $recs[] = $col_defaults;
                }
            }

            ////

            if (!empty($recs))
            {
                $response_rows = count($recs);
                $response_cols = count($recs[0]);
            }

            $response_firstpage = $g_action->get_limit_offset() <= 0 ? 1 : 0 ;
            $response_lastpage = $g_action->get_limit_rows() < 1 || $response_rows <= $g_action->get_limit_rows() ? 1 : 0 ;

            if ($g_action->get_limit_rows() > 0 && $response_rows > $g_action->get_limit_rows())
            {
                $response_rows = $g_action->get_limit_rows(); // size of the payload
            }

            ////

            $select_options_exprs = $g_query->get_select_options_exprs();

            if (!empty($select_options_exprs))
            {
                foreach ($select_options_exprs as $col_name => $select_options_expr)
                {
                    if (is_string($select_options_expr))
                    {
                        $select_options[$col_name] = $g_dbx->get_query_records($select_options_expr);
                    }
                    else if (is_array($select_options_expr))
                    {
                        $select_options[$col_name] = $select_options_expr; // set/enum
                    }
                }
            }
        }
        else if ($g_action->is_insert())
        {
            $insert_id = $g_dbx->insert_id();
            $insert_offset = get_insert_offset($insert_id);
        }
        else if ($g_action->is_update())
        {
            $affected_id = $g_action->get_pk();
            $insert_offset = get_insert_offset($affected_id);
        }
        else if ($g_action->is_delete())
        {
            // do nothing
        }

        $g_action->do_process($g_custom->get_process(PROCESS_MAIN_ON_CLOSE));
    }
}

$g_action->do_process($g_custom->get_process(PROCESS_ON_EXIT));

////////

assert('$response_dbx_errno == 0');

////////

$response = '';

fmt_line($response, "<response>");
fmt_line($response, "<version>" . get_version(true) . "</version>");

if ($g_access->is_setup())
{
    fmt_line($response, "<setup>true</setup>");
}

fmt_line($response, "<authentication>" . ($g_access->is_authenticated() ? 'succeeded' : 'failed') . "</authentication>");
fmt_line($response, "<authorization>" . ($g_access->is_authorized() ? 'succeeded' : 'failed') . "</authorization>");
fmt_line($response, "<request_action>" . $g_action->get_request_action() . "</request_action>");
fmt_line($response, "<request_mode>" . $g_action->get_request_mode() . "</request_mode>");
fmt_line($response, "<qid>" . $g_action->get_qid() . "</qid>");
fmt_line($response, "<query>" . ($g_action->is_verbose_response() ? encode_entities($response_query) : '') . "</query>");

if (!empty($response_dbx_error))
{
    fmt_line($response, "<error>");

    foreach ($response_dbx_error as $line)
    {
        fmt_line($response, encode_entities($line));
    }

    fmt_line($response, "</error>");
}

fmt_line($response, "<affected_rows>{$response_dbx_affected_rows}</affected_rows>");
fmt_line($response, "<found_rows>{$response_dbx_found_rows}</found_rows>");
fmt_line($response, "<insert_offset>{$insert_offset}</insert_offset>");
fmt_line($response, "<rows>{$response_rows}</rows>");
fmt_line($response, "<cols>{$response_cols}</cols>");
fmt_line($response, "<firstpage>{$response_firstpage}</firstpage>");
fmt_line($response, "<lastpage>{$response_lastpage}</lastpage>");

if ($auth_action_qids = $g_custom->get_qids_auth_actions($g_access->get_username()))
{
    fmt_line($response, '<auth_actions>');

    foreach ($auth_action_qids as $qid => $auth_actions)
    {
        $line = '';
        $sep = '';

        $line .= "<actions id=\"{$qid}\">";

        if (!empty($auth_actions))
        {
            foreach ($auth_actions as $auth_action)
            {
                switch ($auth_action)
                {
                case AUTH_ADD:
                case AUTH_EDIT:
                case AUTH_DELETE:
                    $line .= $sep . $auth_action;
                    $sep = ',';
                    break;
                }
            }
        }

        $line .= "</actions>";

        if (!empty($line))
        {
            fmt_line($response, $line);
        }
    }

    fmt_line($response, '</auth_actions>');
}

////

if (!empty($g_markup->m_ADF))
{
    assert('empty($feedback) == true');

    $feedback = &$g_markup->m_ADF;
}

if (!empty($feedback))
{
    fmt_line($response, '<feedback>');

    foreach ($feedback as $name => $status)
    {
        fmt_line($response, "<status name=\"$name\">{$status['status']}</status>");
    }

    fmt_line($response, '</feedback>');
}
else if (!empty($recs) && (!$g_action->is_report() || $g_action->is_verbose_response()))
{
    fmt_line($response, "<payload>");

    $pk_name = $g_custom->get_pk_name($g_query->get_table());

    $i = 0;

    foreach ($recs as $rec)
    {
        if (!$i)
        {
            fmt_line($response, "<axis>" . implode(',', array_keys($rec)) . "</axis>");
        }

        ////

        $rec_id = isset($rec[$pk_name]) ? " id=\"{$rec[$pk_name]}\"" : '' ;

        ////

        $response .= "<tr$rec_id>";

        $show_names = $g_action->is_verbose_response();

        foreach ($rec as $n => $v)
        {
            $attrs = $show_names ? " name=\"$n\"" : '' ;
            $response .= "<td$attrs>" . encode_entities($v) . "</td>";
        }

        fmt_line($response, "</tr>");

        ////

        $i++;

        if ($i >= $response_rows)
        {
            break; // skip extra record used to determine $response_lastpage
        }
    }

    fmt_line($response, "</payload>");
}

////

if (!empty($select_options))
{
    foreach ($select_options as $col_name => $options)
    {
        fmt_line($response, "<select name=\"$col_name\">");

        if (!empty($options))
        {
            foreach ($options as $c => $option)
            {
                $value = isset($option['value']) ? $option['value'] : (isset($option['VALUE']) ? $option['VALUE'] : '') ; // TODO: HACK: KLUGE:
                $text = isset($option['text']) ? $option['text'] : (isset($option['TEXT']) ? $option['TEXT'] : '') ; // TODO: HACK: KLUGE:

                if (empty($text))
                {
                    $text = $value;
                }

                fmt_line($response, "<option value=\"{$value}\">" . encode_entities($text) . "</option>");
            }
        }

        fmt_line($response, "</select>");
    }
}

////

if ($g_action->is_logout())
{
    $g_access->logout();

    fmt_line($response, '<logout>');
    fmt_line($response, $g_action->get_appid());
    fmt_line($response, '</logout>');
}

if ($g_action->is_adhoc())
{
    fmt_line($response, '<adhoc>');

    if ($g_access->is_setup())
    {
        if (!empty($g_access->m_ADH))
        {
            fmt_line($response, '<markup>');

            foreach ($g_access->m_ADH as $markup)
            {
                fmt_line($response, $markup);
            }

            fmt_line($response, '</markup>');
        }
    }
    else if (isset($g_markup))
    {
        if (!empty($g_markup->m_ADH))
        {
            fmt_line($response, '<markup>');

            foreach ($g_markup->m_ADH as $markup)
            {
                fmt_line($response, $markup);
            }

            fmt_line($response, '</markup>');
        }

        if (!empty($g_markup->m_IDD))
        {
            fmt_line($response, '<idd>' . implode(',', $g_markup->m_IDD) . '</idd>');
        }

        if (!empty($g_markup->m_TDD))
        {
            fmt_line($response, '<tdd>' . implode(',', $g_markup->m_TDD) . '</tdd>');
        }
    }

    fmt_line($response, '</adhoc>');
}

////

if (!empty($g_debug_msg))
{
    $response .= $g_debug_msg;
}

////

fmt_line($response, "</response>");

////

$preamble = '';

fmt_line($preamble, '<' . '?xml version="1.0" encoding="'. get_charset_map()->get_charset_out() . '" standalone="no" ?' . '>');

$response = $preamble . get_entity_references() . $response;

////

if ($g_action && $g_action->is_report() && !$g_action->is_verbose_response())
{
    if ($g_access->is_authorized())
    {
        require_once('report.php');

        if ($obj_report = new_report($g_action, $g_custom, $g_schema, $g_query))
        {
            $obj_report->do_report($recs);
        }
    }
}
else
{
    header("Content-Type: text/xml");
    echo $response;
}

////////

function put_payload_rec($name, $value)
{
    global $recs;

    $recs[] = array($name => $value);
}

////

function get_insert_offset($id)
{
    global $g_action, $g_dbx, $g_custom, $g_schema;

    $offset = 0;

    $offset_obj = new query_offset($g_action, $g_custom, $g_schema, $id);
    $offset_expr = $offset_obj->get_query_expr();

    if (!empty($offset_expr))
    {
        $offset_query = $g_dbx->get_insert_offset_query($g_custom->get_pk_name($g_custom->get_table()), $id, $offset_expr);
        $offset = max(0, $g_dbx->get_query_value($offset_query) - 1);
    }

    return $offset;
}

function get_found_rows(&$query)
{
    global $g_dbx;

    $found_rows = 0;

    $expr = $query->get_found_rows_expr();

    if (!empty($expr))
    {
        $found_rows = $g_dbx->get_query_value($expr);
    }

    return $found_rows;
}

////

?>
